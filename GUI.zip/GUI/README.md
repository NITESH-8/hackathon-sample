## Performance GUI (PySide6 + PyQtGraph)

Run a real-time subsystem performance dashboard with targets and export.

### Setup

1. Create venv (optional)
```bash
python -m venv .venv
. .venv/Scripts/activate
```
2. Install dependencies
```bash
pip install -r requirements.txt
```
3. Run
```bash
python -m app.main
```

### Notes
- GPU metrics use NVIDIA NVML via `pynvml` if available.
- PNG export uses PyQtGraph exporters; falls back to widget grab.
