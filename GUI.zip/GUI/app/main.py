from __future__ import annotations

import csv
import os
import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .data_sources import Subsystem, get_timestamp, get_cpu_core_count, get_cpu_core_percent


SUBSYSTEMS = [Subsystem.CPU, Subsystem.GPU, Subsystem.DRAM]


@dataclass
class SubsystemState:
	name: str
	target_percent: int = 50
	values: List[Tuple[float, float]] = field(default_factory=list)
	curve: Optional[pg.PlotDataItem] = None
	target_line: Optional[pg.InfiniteLine] = None


@dataclass
class CoreState:
	core_id: int
	target_percent: int = 50
	values: List[Tuple[float, float]] = field(default_factory=list)
	curve: Optional[pg.PlotDataItem] = None
	target_line: Optional[pg.InfiniteLine] = None


class PerformanceApp(QtWidgets.QMainWindow):
	def __init__(self) -> None:
		super().__init__()
		self.setWindowTitle("Performance Dashboard")
		self.resize(1200, 720)

		self.states: Dict[str, SubsystemState] = {name: SubsystemState(name=name) for name in SUBSYSTEMS}
		self.core_states: Dict[int, CoreState] = {}
		self.active_subsystems: List[str] = []
		self.active_cores: List[int] = []
		self.is_running: bool = False
		self.end_time_epoch: Optional[float] = None

		self.process: Optional[QtCore.QProcess] = None
		self.line_buffer: bytes = b""

		# Initialize CPU cores
		self._init_cpu_cores()

		self._build_ui()
		self._configure_plot()
		# Start maximized with window controls visible
		self.showMaximized()
		# Internal sampler (used when no external command is needed)
		self._sample_timer = QtCore.QTimer(self)
		self._sample_timer.setInterval(500)
		self._sample_timer.timeout.connect(self._sample_metrics)

	def _init_cpu_cores(self) -> None:
		"""Initialize CPU core states."""
		core_count = get_cpu_core_count()
		self.core_states = {i: CoreState(core_id=i) for i in range(core_count)}

	def _build_ui(self) -> None:
		central = QtWidgets.QWidget(self)
		self.setCentralWidget(central)

		root = QtWidgets.QHBoxLayout(central)

		# Left panel inside a scroll area to avoid forcing huge window height
		controls_scroll = QtWidgets.QScrollArea()
		controls_scroll.setWidgetResizable(True)
		controls_container = QtWidgets.QWidget()
		controls = QtWidgets.QVBoxLayout(controls_container)
		controls_scroll.setWidget(controls_container)
		root.addWidget(controls_scroll, 0)

		controls.addWidget(self._make_label("Subsystems", bold=True))
		self.checkbox_group: Dict[str, QtWidgets.QCheckBox] = {}
		for name in SUBSYSTEMS:
			cb = QtWidgets.QCheckBox(name)
			cb.stateChanged.connect(self._on_subsystem_toggled)
			controls.addWidget(cb)
			self.checkbox_group[name] = cb

		# CPU Cores section (initially hidden)
		controls.addSpacing(8)
		self.cpu_cores_group = QtWidgets.QGroupBox("CPU Cores")
		self.cpu_cores_group.setVisible(False)
		cores_layout = QtWidgets.QVBoxLayout(self.cpu_cores_group)
		
		# Header above cores to label slider column
		header_row = QtWidgets.QHBoxLayout()
		header_row.addWidget(QtWidgets.QLabel(""))  # spacer for checkbox column
		header_target = QtWidgets.QLabel("Target (%)")
		header_row.addWidget(header_target)
		header_row.addWidget(QtWidgets.QLabel(""))  # spacer for live value column
		header_row.addStretch(1)
		cores_layout.addLayout(header_row)
		
		self.core_checkboxes: Dict[int, QtWidgets.QCheckBox] = {}
		self.core_sliders: Dict[int, QtWidgets.QSlider] = {}
		self.core_labels: Dict[int, QtWidgets.QLabel] = {}
		self.core_texts: Dict[int, QtWidgets.QLineEdit] = {}
		controls.addWidget(self._make_label("Targets (%)", bold=True))
		# CPU Target row (replaces Core 0)
		cpu_target_row = QtWidgets.QHBoxLayout()
		cpu_target_cb = QtWidgets.QCheckBox("CPU Target")
		cpu_target_cb.stateChanged.connect(self._on_cpu_target_toggled)
		cpu_target_row.addWidget(cpu_target_cb)
		self.cpu_target_checkbox = cpu_target_cb
		
		# CPU Target slider
		cpu_target_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
		cpu_target_slider.setRange(0, 100)
		cpu_target_slider.setValue(self.states[Subsystem.CPU].target_percent)
		cpu_target_slider.setMinimumWidth(100)
		cpu_target_slider.setMaximumWidth(150)
		cpu_target_slider.valueChanged.connect(lambda val: self._on_cpu_target_changed(val))
		cpu_target_row.addWidget(cpu_target_slider)
		self.cpu_target_slider = cpu_target_slider
		cpu_target_slider.setVisible(False)
		
		# CPU Target text box
		cpu_target_text = QtWidgets.QLineEdit(str(self.states[Subsystem.CPU].target_percent))
		cpu_target_text.setValidator(QtGui.QIntValidator(0, 100, self))
		cpu_target_text.setFixedWidth(40)
		cpu_target_slider.valueChanged.connect(lambda val, field=cpu_target_text: field.setText(str(int(val))))
		def _apply_cpu_target_txt():
			try:
				val_int = int(cpu_target_text.text() or 0)
				val_int = max(0, min(100, val_int))
				if cpu_target_slider.value() != val_int:
					cpu_target_slider.setValue(val_int)
			except Exception:
				pass
		cpu_target_text.editingFinished.connect(_apply_cpu_target_txt)
		cpu_target_row.addWidget(cpu_target_text)
		self.cpu_target_text = cpu_target_text
		
		cpu_target_row.addStretch(1)
		cores_layout.addLayout(cpu_target_row)
		
		# CPU cores 0-6 (7 cores total)
		for core_id in range(7):
			# Create horizontal layout for each core
			core_row = QtWidgets.QHBoxLayout()
			
			# Checkbox
			cb = QtWidgets.QCheckBox(f"Core {core_id}")
			cb.stateChanged.connect(self._on_core_toggled)
			core_row.addWidget(cb)
			self.core_checkboxes[core_id] = cb
			
			# Slider
			slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
			slider.setRange(0, 100)
			slider.setValue(self.core_states[core_id].target_percent)
			slider.setMinimumWidth(100)
			slider.setMaximumWidth(150)
			slider.valueChanged.connect(lambda val, cid=core_id: self._on_core_target_changed(cid, val))
			core_row.addWidget(slider)
			self.core_sliders[core_id] = slider
			slider.setVisible(False)
			
			# Editable percent to the right of slider
			txt = QtWidgets.QLineEdit(str(self.core_states[core_id].target_percent))
			txt.setValidator(QtGui.QIntValidator(0, 100, self))
			txt.setFixedWidth(40)
			slider.valueChanged.connect(lambda val, field=txt: field.setText(str(int(val))))
			def _apply_txt(cid=core_id, field_ref=None):
				# On edit, push to slider and target
				try:
					val_int = int((field_ref or txt).text() or 0)
					val_int = max(0, min(100, val_int))
					sel_slider = self.core_sliders[cid]
					if sel_slider.value() != val_int:
						sel_slider.setValue(val_int)
				except Exception:
					pass
			txt.editingFinished.connect(lambda cid=core_id, field_ref=txt: _apply_txt(cid, field_ref))
			core_row.addWidget(txt)
			self.core_texts[core_id] = txt
			
			# Add stretch to push everything to the left
			core_row.addStretch(1)
			
			cores_layout.addLayout(core_row)
		
		controls.addWidget(self.cpu_cores_group)

		controls.addSpacing(8)
		self.slider_container = QtWidgets.QWidget()
		self.slider_form = QtWidgets.QFormLayout(self.slider_container)
		self.slider_form.setFieldGrowthPolicy(QtWidgets.QFormLayout.ExpandingFieldsGrow)
		controls.addWidget(self.slider_container, 0)

		# User Setup group
		controls.addSpacing(8)
		user_group = QtWidgets.QGroupBox("User Setup")
		user_v = QtWidgets.QVBoxLayout(user_group)
		user_v.addWidget(self._make_label("Duration", bold=True))
		duration_row = QtWidgets.QHBoxLayout()
		self.duration_spin = QtWidgets.QSpinBox()
		self.duration_spin.setRange(1, 24 * 60 * 60)
		self.duration_spin.setValue(60)
		self.duration_spin.setSuffix(" s")
		duration_row.addWidget(self.duration_spin)
		user_v.addLayout(duration_row)
		# Slider + editable text field synced with the spinbox
		slider_row = QtWidgets.QHBoxLayout()
		self.duration_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
		self.duration_slider.setRange(1, 3600)
		self.duration_slider.setValue(60)
		slider_row.addWidget(self.duration_slider, 1)
		self.duration_text = QtWidgets.QLineEdit()
		self.duration_text.setFixedWidth(64)
		self.duration_text.setText("60")
		self.duration_text.setValidator(QtGui.QIntValidator(1, 24 * 60 * 60, self))
		slider_row.addWidget(self.duration_text)
		user_v.addLayout(slider_row)
		# Wiring: keep all three in sync
		self.duration_slider.valueChanged.connect(lambda v: (self.duration_spin.setValue(int(v)), self._update_command_preview()))
		self.duration_spin.valueChanged.connect(lambda v: (self.duration_text.setText(str(int(v))), self._update_command_preview()))
		self.duration_spin.valueChanged.connect(lambda v: (self.duration_slider.setValue(int(v)) if 1 <= int(v) <= 3600 else None))
		self.duration_text.editingFinished.connect(lambda: (self.duration_spin.setValue(int(self.duration_text.text() or 60)), self._update_command_preview()))
		# Generated command preview (for Linux stress tool)
		user_v.addWidget(self._make_label("Generated command (auto-updates):", bold=True))
		cmd_row = QtWidgets.QHBoxLayout()
		self.command_preview = QtWidgets.QTextEdit()
		self.command_preview.setReadOnly(True)
		self.command_preview.setLineWrapMode(QtWidgets.QTextEdit.WidgetWidth)
		self.command_preview.setFixedHeight(72)
		cmd_row.addWidget(self.command_preview, 1)
		self.btn_copy_cmd = QtWidgets.QToolButton()
		self.btn_copy_cmd.setText("Copy")
		self.btn_copy_cmd.setToolTip("Copy command to clipboard")
		self.btn_copy_cmd.clicked.connect(lambda: QtWidgets.QApplication.clipboard().setText(self.command_preview.toPlainText()))
		cmd_row.addWidget(self.btn_copy_cmd)
		user_v.addLayout(cmd_row)
		
		# Test mode checkbox for simulating Linux stress output (can be removed later)
		test_row = QtWidgets.QHBoxLayout()
		self.test_mode_cb = QtWidgets.QCheckBox("Test Mode (simulate Linux stress output)")
		self.test_mode_cb.setToolTip("Enable to simulate Linux stress tool output for testing")
		test_row.addWidget(self.test_mode_cb)
		test_row.addStretch(1)
		user_v.addLayout(test_row)
		controls.addWidget(user_group)

		# Actions group
		actions_group = QtWidgets.QGroupBox("Actions")
		actions_v = QtWidgets.QVBoxLayout(actions_group)
		btn_row = QtWidgets.QHBoxLayout()
		self.btn_start = QtWidgets.QPushButton("Execute Test")
		self.btn_start.setToolTip("Start the test (Ctrl+R)")
		self.btn_stop = QtWidgets.QPushButton("Stop")
		self.btn_stop.setToolTip("Stop the running test (Esc)")
		self.btn_start.clicked.connect(self._on_start)
		self.btn_stop.clicked.connect(self._on_stop)
		btn_row.addWidget(self.btn_start)
		btn_row.addWidget(self.btn_stop)
		btn_row.addStretch(1)
		actions_v.addLayout(btn_row)
		row2 = QtWidgets.QHBoxLayout()
		self.btn_clear = QtWidgets.QPushButton("Clear Data")
		self.btn_clear.setToolTip("Clear current chart and values")
		self.btn_clear.clicked.connect(self._on_clear)
		row2.addWidget(self.btn_clear)
		self.btn_export_csv = QtWidgets.QPushButton("Export CSV")
		self.btn_export_png = QtWidgets.QPushButton("Export PNG")
		self.btn_export_csv.clicked.connect(self._on_export_csv)
		self.btn_export_png.clicked.connect(self._on_export_png)
		row2.addWidget(self.btn_export_csv)
		row2.addWidget(self.btn_export_png)
		row2.addStretch(1)
		actions_v.addLayout(row2)
		controls.addWidget(actions_group)
		# Shortcuts
		QtGui.QShortcut(QtGui.QKeySequence("Ctrl+R"), self, activated=self._on_start)
		QtGui.QShortcut(QtGui.QKeySequence("Escape"), self, activated=self._on_stop)
		QtGui.QShortcut(QtGui.QKeySequence("Ctrl+S"), self, activated=self._on_export_csv)
		QtGui.QShortcut(QtGui.QKeySequence("Ctrl+P"), self, activated=self._on_export_png)
		controls.addStretch(1)

		controls.addWidget(self._make_label("Current Values", bold=True))
		self.numeric_list = QtWidgets.QListWidget()
		self.numeric_list.setMinimumWidth(260)
		controls.addWidget(self.numeric_list, 1)

		right = QtWidgets.QVBoxLayout()
		root.addLayout(right, 1)

		select_row = QtWidgets.QHBoxLayout()
		select_row.addWidget(self._make_label("Active graph:"))
		self.combo_active = QtWidgets.QComboBox()
		self.combo_active.currentTextChanged.connect(self._on_active_changed)
		select_row.addWidget(self.combo_active)
		select_row.addStretch(1)
		right.addLayout(select_row)

		# Create plot widget with reset button
		plot_container = QtWidgets.QWidget()
		plot_layout = QtWidgets.QVBoxLayout(plot_container)
		plot_layout.setContentsMargins(0, 0, 0, 0)
		
		# Add reset button at top right
		reset_button = QtWidgets.QPushButton("Reset View")
		reset_button.setMaximumWidth(100)
		reset_button.setMaximumHeight(30)
		reset_button.clicked.connect(self._on_reset_graph)
		reset_button.setToolTip("Reset zoom and pan to show full data range")
		
		# Create horizontal layout for reset button (right-aligned)
		button_layout = QtWidgets.QHBoxLayout()
		button_layout.addStretch()  # Push button to the right
		button_layout.addWidget(reset_button)
		button_layout.setContentsMargins(0, 0, 5, 0)  # Small margin from right edge
		
		plot_layout.addLayout(button_layout)
		
		# Create plot widget
		self.plot_widget = pg.PlotWidget()
		self.plot_widget.setBackground("w")
		plot_layout.addWidget(self.plot_widget, 1)
		
		right.addWidget(plot_container, 1)

	def _configure_plot(self) -> None:
		self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
		self.plot_widget.setLabel("left", "Performance", units="%")
		self.plot_widget.setLabel("bottom", "Time", units="s")
		self.plot_widget.setYRange(0, 100)
		
		# Force time axis to show seconds, not kiloseconds
		bottom_axis = self.plot_widget.getAxis('bottom')
		bottom_axis.setLabel(text="Time", units="s")
		
		# Enhanced scrolling and interaction
		self.plot_widget.setMouseEnabled(x=True, y=True)
		self.plot_widget.setLimits(xMin=0, yMin=0, yMax=100)
		
		# Better axis formatting
		self.plot_widget.getAxis('left').setTickSpacing(10, 5)
		
		# Improved scrolling behavior
		self.plot_widget.setAutoVisible(y=True)
		self.plot_widget.enableAutoRange(axis='y')
		
		# Set initial view range
		self.plot_widget.setXRange(0, 60)
		
		# Enable smooth scrolling and better performance
		self.plot_widget.setClipToView(True)
		self.plot_widget.setDownsampling(mode='peak')
		self.plot_widget.setDownsampling(auto=True)
		
		# Better performance for real-time updates
		self.plot_widget.setCacheMode(QtWidgets.QGraphicsView.CacheBackground)
		
		# Configure mouse interaction for better scrolling
		viewbox = self.plot_widget.getViewBox()
		viewbox.setMouseMode(pg.ViewBox.PanMode)
		viewbox.setAspectLocked(False)
		viewbox.setLimits(xMin=0, yMin=0, yMax=100)
		
		# Enable smooth mouse interaction
		viewbox.setMouseEnabled(x=True, y=True)
		
		# Connect to view range change for dynamic time scaling
		viewbox.sigRangeChanged.connect(self._on_view_range_changed)

	def _on_view_range_changed(self) -> None:
		"""Dynamically adjust time axis tick spacing based on zoom level."""
		viewbox = self.plot_widget.getViewBox()
		view_range = viewbox.viewRange()
		x_range = view_range[0]  # (x_min, x_max)
		time_span = x_range[1] - x_range[0]
		
		# Only apply custom spacing if we have a reasonable time span
		if time_span < 1:
			return  # Don't format if time span is too small
		
		# Determine appropriate tick spacing based on time span
		if time_span <= 30:
			# Short time span: 5-second intervals
			major_tick = 5
			minor_tick = 1
		elif time_span <= 120:
			# Medium time span: 10-second intervals
			major_tick = 10
			minor_tick = 2
		elif time_span <= 300:
			# Longer time span: 20-second intervals
			major_tick = 20
			minor_tick = 5
		elif time_span <= 600:
			# Very long time span: 50-second intervals
			major_tick = 50
			minor_tick = 10
		elif time_span <= 1800:
			# Extra long time span: 100-second intervals
			major_tick = 100
			minor_tick = 20
		else:
			# Very long time span: 300-second intervals
			major_tick = 300
			minor_tick = 60
		
		# Apply the new tick spacing
		self.plot_widget.getAxis('bottom').setTickSpacing(major_tick, minor_tick)

	def _setup_time_axis_formatting(self, time_span: float) -> None:
		"""Setup time axis formatting to show seconds and minutes format."""
		# For now, let PyQtGraph handle the default formatting
		# The custom tick spacing will provide the main benefit
		pass

	def _on_reset_graph(self) -> None:
		"""Reset graph zoom and pan to show full data range."""
		# Get all data points to determine the range
		all_x_values = []
		all_y_values = []
		
		# Collect data from all subsystems
		for state in self.states.values():
			if state.values:
				for ts, val in state.values:
					all_x_values.append(ts)
					all_y_values.append(val)
		
		# Collect data from all CPU cores
		for core_state in self.core_states.values():
			if core_state.values:
				for ts, val in core_state.values:
					all_x_values.append(ts)
					all_y_values.append(val)
		
		if not all_x_values:
			# No data yet, reset to default view
			self.plot_widget.setXRange(0, 60)
			self.plot_widget.setYRange(0, 100)
			return
		
		# Calculate data range
		min_x = min(all_x_values)
		max_x = max(all_x_values)
		min_y = min(all_y_values)
		max_y = max(all_y_values)
		
		# Convert to relative time (seconds from start)
		if min_x > 0:
			# Data exists, show from 0 to max relative time
			max_relative_time = max_x - min_x
			self.plot_widget.setXRange(0, max_relative_time + 10)  # Add 10 seconds padding
		else:
			# No data yet, show default range
			self.plot_widget.setXRange(0, 60)
		
		# Set Y range with some padding
		y_padding = (max_y - min_y) * 0.1 if max_y > min_y else 10
		self.plot_widget.setYRange(max(0, min_y - y_padding), min(100, max_y + y_padding))
		
		# Reset the view to auto-range for better display
		self.plot_widget.enableAutoRange(axis='xy')

	def _make_label(self, text: str, bold: bool = False) -> QtWidgets.QLabel:
		lbl = QtWidgets.QLabel(text)
		if bold:
			font = lbl.font()
			font.setBold(True)
			lbl.setFont(font)
		return lbl

	def _get_core_pen(self, core_id: int) -> pg.mkPen:
		# Use distinct color per core via color wheel
		color = pg.intColor(core_id, hues=len(self.core_states) or 8, maxValue=200)
		return pg.mkPen(color=color, width=2)

	def _on_subsystem_toggled(self) -> None:
		self.active_subsystems = [name for name, cb in self.checkbox_group.items() if cb.isChecked()]
		
		# Show/hide CPU cores section when CPU is selected
		cpu_selected = self.checkbox_group[Subsystem.CPU].isChecked()
		self.cpu_cores_group.setVisible(cpu_selected)
		
		# If CPU is deselected, clear active cores and hide sliders
		if not cpu_selected:
			for cb in self.core_checkboxes.values():
				cb.setChecked(False)
			self.active_cores.clear()
			for slider in self.core_sliders.values():
				slider.setVisible(False)
			for label in self.core_labels.values():
				label.setVisible(False)
		
		self._rebuild_sliders()
		self._rebuild_active_combo()
		self._refresh_numeric_list()
		self._refresh_plot_items()
		self._update_command_preview()

	def _on_cpu_target_toggled(self) -> None:
		"""Handle CPU Target checkbox toggle."""
		cpu_target_selected = self.cpu_target_checkbox.isChecked()
		self.cpu_target_slider.setVisible(cpu_target_selected)
		self.cpu_target_text.setVisible(cpu_target_selected)
		
		# Update active subsystems
		if cpu_target_selected:
			if Subsystem.CPU not in self.active_subsystems:
				self.active_subsystems.append(Subsystem.CPU)
		else:
			if Subsystem.CPU in self.active_subsystems:
				self.active_subsystems.remove(Subsystem.CPU)
		
		self._rebuild_active_combo()
		self._refresh_plot_items()
		self._update_command_preview()

	def _on_core_toggled(self) -> None:
		self.active_cores = [core_id for core_id, cb in self.core_checkboxes.items() if cb.isChecked()]
		# Update slider visibility
		for core_id, slider in self.core_sliders.items():
			slider.setVisible(core_id in self.active_cores)
		for core_id, label in self.core_labels.items():
			label.setVisible(core_id in self.active_cores)
		self._rebuild_active_combo()
		self._refresh_numeric_list()
		self._refresh_plot_items()
		self._update_command_preview()

	def _rebuild_sliders(self) -> None:
		while self.slider_form.rowCount() > 0:
			self.slider_form.removeRow(0)
		
		# Add sliders for regular subsystems (excluding CPU)
		for name in self.active_subsystems:
			if name == Subsystem.CPU:
				continue  # Skip CPU, cores have their own sliders
			slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
			slider.setRange(0, 100)
			slider.setValue(self.states[name].target_percent)
			slider.valueChanged.connect(lambda val, n=name: self._on_target_changed(n, val))
			# Composite row widget with slider and editable percent to the right
			row_widget = QtWidgets.QWidget()
			row_layout = QtWidgets.QHBoxLayout(row_widget)
			row_layout.setContentsMargins(0, 0, 0, 0)
			row_layout.addWidget(slider, 1)
			txt = QtWidgets.QLineEdit(str(self.states[name].target_percent))
			txt.setValidator(QtGui.QIntValidator(0, 100, self))
			txt.setFixedWidth(40)
			slider.valueChanged.connect(lambda val, field=txt: field.setText(str(int(val))))
			def _apply_txt_sys(sys_name=name, field_ref=None):
				try:
					val_int = int((field_ref or txt).text() or 0)
					val_int = max(0, min(100, val_int))
					if slider.value() != val_int:
						slider.setValue(val_int)
				except Exception:
					pass
			txt.editingFinished.connect(lambda sys_name=name, field_ref=txt: _apply_txt_sys(sys_name, field_ref))
			row_layout.addWidget(txt)
			self.slider_form.addRow(QtWidgets.QLabel(f"{name} Target:"), row_widget)

	def _rebuild_active_combo(self) -> None:
		current = self.combo_active.currentText()
		self.combo_active.blockSignals(True)
		self.combo_active.clear()
		
		# Add regular subsystems (including CPU)
		for name in self.active_subsystems:
			self.combo_active.addItem(name)
		
		# Combined CPU cores option
		if self.active_cores:
			self.combo_active.addItem("CPU (cores)")
		
		# Add individual CPU cores
		for core_id in self.active_cores:
			self.combo_active.addItem(f"Core {core_id}")
		
		self.combo_active.blockSignals(False)
		if current in [self.combo_active.itemText(i) for i in range(self.combo_active.count())]:
			self.combo_active.setCurrentText(current)
		elif self.combo_active.count() > 0:
			self.combo_active.setCurrentIndex(0)
		self._refresh_plot_items()
		self._update_command_preview()

	def _on_target_changed(self, name: str, value: int) -> None:
		self.states[name].target_percent = int(value)
		if self.combo_active.currentText() == name and self.states[name].target_line is not None:
			self.states[name].target_line.setValue(value)
		self._update_numeric_colors()
		self._update_command_preview()

	def _on_cpu_target_changed(self, value: int) -> None:
		"""Handle CPU target slider changes."""
		self.states[Subsystem.CPU].target_percent = int(value)
		if self.combo_active.currentText() == Subsystem.CPU and self.states[Subsystem.CPU].target_line is not None:
			self.states[Subsystem.CPU].target_line.setValue(value)
		self._update_numeric_colors()
		self._update_command_preview()

	def _on_core_target_changed(self, core_id: int, value: int) -> None:
		self.core_states[core_id].target_percent = int(value)
		active = self.combo_active.currentText()
		if (active == "CPU (cores)" or active == f"Core {core_id}") and self.core_states[core_id].target_line is not None:
			self.core_states[core_id].target_line.setValue(value)
		self._update_numeric_colors()
		self._update_command_preview()

	def _refresh_plot_items(self) -> None:
		self.plot_widget.clear()
		active = self.combo_active.currentText()
		if not active:
			return
		
		if active == "CPU (cores)":
			# Plot all selected cores with distinct colors and own target lines
			for core_id in self.active_cores:
				state = self.core_states[core_id]
				state.curve = self.plot_widget.plot([], [], pen=self._get_core_pen(core_id))
				line = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen(color=self._get_core_pen(core_id).color(), width=1, style=QtCore.Qt.DotLine))
				line.setValue(state.target_percent)
				self.plot_widget.addItem(line)
				state.target_line = line
			return
		
		# Otherwise, single item (subsystem or individual core)
		if active.startswith("Core "):
			core_id = int(active.split()[1])
			state = self.core_states[core_id]
		else:
			state = self.states[active]
		
		curve = self.plot_widget.plot([], [], pen=pg.mkPen(color=(0, 122, 204), width=2))
		state.curve = curve
		line = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen(color=(200, 0, 0), width=2, style=QtCore.Qt.DotLine))
		line.setValue(state.target_percent)
		self.plot_widget.addItem(line)
		state.target_line = line

	def _on_active_changed(self, _: str) -> None:
		self._refresh_plot_items()
		self._redraw_curve()
		self._update_export_enabled()

	def _on_start(self) -> None:
		if not self.active_subsystems and not self.active_cores:
			QtWidgets.QMessageBox.information(self, "Info", "Select at least one subsystem or CPU core.")
			return
		for name in self.active_subsystems:
			self.states[name].values.clear()
		for core_id in self.active_cores:
			self.core_states[core_id].values.clear()
		self.is_running = True
		duration_s = int(self.duration_spin.value())
		self.end_time_epoch = get_timestamp() + duration_s
		# Start internal sampler by default; if a stress command is built, run it and parse as well
		cmd = self.command_preview.toPlainText().strip()
		if cmd and not (hasattr(self, 'test_mode_cb') and self.test_mode_cb.isChecked()):
			self._start_process(cmd)
		elif hasattr(self, 'test_mode_cb') and self.test_mode_cb.isChecked():
			self._start_test_mode()
		self._sample_timer.start()
		# Disable inputs while running
		self.btn_start.setEnabled(False)
		self.btn_stop.setEnabled(True)
		self.duration_spin.setEnabled(False)
		# Command input removed

	def _start_process(self, cmd: str) -> None:
		self._stop_process()
		self.process = QtCore.QProcess(self)
		self.process.setProcessChannelMode(QtCore.QProcess.MergedChannels)
		self.process.readyReadStandardOutput.connect(self._on_process_output)
		self.process.finished.connect(self._on_process_finished)
		# Use shell for Windows to interpret full command line
		self.process.start("powershell.exe", ["-NoProfile", "-Command", cmd])
		if not self.process.waitForStarted(3000):
			QtWidgets.QMessageBox.critical(self, "Error", "Failed to start command.")
			self._on_stop()

	def _stop_process(self) -> None:
		if self.process is not None:
			self.process.kill()
			self.process = None

	def _on_stop(self) -> None:
		self.is_running = False
		self._stop_process()
		self.end_time_epoch = None
		# Re-enable inputs
		self.btn_start.setEnabled(True)
		self.btn_stop.setEnabled(False)
		self.duration_spin.setEnabled(True)
		# Stop internal sampler
		self._sample_timer.stop()
		# Stop test mode if running (test mode only)
		if hasattr(self, 'test_timer'):
			self.test_timer.stop()

	def _on_process_finished(self) -> None:
		self.is_running = False
		self._stop_process()
		self._sample_timer.stop()

	def _on_process_output(self) -> None:
		now = get_timestamp()
		if self.is_running and self.end_time_epoch is not None and now >= self.end_time_epoch:
			self._on_stop()
			return
		if self.process is not None:
			self.line_buffer += self.process.readAllStandardOutput().data()
			lines = self.line_buffer.split(b"\n")
			self.line_buffer = lines[-1]
			for raw in lines[:-1]:
				line = raw.decode(errors="ignore").strip()
				if not line:
					continue
				self._try_parse_and_store(line, now)
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()

	def _try_parse_and_store(self, line: str, ts: float) -> None:
		# Parse Linux stress tool output format
		# Examples: cpu0: 61.38619%, DRAM usage: 4.87443%, GPU usage: 0%
		
		# Parse CPU cores (cpu0: 61.38619%, cpu1: 80%, etc.)
		for core_id in self.active_cores:
			core_patterns = [
				rf"cpu{core_id}:\s*([0-9]+(?:\.[0-9]+)?)%",
				rf"Core\s+{core_id}:\s*([0-9]+(?:\.[0-9]+)?)%",
			]
			for pat in core_patterns:
				m = re.search(pat, line)
				if m:
					val = float(m.group(1))
					self.core_states[core_id].values.append((ts, val))
					break
		
		# Parse DRAM usage
		if Subsystem.DRAM in self.active_subsystems:
			dram_patterns = [
				r"DRAM usage:\s*([0-9]+(?:\.[0-9]+)?)%",
				r"DRAM\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%",
			]
			for pat in dram_patterns:
				m = re.search(pat, line)
				if m:
					val = float(m.group(1))
					self.states[Subsystem.DRAM].values.append((ts, val))
					break
		
		# Parse GPU usage
		if Subsystem.GPU in self.active_subsystems:
			gpu_patterns = [
				r"GPU usage:\s*([0-9]+(?:\.[0-9]+)?)%",
				r"GPU\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%",
			]
			for pat in gpu_patterns:
				m = re.search(pat, line)
				if m:
					val = float(m.group(1))
					self.states[Subsystem.GPU].values.append((ts, val))
					break
		
		# Fallback to old patterns for compatibility
		patterns = {
			Subsystem.CPU: [r"CPU\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"cpu\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%"],
			Subsystem.GPU: [r"GPU\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"gpu\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%"],
			Subsystem.DRAM: [r"DRAM\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"MEM(?:ORY)?\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"mem\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%"],
		}
		
		# Parse regular subsystems (excluding CPU)
		for name in self.active_subsystems:
			if name != Subsystem.CPU:  # Skip CPU, handle cores separately
				for pat in patterns.get(name, []):
					m = re.search(pat, line)
					if m:
						val = float(m.group(1))
						self.states[name].values.append((ts, val))
						break
		
		# If no specific core data found, try to get CPU core data from psutil
		if Subsystem.CPU in self.active_subsystems and self.active_cores:
			try:
				core_percentages = get_cpu_core_percent()
				for core_id in self.active_cores:
					if core_id < len(core_percentages):
						self.core_states[core_id].values.append((ts, core_percentages[core_id]))
			except Exception:
				pass

	def _sample_metrics(self) -> None:
		if not self.is_running:
			return
		ts = get_timestamp()
		# CPU cores
		try:
			core_percentages = get_cpu_core_percent()
			for core_id in self.active_cores:
				if core_id < len(core_percentages):
					core_value = max(0, min(100, core_percentages[core_id]))  # Clamp to 0-100%
					self.core_states[core_id].values.append((ts, core_value))
		except Exception:
			pass
		# CPU aggregate if selected and no cores selected
		if Subsystem.CPU in self.active_subsystems and not self.active_cores:
			try:
				vals = get_cpu_core_percent()
				avg = sum(vals) / max(1, len(vals))
				cpu_value = max(0, min(100, avg))  # Clamp to 0-100%
				self.states[Subsystem.CPU].values.append((ts, cpu_value))
			except Exception:
				pass
		# DRAM via psutil
		if Subsystem.DRAM in self.active_subsystems:
			try:
				import psutil
				mem = psutil.virtual_memory()
				dram_value = max(0, min(100, float(mem.percent)))  # Clamp to 0-100%
				self.states[Subsystem.DRAM].values.append((ts, dram_value))
			except Exception:
				pass
		# GPU via pynvml if available
		if Subsystem.GPU in self.active_subsystems:
			try:
				import pynvml
				pynvml.nvmlInit()
				h = pynvml.nvmlDeviceGetHandleByIndex(0)
				util = pynvml.nvmlDeviceGetUtilizationRates(h)
				gpu_value = max(0, min(100, float(util.gpu)))  # Clamp to 0-100%
				self.states[Subsystem.GPU].values.append((ts, gpu_value))
				pynvml.nvmlShutdown()
			except (ImportError, Exception):
				# If no NVIDIA GPU or drivers, set GPU to 0
				self.states[Subsystem.GPU].values.append((ts, 0.0))
		self._redraw_curve()
		self._refresh_numeric_list()

	def _redraw_curve(self) -> None:
		active = self.combo_active.currentText()
		if not active:
			return
		
		if active == "CPU (cores)":
			# For each core, draw its curve
			for core_id in self.active_cores:
				state = self.core_states[core_id]
				if state.curve is None or not state.values:
					if state.curve is not None and not state.values:
						state.curve.setData([], [])
					continue
				t0 = state.values[0][0]
				x = [ts - t0 for ts, _ in state.values]
				y = [max(0, min(100, v)) for _, v in state.values]  # Clamp values to 0-100%
				state.curve.setData(x, y)
			if any(self.core_states[c].values for c in self.active_cores):
				last_x = max((self.core_states[c].values[-1][0] - self.core_states[c].values[0][0]) for c in self.active_cores if self.core_states[c].values)
				if last_x > 60:
					# Smooth scrolling: show last 60 seconds
					self.plot_widget.setXRange(max(0, last_x - 60), last_x)
				else:
					# Show from 0 to at least 60 seconds
					self.plot_widget.setXRange(0, max(60, last_x + 10))
				# Trigger dynamic time scaling
				self._on_view_range_changed()
			return
		
		# Single item view
		if active.startswith("Core "):
			core_id = int(active.split()[1])
			state = self.core_states[core_id]
		else:
			state = self.states[active]
		
		if state.curve is None:
			return
		if not state.values:
			state.curve.setData([], [])
			return
		t0 = state.values[0][0]
		x = [ts - t0 for ts, _ in state.values]
		y = [max(0, min(100, v)) for _, v in state.values]  # Clamp values to 0-100%
		state.curve.setData(x, y)
		if x and x[-1] > 60:
			# Smooth scrolling: show last 60 seconds
			self.plot_widget.setXRange(max(0, x[-1] - 60), x[-1])
		elif x:
			# Show from 0 to at least 60 seconds
			self.plot_widget.setXRange(0, max(60, x[-1] + 10))
		# Trigger dynamic time scaling
		self._on_view_range_changed()

	def _refresh_numeric_list(self) -> None:
		self.numeric_list.clear()
		
		# Add regular subsystems (excluding CPU)
		for name in self.active_subsystems:
			if name != Subsystem.CPU:
				state = self.states[name]
				val: Optional[float] = state.values[-1][1] if state.values else None
				text = f"{name}: {val:.1f}% (target {state.target_percent}%)" if val is not None else f"{name}: -- (target {state.target_percent}%)"
				item = QtWidgets.QListWidgetItem(text)
				self.numeric_list.addItem(item)
		
		# Add active CPU cores
		for core_id in self.active_cores:
			state = self.core_states[core_id]
			val: Optional[float] = state.values[-1][1] if state.values else None
			text = f"Core {core_id}: {val:.1f}% (target {state.target_percent}%)" if val is not None else f"Core {core_id}: -- (target {state.target_percent}%)"
			item = QtWidgets.QListWidgetItem(text)
			self.numeric_list.addItem(item)
		
		self._update_numeric_colors()

	def _update_numeric_colors(self) -> None:
		item_idx = 0
		
		# Color regular subsystems (excluding CPU)
		for name in self.active_subsystems:
			if name != Subsystem.CPU:
				state = self.states[name]
				val: Optional[float] = state.values[-1][1] if state.values else None
				item = self.numeric_list.item(item_idx)
				if item is not None:
					if val is None:
						item.setForeground(QtGui.QBrush(QtGui.QColor(120, 120, 120)))
					elif val >= state.target_percent:
						item.setForeground(QtGui.QBrush(QtGui.QColor(0, 130, 0)))
					else:
						item.setForeground(QtGui.QBrush(QtGui.QColor(180, 0, 0)))
				item_idx += 1
		
		# Color active CPU cores
		for core_id in self.active_cores:
			state = self.core_states[core_id]
			val: Optional[float] = state.values[-1][1] if state.values else None
			item = self.numeric_list.item(item_idx)
			if item is not None:
				if val is None:
					item.setForeground(QtGui.QBrush(QtGui.QColor(120, 120, 120)))
				elif val >= state.target_percent:
					item.setForeground(QtGui.QBrush(QtGui.QColor(0, 130, 0)))
				else:
					item.setForeground(QtGui.QBrush(QtGui.QColor(180, 0, 0)))
			item_idx += 1

	# ===== TEST MODE FUNCTIONS (CAN BE REMOVED AFTER TESTING) =====
	def _start_test_mode(self) -> None:
		"""Start test mode that simulates Linux stress tool output."""
		self.test_timer = QtCore.QTimer(self)
		self.test_timer.setInterval(2000)  # Simulate every 2 seconds
		self.test_timer.timeout.connect(self._simulate_stress_output)
		self.test_timer.start()
		self._simulate_stress_output()  # Start immediately

	def _simulate_stress_output(self) -> None:
		"""Simulate Linux stress tool output for testing."""
		if not self.is_running:
			return
		
		import random
		ts = get_timestamp()
		
		# Simulate realistic performance data based on your output format
		# CPU overall usage (from "cpu: XX.XX%" line)
		if Subsystem.CPU in self.active_subsystems:
			# Simulate overall CPU usage with some variation
			base_cpu = random.uniform(20, 50)
			variation = random.uniform(-3, 3)
			cpu_value = max(0, min(100, base_cpu + variation))
			self.states[Subsystem.CPU].values.append((ts, cpu_value))
		
		# Simulate CPU core data (from "cpu0: XX.XX%" lines)
		for core_id in self.active_cores:
			if core_id == 0:  # Core 0 - target around 60%
				base_value = random.uniform(55, 65)
			elif core_id == 1:  # Core 1 - target around 80%
				base_value = random.uniform(75, 85)
			else:  # Other cores - random low usage
				base_value = random.uniform(0, 40)
			
			variation = random.uniform(-2, 2)
			value = max(0, min(100, base_value + variation))
			self.core_states[core_id].values.append((ts, value))
		
		# Simulate DRAM data (from "DRAM usage: XX.XXXXX%" line)
		if Subsystem.DRAM in self.active_subsystems:
			# Simulate DRAM usage with some variation
			base_dram = random.uniform(3, 8)
			variation = random.uniform(-1, 1)
			dram_value = max(0, min(100, base_dram + variation))
			self.states[Subsystem.DRAM].values.append((ts, dram_value))
		
		# Simulate GPU data (from "GPU usage: X%" line)
		if Subsystem.GPU in self.active_subsystems:
			# Simulate GPU usage with some variation
			base_gpu = random.uniform(0, 5)
			variation = random.uniform(-1, 1)
			gpu_value = max(0, min(100, base_gpu + variation))
			self.states[Subsystem.GPU].values.append((ts, gpu_value))
		
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()

	def _parse_stress_output(self, output: str) -> None:
		"""Parse Linux stress tool output and update graph data."""
		import re
		ts = get_timestamp()
		
		# Parse CPU overall usage (from "cpu: XX.XX%" line)
		cpu_match = re.search(r'cpu:\s+([\d.]+)%', output)
		if cpu_match and Subsystem.CPU in self.active_subsystems:
			cpu_value = float(cpu_match.group(1))
			self.states[Subsystem.CPU].values.append((ts, cpu_value))
		
		# Parse CPU core usage (from "cpu0: XX.XX%" lines)
		for core_id in range(7):
			core_match = re.search(rf'cpu{core_id}:\s+([\d.]+)%', output)
			if core_match and core_id in self.active_cores:
				core_value = float(core_match.group(1))
				self.core_states[core_id].values.append((ts, core_value))
		
		# Parse DRAM usage (from "DRAM usage: XX.XXXXX%" line)
		dram_match = re.search(r'DRAM usage:\s+([\d.]+)%', output)
		if dram_match and Subsystem.DRAM in self.active_subsystems:
			dram_value = float(dram_match.group(1))
			self.states[Subsystem.DRAM].values.append((ts, dram_value))
		
		# Parse GPU usage (from "GPU usage: X%" line)
		gpu_match = re.search(r'GPU usage:\s+([\d.]+)%', output)
		if gpu_match and Subsystem.GPU in self.active_subsystems:
			gpu_value = float(gpu_match.group(1))
			self.states[Subsystem.GPU].values.append((ts, gpu_value))
		
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()
	# ===== END TEST MODE FUNCTIONS =====

	def _on_export_csv(self) -> None:
		has_data = any(self.states[name].values for name in self.active_subsystems) or any(self.core_states[core_id].values for core_id in self.active_cores)
		if not has_data:
			QtWidgets.QMessageBox.information(self, "Info", "No data to export.")
			return
		path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save CSV", os.path.join(os.getcwd(), "results.csv"), "CSV Files (*.csv)")
		if not path:
			return
		with open(path, "w", newline="", encoding="utf-8") as f:
			writer = csv.writer(f)
			writer.writerow(["timestamp", "subsystem", "value_percent", "target_percent"])
			for name in self.active_subsystems:
				state = self.states[name]
				for ts, val in state.values:
					writer.writerow([int(ts), name, f"{val:.3f}", state.target_percent])
			for core_id in self.active_cores:
				state = self.core_states[core_id]
				for ts, val in state.values:
					writer.writerow([int(ts), f"Core {core_id}", f"{val:.3f}", state.target_percent])

	def _on_export_png(self) -> None:
		if self.combo_active.currentText() == "":
			QtWidgets.QMessageBox.information(self, "Info", "No active graph to export.")
			return
		path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save PNG", os.path.join(os.getcwd(), "graph.png"), "PNG Files (*.png)")
		if not path:
			return
		try:
			from pyqtgraph.exporters import ImageExporter
			exporter = ImageExporter(self.plot_widget.plotItem)
			exporter.parameters()["width"] = 1200
			exporter.export(path)
		except Exception:
			pixmap = self.plot_widget.grab()
			pixmap.save(path, "PNG")

	def _on_clear(self) -> None:
		for name in self.states:
			self.states[name].values.clear()
		for core_id in self.core_states:
			self.core_states[core_id].values.clear()
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()

	def _update_export_enabled(self) -> None:
		has_data = any(self.states[name].values for name in self.active_subsystems) or any(self.core_states[core_id].values for core_id in self.active_cores)
		self.btn_export_csv.setEnabled(has_data)
		self.btn_export_png.setEnabled(self.combo_active.currentText() != "")

	def _update_command_preview(self) -> None:
		# Build Linux stress command from current selections
		parts: List[str] = ["stress"]
		
		# CPU load (overall CPU target) - only if CPU Target is checked
		if (Subsystem.CPU in self.active_subsystems and 
			hasattr(self, 'cpu_target_checkbox') and 
			self.cpu_target_checkbox.isChecked()):
			target = self.states[Subsystem.CPU].target_percent
			parts.extend(["--cpu-load", str(target)])
		
		# CPU cores - only if individual cores are checked
		for core_id in self.active_cores:
			if (hasattr(self, 'core_checkboxes') and 
				core_id in self.core_checkboxes and 
				self.core_checkboxes[core_id].isChecked()):
				target = self.core_states[core_id].target_percent
				parts.extend(["--cpu-core-load", f"{core_id}:{target}"])
		
		# GPU - only if GPU is checked
		if Subsystem.GPU in self.active_subsystems:
			target = self.states[Subsystem.GPU].target_percent
			parts.extend(["--gpu-load", str(target)])
		
		# DRAM - only if DRAM is checked
		if Subsystem.DRAM in self.active_subsystems:
			target = self.states[Subsystem.DRAM].target_percent
			parts.extend(["--dram-load", str(target)])
		
		# Duration
		dur = int(self.duration_spin.value())
		parts.extend(["--duration", str(dur)])
		self.command_preview.setPlainText(" ".join(parts))

	# Command browse removed with command feature


def main() -> None:
	app = QtWidgets.QApplication(sys.argv)
	pg.setConfigOptions(antialias=True)
	w = PerformanceApp()
	w.show()
	sys.exit(app.exec())


if __name__ == "__main__":
	main()
