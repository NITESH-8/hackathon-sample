from typing import List, Dict, Any, Optional
import numpy as np
import os
from .database import DatabaseManager
from .embedding_service import EmbeddingService
import uuid
from datetime import datetime

class SimilarityService:
    def __init__(self):
        self.db = DatabaseManager()
        self.embedding_service = EmbeddingService()
        # Configurable threshold; lighter embeddings often work best around 0.7
        try:
            self.similarity_threshold = float(os.getenv('SIMILARITY_THRESHOLD', '0.7'))
        except Exception:
            self.similarity_threshold = 0.7
    
    def find_similar_records(self, embeddings: Dict[str, Any], user_id: str, team_id: str) -> List[Dict[str, Any]]:
        """
        Stage 6: Find similar records based on embeddings
        """
        try:
            record_embedding = embeddings.get('record_embedding')
            if not record_embedding:
                return []
            
            # Get all accessible records for the user
            accessible_records = self._get_accessible_records(user_id, team_id)
            
            similar_records = []
            
            for record in accessible_records:
                if 'embedding' in record and record['embedding']:
                    similarity = self.embedding_service.compute_similarity(
                        record_embedding,
                        record.get('embedding') or []
                    )
                    
                    if similarity >= self.similarity_threshold:
                        similar_records.append({
                            'record_id': record['record_id'],
                            'title': record.get('title', 'Untitled'),
                            'similarity_score': similarity,
                            'owner_user_id': record['owner_user_id'],
                            'team_id': record['team_id'],
                            'visibility': record['visibility'],
                            'created_at': record['created_at'],
                            'overall_summary': record.get('overall_summary', ''),
                            'overall_severity': record.get('overall_severity', 0),
                            'tags': record.get('tags', [])
                        })
            
            # Sort by similarity score (highest first)
            similar_records.sort(key=lambda x: x['similarity_score'], reverse=True)
            
            return similar_records[:10]  # Return top 10 similar records
            
        except Exception as e:
            print(f"Error finding similar records: {e}")
            return []
    
    def get_similar_records(self, record_id: str, user_id: str, team_id: str) -> List[Dict[str, Any]]:
        """Get similar records for a specific record"""
        try:
            # Get the record
            record = self.db.get_record(record_id, user_id, team_id)
            if not record or 'embedding' not in record:
                return []
            
            # Find similar records
            embeddings = {'record_embedding': record['embedding']}
            return self.find_similar_records(embeddings, user_id, team_id)
            
        except Exception as e:
            print(f"Error getting similar records: {e}")
            return []
    
    def find_similar_chunks(self, chunk_embedding: List[float], user_id: str, team_id: str) -> List[Dict[str, Any]]:
        """Find similar chunks across all records"""
        try:
            # Query for chunks with embeddings
            query = {
                "query": {
                    "bool": {
                        "must": [
                            {"exists": {"field": "embedding"}}
                        ],
                        "should": [
                            {"term": {"owner_user_id": user_id}},
                            {
                                "bool": {
                                    "must": [
                                        {"term": {"team_id": team_id}},
                                        {"term": {"visibility": "team"}}
                                    ]
                                }
                            },
                            {"term": {"visibility": "public"}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "size": 100
            }
            
            result = self.db.es.search(
                index=self.db.indices['record_chunks'], 
                body=query
            )
            
            similar_chunks = []
            
            for hit in result['hits']['hits']:
                chunk = hit['_source']
                if 'embedding' in chunk and chunk['embedding']:
                    similarity = self.embedding_service.compute_similarity(
                        chunk_embedding,
                        chunk['embedding']
                    )
                    
                    if similarity >= self.similarity_threshold:
                        similar_chunks.append({
                            'chunk_id': chunk['chunk_id'],
                            'record_id': chunk['record_id'],
                            'similarity_score': similarity,
                            'text': chunk.get('text', ''),
                            'summary': chunk.get('summary', ''),
                            'is_error_window': chunk.get('is_error_window', False),
                            'signals': chunk.get('signals', []),
                            'start_line': chunk.get('start_line', 0),
                            'end_line': chunk.get('end_line', 0)
                        })
            
            # Sort by similarity score
            similar_chunks.sort(key=lambda x: x['similarity_score'], reverse=True)
            
            return similar_chunks[:20]  # Return top 20 similar chunks
            
        except Exception as e:
            print(f"Error finding similar chunks: {e}")
            return []
    
    def _get_accessible_records(self, user_id: str, team_id: str) -> List[Dict[str, Any]]:
        """Get all records accessible to the user"""
        try:
            query = {
                "query": {
                    "bool": {
                        "should": [
                            {"term": {"owner_user_id": user_id}},
                            {
                                "bool": {
                                    "must": [
                                        {"term": {"team_id": team_id}},
                                        {"term": {"visibility": "team"}}
                                    ]
                                }
                            },
                            {"term": {"visibility": "public"}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "size": 1000  # Get more records for better similarity matching
            }
            
            result = self.db.es.search(
                index=self.db.indices['records'], 
                body=query
            )
            
            return [hit['_source'] for hit in result['hits']['hits']]
            
        except Exception as e:
            print(f"Error getting accessible records: {e}")
            return []
    
    def store_record_chunks(self, record_id: str, chunk_embeddings: List[Dict[str, Any]], 
                           user_id: str, team_id: str, visibility: str):
        """Store chunk embeddings in the database"""
        try:
            for chunk_data in chunk_embeddings:
                chunk_id = str(uuid.uuid4())
                
                chunk_doc = {
                    'chunk_id': chunk_id,
                    'record_id': record_id,
                    'owner_user_id': user_id,
                    'team_id': team_id,
                    'visibility': visibility,
                    'start_line': chunk_data.get('start_line', 0),
                    'end_line': chunk_data.get('end_line', 0),
                    'is_error_window': chunk_data.get('is_error_window', False),
                    'text': chunk_data.get('text', ''),
                    'summary': chunk_data.get('summary', ''),
                    'signals': chunk_data.get('signals', []),
                    'embedding': chunk_data.get('embedding', []),
                    'created_at': datetime.now().isoformat()
                }
                
                self.db.es.index(
                    index=self.db.indices['record_chunks'],
                    id=chunk_id,
                    body=chunk_doc
                )
                
        except Exception as e:
            print(f"Error storing record chunks: {e}")
    
    def search_similar_content(self, query_text: str, user_id: str, team_id: str, 
                              search_type: str = 'records') -> List[Dict[str, Any]]:
        """Search for similar content using text query"""
        try:
            query_embedding = self.embedding_service._get_embedding(query_text)
            
            if search_type == 'records':
                return self._search_similar_records(query_embedding, user_id, team_id)
            elif search_type == 'chunks':
                return self.find_similar_chunks(query_embedding, user_id, team_id)
            else:
                return []
                
        except Exception as e:
            print(f"Error searching similar content: {e}")
            return []
    
    def _search_similar_records(self, query_embedding: List[float], user_id: str, team_id: str) -> List[Dict[str, Any]]:
        """Search for similar records using vector similarity"""
        try:
            query = {
                "knn": {
                    "field": "embedding",
                    "query_vector": query_embedding,
                    "k": 10,
                    "num_candidates": 100
                },
                "filter": {
                    "bool": {
                        "should": [
                            {"term": {"owner_user_id": user_id}},
                            {
                                "bool": {
                                    "must": [
                                        {"term": {"team_id": team_id}},
                                        {"term": {"visibility": "team"}}
                                    ]
                                }
                            },
                            {"term": {"visibility": "public"}}
                        ],
                        "minimum_should_match": 1
                    }
                }
            }
            
            result = self.db.es.search(
                index=self.db.indices['records'],
                body=query
            )
            
            similar_records = []
            for hit in result['hits']['hits']:
                record = hit['_source']
                similar_records.append({
                    'record_id': record['record_id'],
                    'title': record.get('title', 'Untitled'),
                    'similarity_score': hit['_score'],
                    'owner_user_id': record['owner_user_id'],
                    'team_id': record['team_id'],
                    'visibility': record['visibility'],
                    'created_at': record['created_at'],
                    'overall_summary': record.get('overall_summary', ''),
                    'overall_severity': record.get('overall_severity', 0),
                    'tags': record.get('tags', [])
                })
            
            return similar_records
            
        except Exception as e:
            print(f"Error searching similar records: {e}")
            return []
    
    def get_similarity_stats(self) -> Dict[str, Any]:
        """Get statistics about similarity service"""
        try:
            records_count = self.db.es.count(index=self.db.indices['records'])['count']
            chunks_count = self.db.es.count(index=self.db.indices['record_chunks'])['count']
            
            return {
                'total_records': records_count,
                'total_chunks': chunks_count,
                'similarity_threshold': self.similarity_threshold,
                'embedding_dimensions': self.embedding_service.embedding_dimensions
            }
        except Exception as e:
            return {'error': str(e)}
