from typing import Dict, List, Any, Optional
from datetime import datetime, timezone
import uuid
from .database import DatabaseManager
from .genapi_service import GenAPIService

class ConversationService:
    def __init__(self):
        self.db = DatabaseManager()
        self.genapi_service = GenAPIService()
    
    def create_conversation(self, record_id: str, user_id: str, team_id: str) -> str:
        """Create a new conversation for a log record"""
        try:
            conversation_id = str(uuid.uuid4())
            
            conversation_doc = {
                'conversation_id': conversation_id,
                'record_id': record_id,
                'user_id': user_id,
                'team_id': team_id,
                'messages': [],
                'created_at': datetime.now(timezone.utc).isoformat(),
                'updated_at': datetime.now(timezone.utc).isoformat(),
                'status': 'active'
            }
            
            result = self.db.es.index(
                index=self.db.indices['conversations'],
                id=conversation_id,
                body=conversation_doc
            )
            
            if result['result'] == 'created':
                return conversation_id
            else:
                raise Exception("Failed to create conversation")
                
        except Exception as e:
            print(f"Error creating conversation: {e}")
            raise e
    
    def get_conversation(self, conversation_id: str, user_id: str) -> Optional[Dict]:
        """Get conversation by ID with permission check"""
        try:
            result = self.db.es.get(
                index=self.db.indices['conversations'],
                id=conversation_id
            )
            
            conversation = result['_source']
            
            # Check if user has permission to access this conversation
            if conversation['user_id'] != user_id:
                return None
                
            return conversation
            
        except Exception as e:
            print(f"Error getting conversation: {e}")
            return None
    
    def get_conversation_by_record(self, record_id: str, user_id: str) -> Optional[Dict]:
        """Get existing conversation for a record, or create new one"""
        try:
            # Search for existing conversation
            query = {
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"record_id": record_id}},
                            {"term": {"user_id": user_id}},
                            {"term": {"status": "active"}}
                        ]
                    }
                },
                "sort": [{"created_at": {"order": "desc"}}],
                "size": 1
            }
            
            result = self.db.es.search(
                index=self.db.indices['conversations'],
                body=query
            )
            
            if result['hits']['total']['value'] > 0:
                return result['hits']['hits'][0]['_source']
            else:
                # Create new conversation
                # Get team_id from record
                record_result = self.db.es.get(
                    index=self.db.indices['records'],
                    id=record_id
                )
                record = record_result['_source']
                team_id = record.get('team_id', '')
                
                conversation_id = self.create_conversation(record_id, user_id, team_id)
                return self.get_conversation(conversation_id, user_id)
                
        except Exception as e:
            print(f"Error getting conversation by record: {e}")
            return None
    
    def add_message(self, conversation_id: str, message: str, sender: str, user_id: str) -> Dict:
        """Add a message to the conversation"""
        try:
            # Get conversation
            conversation = self.get_conversation(conversation_id, user_id)
            if not conversation:
                raise Exception("Conversation not found or access denied")
            
            # Create message
            message_doc = {
                'message_id': str(uuid.uuid4()),
                'content': message,
                'sender': sender,  # 'user' or 'assistant'
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
            
            # Add message to conversation
            conversation['messages'].append(message_doc)
            conversation['updated_at'] = datetime.now(timezone.utc).isoformat()
            
            # Update conversation in database
            self.db.es.index(
                index=self.db.indices['conversations'],
                id=conversation_id,
                body=conversation
            )
            
            return message_doc
            
        except Exception as e:
            print(f"Error adding message: {e}")
            raise e
    
    def ask_question(self, conversation_id: str, question: str, user_id: str) -> Dict:
        """Ask a question and get AI response"""
        try:
            # Get conversation
            conversation = self.get_conversation(conversation_id, user_id)
            if not conversation:
                raise Exception("Conversation not found or access denied")
            
            # Add user message
            user_message = self.add_message(conversation_id, question, 'user', user_id)
            
            # Get record details for context
            record_id = conversation['record_id']
            record_result = self.db.es.get(
                index=self.db.indices['records'],
                id=record_id
            )
            record = record_result['_source']
            
            # Prepare context for GenAI
            context = self._prepare_chat_context(record, conversation)
            
            # Get AI response from GenAI
            ai_response = self.genapi_service.ask_question(question, context)
            
            # Add AI response to conversation
            ai_message = self.add_message(conversation_id, ai_response, 'assistant', user_id)
            
            return {
                'user_message': user_message,
                'ai_message': ai_message,
                'conversation_id': conversation_id
            }
            
        except Exception as e:
            print(f"Error asking question: {e}")
            raise e
    
    def _prepare_chat_context(self, record: Dict, conversation: Dict) -> str:
        """Prepare context for GenAI chat"""
        context_parts = []
        
        # Basic record info
        context_parts.append(f"Log Record ID: {record['record_id']}")
        context_parts.append(f"Title: {record.get('title', 'Untitled')}")
        context_parts.append(f"Created: {record.get('created_at', 'Unknown')}")
        context_parts.append(f"Severity: {record.get('overall_severity', 0)}")
        
        # Log content
        if record.get('raw_file_path'):
            try:
                with open(record['raw_file_path'], 'r', encoding='utf-8', errors='ignore') as f:
                    log_content = f.read()
                    context_parts.append(f"Log Content:\n{log_content}")
            except Exception:
                context_parts.append("Log content not available")
        
        # Previous analysis
        if record.get('genapi', {}).get('summary'):
            context_parts.append(f"Previous Analysis Summary: {record['genapi']['summary']}")
        
        if record.get('genapi', {}).get('problems'):
            problems = record['genapi']['problems']
            context_parts.append(f"Identified Problems: {len(problems)} problems found")
            for i, problem in enumerate(problems[:3], 1):  # Show first 3 problems
                context_parts.append(f"Problem {i}: {problem.get('title', 'Unknown')} (Severity: {problem.get('severity', 0)})")
        
        # Conversation history
        if conversation.get('messages'):
            context_parts.append("\nPrevious Conversation:")
            for msg in conversation['messages'][-5:]:  # Last 5 messages
                sender = "User" if msg['sender'] == 'user' else "Assistant"
                context_parts.append(f"{sender}: {msg['content']}")
        
        return "\n".join(context_parts)
    
    def get_conversation_history(self, conversation_id: str, user_id: str) -> List[Dict]:
        """Get conversation history"""
        try:
            conversation = self.get_conversation(conversation_id, user_id)
            if not conversation:
                return []
            
            return conversation.get('messages', [])
            
        except Exception as e:
            print(f"Error getting conversation history: {e}")
            return []
