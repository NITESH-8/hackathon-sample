import bcrypt
import jwt
import uuid
from datetime import datetime, timedelta
from typing import Dict, Optional
import os

class AuthManager:
    def __init__(self):
        self.secret_key = os.getenv('JWT_SECRET', 'your-secret-key-change-in-production')
        self.algorithm = 'HS256'
        self.token_expiry = timedelta(hours=24)
    
    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def generate_token(self, user_id: str, team_id: str) -> str:
        """Generate JWT token"""
        payload = {
            'user_id': user_id,
            'team_id': team_id,
            'exp': datetime.utcnow() + self.token_expiry,
            'iat': datetime.utcnow()
        }
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def verify_token(self, token: str) -> Optional[Dict]:
        """Verify and decode JWT token"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return {
                'user_id': payload['user_id'],
                'team_id': payload['team_id']
            }
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def signup(self, userid: str, password: str, teamid: str) -> Dict:
        """Register a new user"""
        try:
            # Check if user already exists
            from .database import DatabaseManager
            db = DatabaseManager()
            
            if db.user_exists(userid):
                return {'success': False, 'error': 'User already exists'}
            
            # Create user
            user_id = str(uuid.uuid4())
            password_hash = self.hash_password(password)
            
            user_data = {
                'user_id': user_id,
                'userid': userid,
                'team_id': teamid,
                'password_hash': password_hash,
                'roles': ['user'],
                'status': 'active',
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat(),
                'last_login_at': None
            }
            
            result = db.create_user(user_data)
            if result['success']:
                return {'success': True, 'user_id': user_id}
            else:
                return {'success': False, 'error': result['error']}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def login(self, userid: str, password: str) -> Dict:
        """Authenticate user login"""
        try:
            from .database import DatabaseManager
            db = DatabaseManager()
            
            # Get user data
            user_data = db.get_user_by_userid(userid)
            if not user_data:
                return {'success': False, 'error': 'Invalid credentials'}
            
            # Verify password
            if not self.verify_password(password, user_data['password_hash']):
                return {'success': False, 'error': 'Invalid credentials'}
            
            # Check if user is active
            if user_data['status'] != 'active':
                return {'success': False, 'error': 'Account is disabled'}
            
            # Update last login
            db.update_last_login(user_data['user_id'])
            
            # Generate token
            token = self.generate_token(user_data['user_id'], user_data['team_id'])
            
            return {
                'success': True,
                'user_id': user_data['user_id'],
                'team_id': user_data['team_id'],
                'token': token
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
