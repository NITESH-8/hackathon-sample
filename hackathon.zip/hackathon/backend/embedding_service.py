import numpy as np
from typing import List, Dict, Any
import os
import pickle
from datetime import datetime
import hashlib

class EmbeddingService:
    def __init__(self):
        # Lightweight hashing-based embeddings by default
        self.model_name = 'lightweight-hash-embeddings-v1'
        self.model = None
        self.embedding_cache: Dict[str, List[float]] = {}
        self.cache_file = 'embedding_cache.pkl'
        try:
            self.embedding_dimensions = int(os.getenv('EMBEDDING_DIMS', '384'))
        except Exception:
            self.embedding_dimensions = 384
        self.skip_chunk_embeddings = os.getenv('SKIP_CHUNK_EMBEDDINGS', 'false').lower() in ('1', 'true', 'yes')
        self._load_model()
        self._load_cache()
    
    def _load_model(self):
        """Use lightweight embeddings; no heavy model to load."""
        self.model = None
        print(f"EmbeddingService initialized with {self.model_name} ({self.embedding_dimensions} dims)")
    
    def _load_cache(self):
        """Load embedding cache from disk"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'rb') as f:
                    self.embedding_cache = pickle.load(f)
                print(f"Loaded embedding cache with {len(self.embedding_cache)} entries")
        except Exception as e:
            print(f"Error loading embedding cache: {e}")
            self.embedding_cache = {}
    
    def _save_cache(self):
        """Save embedding cache to disk"""
        try:
            with open(self.cache_file, 'wb') as f:
                pickle.dump(self.embedding_cache, f)
        except Exception as e:
            print(f"Error saving embedding cache: {e}")
    
    def generate_embeddings(self, file_path: str) -> Dict[str, Any]:
        """
        Stage 5: Generate embeddings for processed log file
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            record_embedding = self._get_embedding(content)
            chunk_embeddings = [] if self.skip_chunk_embeddings else self._generate_chunk_embeddings(content)
            
            return {
                'record_embedding': record_embedding,
                'chunk_embeddings': chunk_embeddings,
                'embedding_model': self.model_name,
                'generated_at': datetime.now().isoformat()
            }
        except Exception as e:
            print(f"Error generating embeddings: {e}")
            return {
                'record_embedding': None,
                'chunk_embeddings': [],
                'error': str(e)
            }
    
    def _cache_key(self, text: str) -> str:
        return hashlib.sha256((self.model_name + '\n' + text).encode('utf-8')).hexdigest()
    
    def _get_embedding(self, text: str) -> List[float]:
        """Get embedding for a single text using fast hashing-TF approach"""
        cache_key = self._cache_key(text)
        if cache_key in self.embedding_cache:
            return self.embedding_cache[cache_key]

        dims = self.embedding_dimensions or 384
        vec = np.zeros(dims, dtype=np.float32)

        words = text.lower().split()
        total = max(1, len(words))
        for word in words:
            if len(word) < 3:
                continue
            h = hash(word)
            # Write into multiple positions for dispersion
            for i in range(8):
                idx = (h + (0x9e3779b97f4a7c15 * i)) % dims
                vec[idx] += 1.0 / total

        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm

        embedding_list: List[float] = vec.astype(float).tolist()
        self.embedding_cache[cache_key] = embedding_list
        self._save_cache()
        return embedding_list
    
    def _generate_chunk_embeddings(self, content: str) -> List[Dict[str, Any]]:
        """Generate embeddings for chunks of the content"""
        try:
            lines = content.split('\n')
            chunks: List[str] = []
            current_chunk: List[str] = []

            for line in lines:
                if line.startswith('CHUNK') or line.startswith('RAW:'):
                    if current_chunk:
                        chunks.append('\n'.join(current_chunk))
                        current_chunk = []
                    current_chunk.append(line)
                else:
                    current_chunk.append(line)

            if current_chunk:
                chunks.append('\n'.join(current_chunk))

            non_empty_chunks = [c for c in chunks if c.strip()]
            embeddings = [self._get_embedding(c) for c in non_empty_chunks] if non_empty_chunks else []

            result: List[Dict[str, Any]] = []
            emb_idx = 0
            for i, chunk in enumerate(chunks):
                if not chunk.strip():
                    continue
                embedding = embeddings[emb_idx] if emb_idx < len(embeddings) else self._get_embedding(chunk)
                emb_idx += 1
                result.append({
                    'chunk_id': f"chunk_{i}",
                    'text': chunk,
                    'embedding': embedding,
                    'is_error_window': 'ERROR DETECTED' in chunk or 'RAW:' in chunk
                })

            return result
        except Exception as e:
            print(f"Error generating chunk embeddings: {e}")
            return []
    
    def compute_similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        """Compute cosine similarity between two embeddings"""
        try:
            vec1 = np.array(embedding1, dtype=np.float32)
            vec2 = np.array(embedding2, dtype=np.float32)
            if vec1.size == 0 or vec2.size == 0:
                return 0.0
            if vec1.shape != vec2.shape:
                min_dim = min(vec1.size, vec2.size)
                vec1 = vec1[:min_dim]
                vec2 = vec2[:min_dim]
            dot_product = float(np.dot(vec1, vec2))
            norm1 = float(np.linalg.norm(vec1))
            norm2 = float(np.linalg.norm(vec2))
            return dot_product / (norm1 * norm2) if norm1 and norm2 else 0.0
        except Exception:
            return 0.0
    
    def batch_embeddings(self, texts: List[str]) -> List[List[float]]:
        return [self._get_embedding(text) for text in texts]
    
    def get_embedding_stats(self) -> Dict[str, Any]:
        return {
            'model_name': self.model_name,
            'cache_size': len(self.embedding_cache),
            'model_loaded': True,
            'embedding_dimensions': self.embedding_dimensions
        }
