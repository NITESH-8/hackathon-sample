import os
import uuid
import re
from typing import List, Dict, Tuple, Any
from datetime import datetime
import shutil
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from processor_enhanced import detect_errors_enhanced, ErrorDetection, ErrorSeverity, ErrorCategory
from summarizer import summarize_chunk
from processor import is_problem_chunk, categorize_errors, extract_error_context

class LogProcessor:
    def __init__(self):
        self.upload_folder = 'uploads'
        self.processed_folder = 'processed'
        os.makedirs(self.upload_folder, exist_ok=True)
        os.makedirs(self.processed_folder, exist_ok=True)
        # Configurable chunking for speed/quality tradeoff
        fast_mode = os.getenv('FAST_MODE', 'false').lower() in ('1', 'true', 'yes')
        env_chunk = os.getenv('CHUNK_SIZE')
        env_window = os.getenv('ERROR_WINDOW_SIZE')
        try:
            # Use much larger chunks in fast mode for fewer iterations
            self.chunk_size = int(env_chunk) if env_chunk else (80 if fast_mode else 5)
        except Exception:
            self.chunk_size = 80 if fast_mode else 5
        try:
            # Minimal error window in fast mode
            self.error_window_size = int(env_window) if env_window else (1 if fast_mode else 5)
        except Exception:
            self.error_window_size = 1 if fast_mode else 5
    
    def process_log_file(self, file_path: str, user_id: str, team_id: str, context: str = '') -> str:
        """
        Stage 4: Log Reduction (Preprocessing Only)
        Clean and reduce raw log file - no analysis, just preprocessing
        Returns path to processed file with cleaned logs
        """
        try:
            from time import perf_counter
            t0 = perf_counter()
            # Generate unique output filename
            output_id = str(uuid.uuid4())
            output_path = os.path.join(self.processed_folder, f"processed_{output_id}.txt")
            
            # Read raw file
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # Get file statistics
            file_size = os.path.getsize(file_path)
            file_name = os.path.basename(file_path)
            
            # Process the log file using enhanced processor
            t1 = perf_counter()
            processed_lines = self._process_log_lines(lines, context)
            t2 = perf_counter()
            
            # Write processed output (clean preprocessed logs only)
            with open(output_path, 'w', encoding='utf-8') as out:
                # Write simple header
                out.write(f"# Processed Log File: {file_name}\n")
                out.write(f"# User: {user_id} | Team: {team_id}\n")
                out.write(f"# Context: {context}\n")
                out.write(f"# Size: {file_size / 1024:.2f} KB | Lines: {len(lines)} -> {len(processed_lines)}\n")
                out.write(f"# Generated: {datetime.now().isoformat()}\n")
                out.write(f"# Timing: read={(t1-t0):.3f}s, preprocess={(t2-t1):.3f}s, total={(perf_counter()-t0):.3f}s\n")
                out.write("#" + "-" * 80 + "\n\n")
                
                # Write clean preprocessed lines
                for line in processed_lines:
                    out.write(line + "\n")
            
            return output_path
            
        except Exception as e:
            print(f"Error processing log file: {e}")
            raise e
    
    def _process_log_lines(self, lines: List[str], context: str) -> List[str]:
        """Process log lines with chunk-based preprocessing, error detection, and summaries"""
        processed_lines = []
        chunk_size = self.chunk_size
        error_window_size = self.error_window_size
        # Keep a rolling memory of recently emitted error signatures to prevent repeats
        recent_error_signatures: List[str] = []
        recent_capacity = 12  # remember last N error signatures
        # Buffer to collapse consecutive, template-identical summaries
        pending_summary_sig: str = ''
        pending_summary_text: str = ''
        pending_summary_count: int = 0
        
        # Process in chunks
        for i in range(0, len(lines), chunk_size):
            chunk = lines[i:i + chunk_size]
            
            # Clean the chunk first
            cleaned_chunk = []
            for line in chunk:
                line = line.strip()
                if line:
                    cleaned_line = self._clean_log_line(line)
                    if cleaned_line:
                        cleaned_chunk.append(cleaned_line)
            
            if not cleaned_chunk:
                continue
            
            # Detect errors using both enhanced detection and processor.py
            error_detection = detect_errors_enhanced(cleaned_chunk)
            is_problem, matching_keywords = is_problem_chunk(cleaned_chunk)
            
            # Use enhanced detection as primary, processor.py as backup
            has_errors = error_detection.is_error or is_problem
            
            if has_errors:
                # Flush any pending summary before emitting error block
                if pending_summary_count > 0:
                    line_to_add = f"CHUNK {(i // chunk_size)} - Summary: {pending_summary_text}"
                    if pending_summary_count > 1:
                        line_to_add += f"    (similar summaries repeated x{pending_summary_count})"
                    processed_lines.append(line_to_add)
                    pending_summary_sig = ''
                    pending_summary_text = ''
                    pending_summary_count = 0
                # For error chunks, preserve raw content with error window
                start_idx = max(0, i - error_window_size)
                end_idx = min(len(lines), i + chunk_size + error_window_size)
                error_window = lines[start_idx:end_idx]
                
                # Build a compact signature for deduplication (category + key patterns)
                error_signature = self._build_error_signature(error_detection, matching_keywords, cleaned_chunk)
                if error_signature in recent_error_signatures:
                    # Skip emitting duplicate error blocks appearing repeatedly nearby
                    continue

                # Create comprehensive error header
                error_header = self._create_comprehensive_error_header(
                    error_detection, matching_keywords, i // chunk_size + 1
                )
                processed_lines.append(error_header)
                
                # Add raw error content
                deduped = self._dedupe_consecutive_lines(error_window)
                for line, repeat in deduped:
                    if not line.strip():
                        continue
                    prefix = f"    {line.strip()}"
                    if repeat > 1:
                        processed_lines.append(prefix + f"    (repeated x{repeat})")
                    else:
                        processed_lines.append(prefix)
                
                processed_lines.append("")  # Empty line separator

                # Update recent signatures ring buffer
                recent_error_signatures.append(error_signature)
                if len(recent_error_signatures) > recent_capacity:
                    recent_error_signatures.pop(0)
            else:
                # For normal chunks, use enhanced summarizer
                summary = summarize_chunk(cleaned_chunk)
                # Template-normalize and collapse consecutive similar summaries
                summary_sig = self._build_summary_signature(summary)
                if pending_summary_sig and summary_sig == pending_summary_sig:
                    pending_summary_count += 1
                else:
                    # Flush previous pending summary (if any)
                    if pending_summary_count > 0:
                        prev_chunk_num = (i // chunk_size)  # previous chunk number
                        line_to_add = f"CHUNK {prev_chunk_num} - Summary: {pending_summary_text}"
                        if pending_summary_count > 1:
                            line_to_add += f"    (similar summaries repeated x{pending_summary_count})"
                        processed_lines.append(line_to_add)
                    # Start new pending summary
                    pending_summary_sig = summary_sig
                    pending_summary_text = summary
                    pending_summary_count = 1
        
        # Flush any remaining pending summary after processing all chunks
        if pending_summary_count > 0:
            # Compute final chunk number based on processed lines length is non-trivial; use sentinel 0
            line_to_add = f"CHUNK 0 - Summary: {pending_summary_text}"
            if pending_summary_count > 1:
                line_to_add += f"    (similar summaries repeated x{pending_summary_count})"
            processed_lines.append(line_to_add)

        return processed_lines
    
    def _clean_log_line(self, line: str) -> str:
        """Clean and normalize a single log line"""
        # Remove excessive whitespace
        line = ' '.join(line.split())
        
        # Normalize timestamps
        line = self._normalize_timestamps(line)
        
        # Normalize process IDs and addresses
        line = self._normalize_identifiers(line)
        
        # Normalize numbers (optional - can be enabled if needed)
        # line = self._normalize_numbers(line)
        
        return line

    def _build_error_signature(self, error_detection: ErrorDetection, matching_keywords: List[str], cleaned_chunk: List[str]) -> str:
        """Create a short signature string to detect repeated/duplicate error chunks.
        Uses category + top patterns + first normalized message token."""
        # Category
        category = error_detection.category.value if error_detection and error_detection.category else "UNKNOWN"
        # Patterns (top 3 from both sources)
        enhanced = (error_detection.matching_patterns or [])[:3]
        backup = (matching_keywords or [])[:3]
        patterns = sorted(set(enhanced + backup))
        # First message token from the chunk (helps distinguish different errors of same category)
        first_line = cleaned_chunk[0] if cleaned_chunk else ""
        first_token = first_line.split(' ', 1)[0]
        return f"{category}|{'|'.join(patterns)}|{first_token}"

    def _build_summary_signature(self, summary: str) -> str:
        """Create a compact signature for a summary line to suppress repeats."""
        import hashlib
        import re
        s = (summary or '').strip()
        if s.lower().startswith('summary:'):
            s = s[8:].strip()
        # Normalize dynamic tokens
        s = re.sub(r'\d{2,}_\d{2,}', 'SESSION', s)  # session ids like 30546354_3336883039
        s = re.sub(r'KB\d+', 'KB*', s, flags=re.IGNORECASE)  # KB identifiers
        s = re.sub(r'\d+\.\d+\.\d+(?:\.\d+)?', 'VER', s)  # version numbers
        s = re.sub(r'0x[0-9a-fA-F]+', '0xADDR', s)  # hex addresses
        s = re.sub(r'\d+', 'N', s)  # remaining numbers
        s = s.lower()
        return 'SUM|' + hashlib.sha1(s[:256].encode('utf-8')).hexdigest()

    def _dedupe_consecutive_lines(self, window_lines: List[str]) -> List[Tuple[str, int]]:
        """Collapse consecutive identical lines to reduce noise.
        Returns list of (line, repeat_count)."""
        collapsed: List[Tuple[str, int]] = []
        prev = None
        count = 0
        for raw in window_lines:
            line = (raw or '').rstrip('\n')
            if prev is None:
                prev = line
                count = 1
                continue
            if line == prev:
                count += 1
            else:
                collapsed.append((prev, count))
                prev = line
                count = 1
        if prev is not None:
            collapsed.append((prev, count))
        return collapsed
    
    def _normalize_timestamps(self, line: str) -> str:
        """Normalize timestamps to reduce variation"""
        import re
        
        # Replace various timestamp formats with [TIME]
        timestamp_patterns = [
            r'\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\]',  # [2024-01-15 10:30:45]
            r'\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?',  # 2024-01-15 10:30:45
            r'\d{2}:\d{2}:\d{2}(?:\.\d+)?',  # 10:30:45
            r'\[\s*\d+\.\d+\]',  # [123.456]
            r'\[\s*\d+\]',  # [123]
            r'Jan \d+ \d{2}:\d{2}:\d{2}',  # Jan 15 10:30:45
            r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}'  # 01/15/2024 10:30:45
        ]
        
        for pattern in timestamp_patterns:
            line = re.sub(pattern, '[TIME]', line)
        
        return line
    
    def _normalize_identifiers(self, line: str) -> str:
        """Normalize process IDs, memory addresses, etc."""
        import re
        
        # Replace process IDs
        line = re.sub(r'\[\d+\]', '[PID]', line)
        line = re.sub(r'process \d+', 'process PID', line)
        line = re.sub(r'PID \d+', 'PID', line)
        
        # Replace memory addresses
        line = re.sub(r'0x[0-9a-fA-F]+', '0xADDR', line)
        
        # Replace file paths (optional)
        line = re.sub(r'/[a-zA-Z0-9_/.-]+', '/PATH', line)
        
        return line
    
    def _create_comprehensive_error_header(self, error_detection: ErrorDetection, matching_keywords: List[str], chunk_num: int) -> str:
        """Create comprehensive error header combining enhanced detection and processor.py categorization"""
        # Get patterns from both sources
        enhanced_patterns = error_detection.matching_patterns[:3] if error_detection.matching_patterns else []
        processor_patterns = matching_keywords[:3] if matching_keywords else []
        
        # Combine and deduplicate patterns
        all_patterns = list(set(enhanced_patterns + processor_patterns))[:3]
        patterns_str = ", ".join(all_patterns) if all_patterns else "Unknown"
        
        # Get category from enhanced detection, fallback to processor.py categorization
        if error_detection.category != ErrorCategory.UNKNOWN:
            category = error_detection.category.value
        else:
            categories = categorize_errors(matching_keywords)
            category = ", ".join(categories[:2]) if categories else "Unknown"
        
        # Create header
        header = f"CHUNK {chunk_num} - ERROR DETECTED [{category}]"
        details = f"Patterns: {patterns_str}"
        
        # Add context from enhanced detection
        context = f"Context: {error_detection.error_context}" if error_detection.error_context != "No specific context" else ""
        
        if context:
            return f"{header}\n{details}\n{context}"
        else:
            return f"{header}\n{details}"
    
    def test_processing(self, test_log_content: str) -> str:
        """Test the log processing with sample content (integrated from simple_test.py)"""
        try:
            # Create temporary test file
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.log') as f:
                f.write(test_log_content)
                temp_file = f.name
            
            # Process the test file
            result = self.process_log_file(temp_file, 'test_user', 'test_team', 'Test processing')
            
            # Read and return the result
            with open(result, 'r') as f:
                content = f.read()
            
            # Clean up
            import os
            os.unlink(temp_file)
            os.unlink(result)
            
            return content
            
        except Exception as e:
            return f"Test failed: {str(e)}"
    
    def get_processing_stats(self, file_path: str) -> Dict[str, Any]:
        """Get statistics about the processed file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Count different types of lines
            total_lines = len(lines)
            chunk_lines = sum(1 for line in lines if line.startswith("CHUNK"))
            error_lines = sum(1 for line in lines if "ERROR DETECTED" in line)
            raw_lines = sum(1 for line in lines if line.startswith("RAW:"))
            
            # Calculate reduction ratio
            reduction_ratio = (total_lines - raw_lines) / total_lines if total_lines > 0 else 0
            
            return {
                'total_lines': total_lines,
                'chunk_lines': chunk_lines,
                'error_lines': error_lines,
                'raw_lines': raw_lines,
                'reduction_ratio': reduction_ratio,
                'file_size_kb': os.path.getsize(file_path) / 1024
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract_problems(self, file_path: str) -> List[Dict[str, Any]]:
        """Extract problems from processed log file"""
        problems = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            current_problem = None
            line_number = 0
            
            for line in lines:
                line_number += 1
                line = line.strip()
                
                if "ERROR DETECTED" in line:
                    # Start of new problem
                    if current_problem:
                        problems.append(current_problem)
                    
                    # Parse error header
                    parts = line.split(" - ")
                    if len(parts) >= 2:
                        chunk_info = parts[0].strip()
                        error_info = parts[1].strip()
                        
                        # Extract severity and category
                        severity = "MEDIUM"
                        category = "UNKNOWN"
                        
                        if "CRITICAL" in error_info:
                            severity = "CRITICAL"
                        elif "HIGH" in error_info:
                            severity = "HIGH"
                        elif "LOW" in error_info:
                            severity = "LOW"
                        elif "INFO" in error_info:
                            severity = "INFO"
                        
                        if "SYSTEM]" in error_info:
                            category = "SYSTEM"
                        elif "MEMORY]" in error_info:
                            category = "MEMORY"
                        elif "NETWORK]" in error_info:
                            category = "NETWORK"
                        elif "DATABASE]" in error_info:
                            category = "DATABASE"
                        elif "SECURITY]" in error_info:
                            category = "SECURITY"
                        elif "APPLICATION]" in error_info:
                            category = "APPLICATION"
                        elif "HARDWARE]" in error_info:
                            category = "HARDWARE"
                        elif "KERNEL]" in error_info:
                            category = "KERNEL"
                        
                        current_problem = {
                            'problem_id': str(uuid.uuid4()),
                            'title': f"Error in {chunk_info}",
                            'severity': self._severity_to_int(severity),
                            'category': category,
                            'start_line': line_number,
                            'end_line': line_number,
                            'root_cause': '',
                            'signals': [],
                            'raw_content': []
                        }
                elif current_problem and line.startswith("RAW:"):
                    # Add raw content to current problem
                    current_problem['raw_content'].append(line[4:].strip())
                    current_problem['end_line'] = line_number
            
            # Add last problem if exists
            if current_problem:
                problems.append(current_problem)
            
            # Process problems to extract more details
            for problem in problems:
                problem['root_cause'] = self._extract_root_cause(problem['raw_content'])
                problem['signals'] = self._extract_signals(problem['raw_content'])
            
            return problems
            
        except Exception as e:
            print(f"Error extracting problems: {e}")
            return []
    
    def _severity_to_int(self, severity: str) -> int:
        """Convert severity string to integer (0-100)"""
        severity_map = {
            'CRITICAL': 90,
            'HIGH': 70,
            'MEDIUM': 50,
            'LOW': 30,
            'INFO': 10
        }
        return severity_map.get(severity, 50)
    
    def _extract_root_cause(self, raw_content: List[str]) -> str:
        """Extract root cause from raw content"""
        if not raw_content:
            return "No specific root cause identified"
        
        # Look for common root cause patterns
        root_cause_patterns = [
            r"root cause: (.+)",
            r"caused by: (.+)",
            r"reason: (.+)",
            r"because (.+)",
            r"due to (.+)"
        ]
        
        for line in raw_content:
            for pattern in root_cause_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    return match.group(1).strip()
        
        # Fallback to first line if no pattern matches
        return raw_content[0][:100] + "..." if len(raw_content[0]) > 100 else raw_content[0]
    
    def _extract_signals(self, raw_content: List[str]) -> List[str]:
        """Extract error signals from raw content"""
        signals = []
        signal_patterns = [
            r"panic", r"fatal", r"critical", r"error", r"exception",
            r"timeout", r"failed", r"abort", r"crash", r"segfault",
            r"oom", r"deadlock", r"corruption", r"leak"
        ]
        
        for line in raw_content:
            line_lower = line.lower()
            for pattern in signal_patterns:
                if re.search(pattern, line_lower):
                    signals.append(pattern)
        
        return list(set(signals))
