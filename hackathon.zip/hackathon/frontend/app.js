// Log Analysis System Frontend JavaScript

class LogAnalysisApp {
    constructor() {
        this.apiBase = 'http://localhost:5000';
        this.token = localStorage.getItem('auth_token');
        this.currentUser = null;
        this.currentRecord = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkAuthStatus();
    }

    setupEventListeners() {
        // Auth forms
        document.getElementById('login-form').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('signup-form').addEventListener('submit', (e) => this.handleSignup(e));
        
        // Navigation
        document.getElementById('show-signup').addEventListener('click', (e) => this.showSignup(e));
        document.getElementById('show-login').addEventListener('click', (e) => this.showLogin(e));
        
        // Upload form
        document.getElementById('upload-form').addEventListener('submit', (e) => this.handleUpload(e));
        
        // Visibility filters
        document.querySelectorAll('[data-visibility]').forEach(btn => {
            btn.addEventListener('click', (e) => this.filterRecords(e));
        });
        
        // Modals
        document.getElementById('analyze-btn').addEventListener('click', () => this.analyzeRecord());
        document.getElementById('ask-question-btn').addEventListener('click', () => this.askQuestion());
        document.getElementById('history-link').addEventListener('click', (e) => { e.preventDefault(); this.openHistory(); });
    }

    checkAuthStatus() {
        if (this.token) {
            this.loadProfile();
        } else {
            this.showLogin();
        }
    }

    async loadProfile() {
        try {
            const response = await this.apiCall('/profile/me');
            this.currentUser = response.profile;
            this.showDashboard();
            this.loadRecords();
            this.loadConversations();
        } catch (error) {
            console.error('Error loading profile:', error);
            this.logout();
        }
    }

    showLogin() {
        document.getElementById('login-section').style.display = 'block';
        document.getElementById('signup-section').style.display = 'none';
        document.getElementById('dashboard-section').style.display = 'none';
        document.getElementById('nav-links').innerHTML = `
            <a class="nav-link" href="#" id="login-link">Login</a>
            <a class="nav-link" href="#" id="show-signup">Sign Up</a>
        `;
    }

    showSignup(e) {
        e.preventDefault();
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('signup-section').style.display = 'block';
        document.getElementById('dashboard-section').style.display = 'none';
    }

    showLogin(e) {
        if (e) e.preventDefault();
        document.getElementById('login-section').style.display = 'block';
        document.getElementById('signup-section').style.display = 'none';
        document.getElementById('dashboard-section').style.display = 'none';
    }

    showDashboard() {
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('signup-section').style.display = 'none';
        document.getElementById('dashboard-section').style.display = 'block';
        
        // Update profile display
        document.getElementById('profile-userid').textContent = this.currentUser.userid || this.currentUser.user_id || 'N/A';
        document.getElementById('profile-teamid').textContent = this.currentUser.team_id || 'N/A';
        document.getElementById('profile-last-login').textContent = 
            this.currentUser.last_login_at ? new Date(this.currentUser.last_login_at).toLocaleString() : 'Never';
        
        // Update nav
        document.getElementById('nav-links').innerHTML = `
            <a class="nav-link" href="#" id="history-link"><i class="fas fa-clock me-1"></i>Log History</a>
            <a class="nav-link" href="#" onclick="app.logout()">Logout</a>
        `;
        // Re-bind history link after DOM replacement
        const historyEl = document.getElementById('history-link');
        if (historyEl) {
            historyEl.addEventListener('click', (e) => { e.preventDefault(); this.openHistory(); });
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        const userid = document.getElementById('login-userid').value;
        const password = document.getElementById('login-password').value;

        try {
            const response = await this.apiCall('/auth/login', 'POST', { userid, password });
            this.token = response.token;
            localStorage.setItem('auth_token', this.token);
            this.currentUser = { userid, team_id: response.team_id };
            this.loadProfile();
        } catch (error) {
            this.showAlert('Login failed: ' + error.message, 'danger');
        }
    }

    async handleSignup(e) {
        e.preventDefault();
        const userid = document.getElementById('signup-userid').value;
        const password = document.getElementById('signup-password').value;
        const teamid = document.getElementById('signup-teamid').value;

        try {
            await this.apiCall('/auth/signup', 'POST', { userid, password, teamid });
            this.showAlert('Account created successfully! Please login.', 'success');
            this.showLogin();
        } catch (error) {
            this.showAlert('Signup failed: ' + error.message, 'danger');
        }
    }

    async handleUpload(e) {
        e.preventDefault();
        const fileInput = document.getElementById('log-file');
        const context = document.getElementById('log-context').value;

        if (!fileInput.files[0]) {
            this.showAlert('Please select a file', 'warning');
            return;
        }

        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('context', context);

        try {
            const response = await this.apiCall('/records', 'POST', formData, true);
            this.showProcessingStatus(response.job_id);
            this.startJobPolling(response.job_id);
        } catch (error) {
            this.showAlert('Upload failed: ' + error.message, 'danger');
        }
    }

    showProcessingStatus(jobId) {
        document.getElementById('processing-status').style.display = 'block';
        document.getElementById('progress-bar').style.width = '0%';
        document.getElementById('processing-message').textContent = 'Processing your log file...';
        document.getElementById('processing-details').innerHTML = '';
    }

    async startJobPolling(jobId) {
        const pollInterval = setInterval(async () => {
            try {
                const job = await this.apiCall(`/jobs/${jobId}`);
                
                document.getElementById('progress-bar').style.width = job.progress + '%';
                document.getElementById('processing-message').textContent = 
                    `Processing... ${job.progress}% complete`;
                
                if (job.status === 'completed') {
                    clearInterval(pollInterval);
                    document.getElementById('processing-status').style.display = 'none';
                    this.showAlert('Log processing completed successfully!', 'success');
                    this.loadRecords();
                } else if (job.status === 'failed') {
                    clearInterval(pollInterval);
                    document.getElementById('processing-status').style.display = 'none';
                    this.showAlert('Processing failed: ' + job.error, 'danger');
                }
            } catch (error) {
                clearInterval(pollInterval);
                document.getElementById('processing-status').style.display = 'none';
                this.showAlert('Error checking job status: ' + error.message, 'danger');
            }
        }, 2000);
    }

    async loadRecords(visibility = 'all') {
        try {
            const response = await this.apiCall(`/records?visibility=${visibility}`);
            this.displayRecords(response.records);
        } catch (error) {
            console.error('Error loading records:', error);
            document.getElementById('records-list').innerHTML = 
                '<div class="alert alert-danger">Error loading records</div>';
        }
    }

    displayRecords(records) {
        const container = document.getElementById('records-list');
        
        if (records.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-file-alt"></i>
                    <h5>No records found</h5>
                    <p>Upload a log file to get started</p>
                </div>
            `;
            return;
        }

        container.innerHTML = records.map(record => `
            <div class="record-item fade-in" data-record-id="${record.record_id}">
                <div class="record-title">${record.title || 'Untitled'}</div>
                <div class="record-summary">${record.overall_summary || 'No summary available'}</div>
                <div class="record-meta">
                    <div>
                        <span class="severity-badge severity-${this.getSeverityClass(record.overall_severity)}">
                            ${this.getSeverityText(record.overall_severity)}
                        </span>
                        ${record.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                    <div>
                        <small class="text-muted">${new Date(record.created_at).toLocaleDateString()}</small>
                        <button class="btn btn-sm btn-outline-primary ms-2" onclick="app.viewRecord('${record.record_id}')">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    getSeverityClass(severity) {
        if (severity >= 90) return 'critical';
        if (severity >= 70) return 'high';
        if (severity >= 50) return 'medium';
        if (severity >= 20) return 'low';
        return 'normal';
    }

    getSeverityText(severity) {
        if (severity >= 90) return 'Critical';
        if (severity >= 70) return 'High';
        if (severity >= 50) return 'Medium';
        if (severity >= 20) return 'Low';
        return 'Normal';
    }

    async viewRecord(recordId) {
        try {
            const record = await this.apiCall(`/records/${recordId}`);
            this.currentRecord = record;
            this.displayRecordDetails(record);
            new bootstrap.Modal(document.getElementById('record-modal')).show();
            // Load similar records (>80%) after opening
            this.loadSimilarRecords(record.record_id);
        } catch (error) {
            this.showAlert('Error loading record: ' + error.message, 'danger');
        }
    }

    displayRecordDetails(record) {
        document.getElementById('record-modal-title').textContent = record.title || 'Record Details';
        
        const details = document.getElementById('record-details');
        const analyzed = !!(record.genapi && record.genapi.analyzed);
        const problemsCount = analyzed && record.genapi && Array.isArray(record.genapi.problems)
            ? record.genapi.problems.length : '-';

        const summaryBlock = analyzed
            ? `<div class="mt-3">
                    <h6>Summary</h6>
                    <p>${record.genapi.summary || record.overall_summary || 'No summary available'}</p>
               </div>`
            : `<div class="mt-3">
                    <h6>Summary</h6>
                    <div class="text-muted">Preprocessed only. Run "Analyze with GenAPI" to generate a final summary.</div>
               </div>`;

        const problemsBlock = analyzed && record.genapi && Array.isArray(record.genapi.problems) && record.genapi.problems.length > 0
            ? `<div class="mt-3">
                    <h6>Problems Detected</h6>
                    ${record.genapi.problems.map(problem => `
                        <div class="problem-item">
                            <div class="problem-title">${problem.title}</div>
                            <div class="problem-details">
                                <p><strong>Severity:</strong> ${problem.severity}/100</p>
                                <p><strong>Root Cause:</strong> ${problem.root_cause || 'Not specified'}</p>
                                <p><strong>Signals:</strong> ${problem.signals?.join(', ') || 'None'}</p>
                            </div>
                        </div>
                    `).join('')}
               </div>`
            : '';

        details.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Basic Information</h6>
                    <p><strong>Title:</strong> ${record.title || 'Untitled'}</p>
                    <p><strong>Severity:</strong> 
                        <span class="severity-badge severity-${this.getSeverityClass(record.overall_severity)}">
                            ${this.getSeverityText(record.overall_severity)}
                        </span>
                    </p>
                    <p><strong>Created:</strong> ${new Date(record.created_at).toLocaleString()}</p>
                    <p><strong>Visibility:</strong> ${record.visibility}</p>
                </div>
                <div class="col-md-6">
                    <h6>Statistics</h6>
                    <p><strong>Raw Lines:</strong> ${record.raw_stats?.line_count || 0}</p>
                    <p><strong>Processed Lines:</strong> ${record.processed_stats?.line_count || 0}</p>
                    <p><strong>File Size:</strong> ${(record.raw_stats?.size_bytes || 0) / 1024} KB</p>
                    <p><strong>Problems Found:</strong> ${problemsCount}</p>
                </div>
            </div>
            
            ${summaryBlock}
            
            <div class="mt-3">
                <h6>Tags</h6>
                ${record.tags?.map(tag => `<span class="tag">${tag}</span>`).join('') || 'No tags'}
            </div>
            
            ${record.raw_file_path ? `
                <div class="mt-3">
                    <h6>Raw Log File</h6>
                    <a href="/download?path=${encodeURIComponent(record.raw_file_path)}" target="_blank" rel="noopener" class="btn btn-outline-primary">
                        <i class="fas fa-download me-2"></i>Download Raw Log
                    </a>
                </div>
            ` : ''}
            
            ${record.processed_content ? `
                <div class="mt-3">
                    <h6>Preprocessed Logs</h6>
                    <div class="preprocessed-logs">
                        <pre>${record.processed_content}</pre>
                    </div>
                </div>
            ` : ''}
            
            ${problemsBlock}
            
            <div class="mt-3">
                <button class="btn btn-primary" onclick="app.askQuestionModal()">
                    <i class="fas fa-question-circle me-2"></i>Ask a Question
                </button>
            </div>

            <div class="mt-4">
                <h6>Similar Records (≥ 80%)</h6>
                <div id="similar-records" class="text-muted">Loading...</div>
            </div>
        `;
    }

    async loadSimilarRecords(recordId) {
        try {
            const res = await this.apiCall(`/records/${recordId}/similar`);
            const list = (res.similar_records || []).filter(r => {
                const s = r.similarity_score;
                return (s > 1 ? s : s * 100) >= 80;
            }).sort((a, b) => {
                const scoreA = a.similarity_score > 1 ? a.similarity_score : a.similarity_score * 100;
                const scoreB = b.similarity_score > 1 ? b.similarity_score : b.similarity_score * 100;
                return scoreB - scoreA;
            });
            
            const container = document.getElementById('similar-records');
            if (!container) return;
            
            if (!list.length) {
                container.textContent = 'No similar records ≥ 80%.';
                return;
            }
            
            const visibleItems = list.slice(0, 3);
            const hiddenItems = list.slice(3);
            
            const visibleHtml = visibleItems.map(item => {
                const pct = (item.similarity_score > 1 ? item.similarity_score : item.similarity_score * 100).toFixed(1);
                return `<li><a href="#" onclick="app.viewRecord('${item.record_id}')">${item.record_id}</a> — ${pct}%</li>`;
            }).join('');
            
            const hiddenHtml = hiddenItems.map(item => {
                const pct = (item.similarity_score > 1 ? item.similarity_score : item.similarity_score * 100).toFixed(1);
                return `<li><a href="#" onclick="app.viewRecord('${item.record_id}')">${item.record_id}</a> — ${pct}%</li>`;
            }).join('');
            
            container.innerHTML = `
                <ul class="mb-0">
                    ${visibleHtml}
                    ${hiddenItems.length > 0 ? `
                        <div id="similar-more" style="display: none;">
                            ${hiddenHtml}
                        </div>
                        <li>
                            <button class="btn btn-sm btn-link p-0" onclick="app.toggleSimilarRecords()" id="toggle-similar">
                                Show ${hiddenItems.length} more
                            </button>
                        </li>
                    ` : ''}
                </ul>
            `;
        } catch (e) {
            const container = document.getElementById('similar-records');
            if (container) container.textContent = 'Failed to load similar records.';
        }
    }

    async analyzeRecord() {
        if (!this.currentRecord) return;
        
        try {
            const response = await this.apiCall('/genapi/analyze', 'POST', {
                record_id: this.currentRecord.record_id,
                context: this.currentRecord.context || ''
            });
            
            this.displayAnalysisResults(response);
            new bootstrap.Modal(document.getElementById('analysis-modal')).show();
        } catch (error) {
            this.showAlert('Analysis failed: ' + error.message, 'danger');
        }
    }

    displayAnalysisResults(analysis) {
        const results = document.getElementById('analysis-results');
        results.innerHTML = `
            <div class="alert alert-info">
                <h6>Analysis Summary</h6>
                <p>${analysis.summary}</p>
            </div>
            
            ${analysis.problems && analysis.problems.length > 0 ? `
                <div class="mt-3">
                    <h6>Problems Found</h6>
                    ${analysis.problems.map(problem => `
                        <div class="problem-item">
                            <div class="problem-title">${problem.title}</div>
                            <div class="problem-details">
                                <p><strong>Severity:</strong> ${problem.severity}/100</p>
                                <p><strong>Root Cause:</strong> ${problem.root_cause || 'Not specified'}</p>
                                <p><strong>Recommendations:</strong> ${problem.recommendations || 'None'}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            ` : '<div class="alert alert-success">No problems detected!</div>'}
            
            ${analysis.key_insights && analysis.key_insights.length > 0 ? `
                <div class="mt-3">
                    <h6>Key Insights</h6>
                    <ul>
                        ${analysis.key_insights.map(insight => `<li>${insight}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
            
            ${analysis.recommendations && analysis.recommendations.length > 0 ? `
                <div class="mt-3">
                    <h6>Recommendations</h6>
                    <ul>
                        ${analysis.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
        `;
    }

    askQuestionModal() {
        document.getElementById('question-input').value = '';
        document.getElementById('question-response').style.display = 'none';
        new bootstrap.Modal(document.getElementById('question-modal')).show();
    }

    async askQuestion() {
        const question = document.getElementById('question-input').value.trim();
        if (!question) {
            this.showAlert('Please enter a question', 'warning');
            return;
        }

        if (!this.currentRecord) {
            this.showAlert('No record selected', 'warning');
            return;
        }

        try {
            const response = await this.apiCall('/ask', 'POST', {
                record_id: this.currentRecord.record_id,
                question: question
            });
            
            document.getElementById('response-text').textContent = response.response;
            document.getElementById('question-response').style.display = 'block';
        } catch (error) {
            this.showAlert('Error asking question: ' + error.message, 'danger');
        }
    }

    async loadConversations() {
        try {
            const response = await this.apiCall('/profile/me');
            this.displayConversations(response.conversations || []);
        } catch (error) {
            console.error('Error loading conversations:', error);
        }
    }

    displayConversations(conversations) {
        const container = document.getElementById('conversations-list');
        
        if (conversations.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-comments"></i>
                    <h6>No conversations yet</h6>
                    <p>Start by asking questions about your log records</p>
                </div>
            `;
            return;
        }

        container.innerHTML = conversations.map(conv => `
            <div class="conversation-item">
                <h6>Conversation ${conv.conversation_id}</h6>
                <p class="text-muted">Last activity: ${new Date(conv.last_activity_at).toLocaleString()}</p>
                <div class="messages">
                    ${conv.messages?.slice(-2).map(msg => `
                        <div class="message ${msg.role}">
                            <div class="message-header">${msg.role === 'user' ? 'You' : 'Assistant'}</div>
                            <div>${msg.text}</div>
                        </div>
                    `).join('') || ''}
                </div>
            </div>
        `).join('');
    }

    // ===== Log History =====
    async openHistory() {
        try {
            // Fetch all records (admin-like view filtered by ACL on server)
            const data = await this.apiCall('/records?visibility=all');
            const records = data.records || [];

            // Build tag list
            const tagCounts = {};
            records.forEach(r => (r.tags || []).forEach(t => tagCounts[t] = (tagCounts[t] || 0) + 1));
            this.renderHistoryTags(tagCounts, records);
            this.renderHistoryTable(records);

            new bootstrap.Modal(document.getElementById('history-modal')).show();
        } catch (err) {
            this.showAlert('Failed to load history: ' + err.message, 'danger');
        }
    }

    renderHistoryTags(tagCounts, records) {
        const container = document.getElementById('history-tags');
        const tags = Object.keys(tagCounts).sort();
        if (tags.length === 0) {
            container.innerHTML = '<div class="text-muted">No tags available</div>';
            return;
        }
        container.innerHTML = '';
        const allBtn = document.createElement('button');
        allBtn.className = 'btn btn-sm btn-outline-primary me-2 mb-2';
        allBtn.textContent = `All (${records.length})`;
        allBtn.onclick = () => this.renderHistoryTable(records);
        container.appendChild(allBtn);

        tags.forEach(t => {
            const btn = document.createElement('button');
            btn.className = 'btn btn-sm btn-outline-secondary me-2 mb-2';
            btn.textContent = `${t} (${tagCounts[t]})`;
            btn.onclick = () => {
                const filtered = records.filter(r => (r.tags || []).includes(t));
                this.renderHistoryTable(filtered);
            };
            container.appendChild(btn);
        });
    }

    renderHistoryTable(records) {
        const tbody = document.querySelector('#history-table tbody');
        if (!records || records.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-4">No records</td></tr>';
            return;
        }
        const rows = records.map((r, index) => {
            const logId = r.record_id || '-';
            const owner = r.owner_user_id || r.user_id || r.userid || '-';
            const time = r.created_at ? new Date(r.created_at).toLocaleString() : '-';
            const rawDownload = r.raw_file_path ? `<a href=\"/download?path=${encodeURIComponent(r.raw_file_path)}\" target=\"_blank\" rel=\"noopener\" class=\"btn btn-sm btn-outline-primary\"><i class=\"fas fa-download\"></i> Download Raw</a>` : 'No file';
            const summary = (r.genapi && r.genapi.summary) ? r.genapi.summary.slice(0, 180) : (r.overall_summary || '').slice(0, 180);
            
            // Similarity with show more/less functionality
            let simBlock = '-';
            const similarItems = r.similar_items || [];
            const highSimilarity = similarItems
                .filter(it => (it.similarity_score > 1 ? it.similarity_score : it.similarity_score * 100) >= 80)
                .sort((a, b) => (b.similarity_score > 1 ? b.similarity_score : b.similarity_score * 100) - (a.similarity_score > 1 ? a.similarity_score : a.similarity_score * 100));
            
            if (highSimilarity.length > 0) {
                const visibleItems = highSimilarity.slice(0, 3);
                const hiddenItems = highSimilarity.slice(3);
                
                const visibleHtml = visibleItems.map(it => {
                    const pct = (it.similarity_score > 1 ? it.similarity_score : it.similarity_score * 100).toFixed(1);
                    return `<div><a href=\"#\" onclick=\"app.viewRecord('${it.record_id}')\">${it.record_id}</a> (${pct}%)</div>`;
                }).join('');
                
                const hiddenHtml = hiddenItems.map(it => {
                    const pct = (it.similarity_score > 1 ? it.similarity_score : it.similarity_score * 100).toFixed(1);
                    return `<div><a href=\"#\" onclick=\"app.viewRecord('${it.record_id}')\">${it.record_id}</a> (${pct}%)</div>`;
                }).join('');
                
                const showMoreId = `show-more-${index}`;
                const showLessId = `show-less-${index}`;
                
                simBlock = `
                    <div id="similarity-${index}">
                        ${visibleHtml}
                        ${hiddenItems.length > 0 ? `
                            <div id="${showMoreId}" style="display: none;">
                                ${hiddenHtml}
                            </div>
                            <button class="btn btn-sm btn-link p-0" onclick="app.toggleSimilarity('${index}')" id="toggle-${index}">
                                Show ${hiddenItems.length} more
                            </button>
                        ` : ''}
                    </div>
                `;
            } else if (r.similar_to) {
                const base = (r.similarity_pct != null) ? Number(r.similarity_pct).toFixed(1) : (r.similarity_score != null ? ((r.similarity_score > 1 ? r.similarity_score : r.similarity_score * 100).toFixed(1)) : null);
                simBlock = base ? `${base}% → <a href=\"#\" onclick=\"app.viewRecord('${r.similar_to}')\">${r.similar_to}</a>` : '-';
            }
            
            const tags = (r.tags || []).map(t => `<span class=\"tag\">${t}</span>`).join(' ');
            return `<tr>
                <td><a href=\"#\" onclick=\"app.viewRecord('${logId}')\">${logId}</a></td>
                <td>${owner}</td>
                <td>${time}</td>
                <td>${rawDownload}</td>
                <td>${summary}</td>
                <td>${simBlock}</td>
                <td>${tags}</td>
            </tr>`;
        }).join('');
        tbody.innerHTML = rows;
    }

    toggleSimilarity(index) {
        const showMoreDiv = document.getElementById(`show-more-${index}`);
        const toggleBtn = document.getElementById(`toggle-${index}`);
        
        if (showMoreDiv.style.display === 'none') {
            showMoreDiv.style.display = 'block';
            toggleBtn.textContent = 'Show less';
        } else {
            showMoreDiv.style.display = 'none';
            toggleBtn.textContent = toggleBtn.textContent.replace('less', 'more');
        }
    }

    toggleSimilarRecords() {
        const showMoreDiv = document.getElementById('similar-more');
        const toggleBtn = document.getElementById('toggle-similar');
        
        if (showMoreDiv.style.display === 'none') {
            showMoreDiv.style.display = 'block';
            toggleBtn.textContent = 'Show less';
        } else {
            showMoreDiv.style.display = 'none';
            toggleBtn.textContent = toggleBtn.textContent.replace('less', 'more');
        }
    }

    filterRecords(e) {
        e.preventDefault();
        const visibility = e.target.dataset.visibility;
        
        // Update button states
        document.querySelectorAll('[data-visibility]').forEach(btn => {
            btn.classList.remove('active');
        });
        e.target.classList.add('active');
        
        this.loadRecords(visibility);
    }

    async saveAnalysis() {
        // Implementation for saving analysis results
        this.showAlert('Analysis saved successfully!', 'success');
        bootstrap.Modal.getInstance(document.getElementById('analysis-modal')).hide();
    }

    async apiCall(endpoint, method = 'GET', data = null, isFormData = false) {
        const url = this.apiBase + endpoint;
        const options = {
            method,
            headers: {}
        };

        if (this.token) {
            options.headers['Authorization'] = `Bearer ${this.token}`;
        }

        if (data) {
            if (isFormData) {
                options.body = data;
            } else {
                options.headers['Content-Type'] = 'application/json';
                options.body = JSON.stringify(data);
            }
        }

        const response = await fetch(url, options);
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Request failed');
        }

        return await response.json();
    }

    showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.querySelector('.container').insertBefore(alertDiv, document.querySelector('.container').firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    logout() {
        this.token = null;
        this.currentUser = null;
        localStorage.removeItem('auth_token');
        this.showLogin();
    }
}

// Initialize the app
const app = new LogAnalysisApp();
