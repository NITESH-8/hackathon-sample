import React, { useState, useEffect, useRef } from 'react';
import { Modal, Button, Form, InputGroup, Spinner, Alert } from 'react-bootstrap';
import { toast } from 'react-toastify';
import ApiService from '../services/ApiService';

const ChatModal = ({ record, show, onHide }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (show && record) {
      loadConversation();
    }
  }, [show, record]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadConversation = async () => {
    if (!record) return;

    try {
      setLoadingHistory(true);
      const response = await ApiService.getConversation(record.record_id);
      setConversationId(response.conversation_id);
      setMessages(response.messages || []);
    } catch (error) {
      console.error('Failed to load conversation:', error);
      toast.error('Failed to load conversation: ' + error.message);
    } finally {
      setLoadingHistory(false);
    }
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || loading) return;

    const userMessage = {
      message_id: Date.now().toString(),
      content: newMessage.trim(),
      sender: 'user',
      timestamp: new Date().toISOString()
    };

    // Add user message immediately
    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setLoading(true);

    try {
      const response = await ApiService.sendChatMessage(conversationId, newMessage.trim());
      
      // Add AI response
      const aiMessage = {
        message_id: response.ai_message.message_id,
        content: response.ai_message.content,
        sender: 'assistant',
        timestamp: response.ai_message.timestamp
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Failed to send message:', error);
      toast.error('Failed to send message: ' + error.message);
      
      // Remove the user message if sending failed
      setMessages(prev => prev.filter(msg => msg.message_id !== userMessage.message_id));
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  const getInitialMessage = () => {
    if (!record) return '';
    
    return `Hi! I'm your AI assistant for this log analysis. I can help you understand:
• When this log was uploaded: ${new Date(record.created_at).toLocaleString()}
• What problems were found in the log
• Details about specific errors or issues
• General questions about the log content

What would you like to know about this log?`;
  };

  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <i className="fas fa-comments me-2"></i>
          Chat with AI - {record?.record_id || 'Log Analysis'}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ height: '500px', display: 'flex', flexDirection: 'column' }}>
        {loadingHistory ? (
          <div className="d-flex justify-content-center align-items-center h-100">
            <Spinner animation="border" />
            <span className="ms-2">Loading conversation...</span>
          </div>
        ) : (
          <>
            {/* Messages */}
            <div 
              className="flex-grow-1 overflow-auto mb-3 p-3 border rounded"
              style={{ maxHeight: '350px', backgroundColor: '#f8f9fa' }}
            >
              {messages.length === 0 ? (
                <div className="text-center text-muted">
                  <i className="fas fa-robot fa-2x mb-2"></i>
                  <p>{getInitialMessage()}</p>
                </div>
              ) : (
                messages.map((message) => (
                  <div
                    key={message.message_id}
                    className={`mb-3 d-flex ${message.sender === 'user' ? 'justify-content-end' : 'justify-content-start'}`}
                  >
                    <div
                      className={`p-3 rounded ${
                        message.sender === 'user'
                          ? 'bg-primary text-white'
                          : 'bg-white border'
                      }`}
                      style={{ maxWidth: '80%' }}
                    >
                      <div className="message-content">
                        {message.content.split('\n').map((line, index) => (
                          <div key={index}>{line}</div>
                        ))}
                      </div>
                      <small
                        className={`d-block mt-1 ${
                          message.sender === 'user' ? 'text-white-50' : 'text-muted'
                        }`}
                      >
                        {message.sender === 'user' ? 'You' : 'AI'} • {formatTime(message.timestamp)}
                      </small>
                    </div>
                  </div>
                ))
              )}
              {loading && (
                <div className="d-flex justify-content-start">
                  <div className="bg-white border p-3 rounded">
                    <Spinner size="sm" animation="border" />
                    <span className="ms-2">AI is thinking...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <Form onSubmit={sendMessage}>
              <InputGroup>
                <Form.Control
                  type="text"
                  placeholder="Ask a question about this log..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  disabled={loading}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage(e);
                    }
                  }}
                />
                <Button
                  type="submit"
                  variant="primary"
                  disabled={!newMessage.trim() || loading}
                >
                  {loading ? (
                    <Spinner size="sm" animation="border" />
                  ) : (
                    <i className="fas fa-paper-plane"></i>
                  )}
                </Button>
              </InputGroup>
            </Form>
          </>
        )}
      </Modal.Body>
      <Modal.Footer>
        <small className="text-muted">
          <i className="fas fa-info-circle me-1"></i>
          This conversation is saved and will persist when you close and reopen this chat.
        </small>
      </Modal.Footer>
    </Modal>
  );
};

export default ChatModal;
