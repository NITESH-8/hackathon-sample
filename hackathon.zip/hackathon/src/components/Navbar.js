import React from 'react';

const Navbar = ({ user, onLogout, onShowHistory }) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light navbar-custom">
      <div className="container-fluid">
        <a className="navbar-brand fw-bold text-primary" href="#">
          <i className="fas fa-chart-line me-2"></i>
          MediaTek's BugPredictor
        </a>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <a className="nav-link" href="#">
                <i className="fas fa-home me-1"></i>
                Dashboard
              </a>
            </li>
            <li className="nav-item">
              <button 
                className="nav-link btn btn-link text-decoration-none"
                onClick={onShowHistory}
              >
                <i className="fas fa-clock me-1"></i>
                Log History
              </button>
            </li>
          </ul>

          <ul className="navbar-nav">
            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle"
                href="#"
                id="navbarDropdown"
                role="button"
                data-bs-toggle="dropdown"
              >
                <i className="fas fa-user me-1"></i>
                {user?.userid || user?.user_id || 'User'}
              </a>
              <ul className="dropdown-menu dropdown-menu-end">
                <li>
                  <h6 className="dropdown-header">
                    <i className="fas fa-info-circle me-1"></i>
                    Profile Info
                  </h6>
                </li>
                <li>
                  <span className="dropdown-item-text">
                    <strong>User ID:</strong> {user?.userid || user?.user_id || 'N/A'}
                  </span>
                </li>
                <li>
                  <span className="dropdown-item-text">
                    <strong>Team:</strong> {user?.team_id || 'N/A'}
                  </span>
                </li>
                <li>
                  <span className="dropdown-item-text">
                    <strong>Last Login:</strong> {user?.last_login_at ? 
                      new Date(user.last_login_at).toLocaleString() : 'Never'}
                  </span>
                </li>
                <li><hr className="dropdown-divider" /></li>
                <li>
                  <button className="dropdown-item text-danger" onClick={onLogout}>
                    <i className="fas fa-sign-out-alt me-1"></i>
                    Logout
                  </button>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
