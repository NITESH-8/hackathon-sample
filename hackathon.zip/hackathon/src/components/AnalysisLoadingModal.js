import React from 'react';
import { Modal, ProgressBar, Spinner } from 'react-bootstrap';

const AnalysisLoadingModal = ({ show, progress, status, elapsedTime }) => {
  const formatTime = (seconds) => {
    if (seconds < 60) {
      return `${seconds}s`;
    }
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  return (
    <Modal show={show} centered backdrop="static" keyboard={false}>
      <Modal.Body className="text-center py-5">
        <div className="mb-4">
          <Spinner animation="border" variant="primary" size="lg" />
        </div>
        
        <h4 className="mb-3 text-primary">
          <i className="fas fa-brain me-2"></i>
          AI Analysis in Progress
        </h4>
        
        <p className="text-muted mb-4">
          Our AI is analyzing your log file to identify issues, patterns, and provide insights.
        </p>
        
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <small className="text-muted">Progress</small>
            <small className="text-muted">{Math.round(progress)}%</small>
          </div>
          <ProgressBar 
            now={progress} 
            variant="primary" 
            animated 
            style={{ height: '8px' }}
          />
        </div>
        
        {/* Status Message */}
        <div className="mb-4">
          <p className="mb-2 fw-bold text-primary">{status}</p>
          {elapsedTime && (
            <small className="text-muted">
              <i className="fas fa-clock me-1"></i>
              Elapsed time: {formatTime(elapsedTime)}
            </small>
          )}
        </div>
        
        {/* Analysis Steps */}
        <div className="row text-start">
          <div className="col-md-6">
            <div className="d-flex align-items-center mb-2">
              <i className={`fas fa-check-circle me-2 ${progress > 20 ? 'text-success' : 'text-muted'}`}></i>
              <small>Connecting to AI</small>
            </div>
            <div className="d-flex align-items-center mb-2">
              <i className={`fas fa-check-circle me-2 ${progress > 40 ? 'text-success' : 'text-muted'}`}></i>
              <small>Processing log content</small>
            </div>
            <div className="d-flex align-items-center mb-2">
              <i className={`fas fa-check-circle me-2 ${progress > 60 ? 'text-success' : 'text-muted'}`}></i>
              <small>Analyzing patterns</small>
            </div>
          </div>
          <div className="col-md-6">
            <div className="d-flex align-items-center mb-2">
              <i className={`fas fa-check-circle me-2 ${progress > 80 ? 'text-success' : 'text-muted'}`}></i>
              <small>Generating insights</small>
            </div>
            <div className="d-flex align-items-center mb-2">
              <i className={`fas fa-check-circle me-2 ${progress > 95 ? 'text-success' : 'text-muted'}`}></i>
              <small>Finalizing results</small>
            </div>
            <div className="d-flex align-items-center mb-2">
              <i className={`fas fa-check-circle me-2 ${progress === 100 ? 'text-success' : 'text-muted'}`}></i>
              <small>Complete</small>
            </div>
          </div>
        </div>
        
        {/* Tips */}
        <div className="mt-4 p-3 bg-light rounded">
          <small className="text-muted">
            <i className="fas fa-lightbulb me-1"></i>
            <strong>Tip:</strong> The AI is examining your log for errors, warnings, patterns, and potential issues to provide you with actionable insights.
          </small>
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default AnalysisLoadingModal;
