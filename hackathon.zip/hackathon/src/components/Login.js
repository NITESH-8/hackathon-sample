import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import AuthService from '../services/AuthService';

const Login = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    userid: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await AuthService.login(formData.userid, formData.password);
      onLogin(response);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <div className="auth-container">
        <div className="auth-card">
          <div className="text-center mb-5">
            <div className="mb-4">
              <div className="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary text-white" 
                   style={{ width: '80px', height: '80px', fontSize: '2rem' }}>
                <i className="fas fa-chart-line"></i>
              </div>
            </div>
            <h2 className="fw-bold mb-2" style={{ 
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
              MediaTek's BugPredictor
            </h2>
            <p className="text-muted fs-5">Sign in to your account</p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="userid" className="form-label">User ID</label>
              <input
                type="text"
                className="form-control"
                id="userid"
                name="userid"
                value={formData.userid}
                onChange={handleChange}
                required
                placeholder="Enter your user ID"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="password" className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="Enter your password"
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary w-100 mb-4 py-3"
              disabled={loading}
              style={{ fontSize: '1.1rem', fontWeight: '600' }}
            >
              {loading ? (
                <>
                  <span className="loading-spinner me-2"></span>
                  Signing In...
                </>
              ) : (
                <>
                  <i className="fas fa-sign-in-alt me-2"></i>
                  Sign In
                </>
              )}
            </button>

            <div className="text-center">
              <p className="mb-0">
                Don't have an account?{' '}
                <Link to="/signup" className="text-decoration-none">
                  Sign up here
                </Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
