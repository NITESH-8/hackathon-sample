import React, { useState, useEffect } from 'react';
import { Modal, Button, Table, Badge, Row, Col } from 'react-bootstrap';
import { toast } from 'react-toastify';
import ApiService from '../services/ApiService';

const LogHistory = ({ show, onHide, onViewRecord }) => {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [selectedTag, setSelectedTag] = useState('all');
  const [tagCounts, setTagCounts] = useState({});
  const [visibility, setVisibility] = useState('all');

  useEffect(() => {
    if (show) {
      loadRecords();
    }
  }, [show]);

  useEffect(() => {
    filterRecords();
  }, [records, selectedTag]);

  const loadRecords = async (visibilityLevel = visibility) => {
    try {
      setLoading(true);
      const response = await ApiService.getRecords(visibilityLevel);
      const recordsData = response.records || [];
      setRecords(recordsData);

      // Build tag counts
      const counts = { all: recordsData.length };
      recordsData.forEach(record => {
        (record.tags || []).forEach(tag => {
          counts[tag] = (counts[tag] || 0) + 1;
        });
      });
      setTagCounts(counts);
    } catch (error) {
      toast.error('Failed to load log history: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const filterRecords = () => {
    if (selectedTag === 'all') {
      setFilteredRecords(records);
    } else {
      const filtered = records.filter(record => 
        (record.tags || []).includes(selectedTag)
      );
      setFilteredRecords(filtered);
    }
  };

  const handleTagFilter = (tag) => {
    setSelectedTag(tag);
  };

  const handleDownload = async (filePath) => {
    try {
      await ApiService.downloadFile(filePath);
      toast.success('File download started');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Download failed: ' + error.message);
    }
  };

  // Ensure consistent local-time display even if ISO string lacks timezone
  const formatLocalTime = (ts) => {
    try {
      if (!ts) return '-';
      const hasZone = /Z|[+-]\d{2}:\d{2}$/.test(ts);
      const d = new Date(hasZone ? ts : ts + 'Z');
      if (isNaN(d.getTime())) return ts;
      return d.toLocaleString();
    } catch {
      return ts;
    }
  };


  return (
    <Modal 
      show={show} 
      onHide={onHide} 
      size="xl" 
      centered
      className="history-modal"
      style={{ 
        maxWidth: '100vw', 
        width: '100vw',
        height: '100vh',
        margin: 0
      }}
    >
      <Modal.Header closeButton>
        <div className="d-flex align-items-center justify-content-between w-100">
          <Modal.Title>
            <i className="fas fa-clock me-2"></i>
            Log History
          </Modal.Title>
          <div className="d-flex align-items-center gap-3">
            <select
              className="form-select"
              value={visibility}
              onChange={(e) => {
                setVisibility(e.target.value);
                loadRecords(e.target.value);
              }}
              style={{ minWidth: '150px' }}
            >
              <option value="mine">My Records</option>
              <option value="team">Team Records</option>
              <option value="public">Public Records</option>
              <option value="all">All Records</option>
            </select>
            <Button 
              variant="outline-primary"
              size="sm"
              onClick={() => loadRecords()}
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="loading-spinner me-2"></span>
                  Loading...
                </>
              ) : (
                <>
                  <i className="fas fa-sync-alt me-2"></i>
                  Refresh
                </>
              )}
            </Button>
          </div>
        </div>
      </Modal.Header>
      <Modal.Body className="p-0" style={{ height: 'calc(100vh - 120px)', overflow: 'hidden' }}>
        <Row className="g-0 h-100">
          <Col md={3} style={{ height: '100%', overflowY: 'auto' }}>
            <div className="history-sidebar p-3">
              <h6 className="fw-bold mb-3">Filter by Tags</h6>
              <div className="d-grid gap-2">
                <Button
                  variant={selectedTag === 'all' ? 'primary' : 'outline-secondary'}
                  size="sm"
                  onClick={() => handleTagFilter('all')}
                >
                  All ({tagCounts.all || 0})
                </Button>
                {Object.entries(tagCounts)
                  .filter(([tag]) => tag !== 'all')
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([tag, count]) => (
                    <Button
                      key={tag}
                      variant={selectedTag === tag ? 'primary' : 'outline-secondary'}
                      size="sm"
                      onClick={() => handleTagFilter(tag)}
                    >
                      {tag} ({count})
                    </Button>
                  ))}
              </div>
            </div>
          </Col>
          <Col md={9} style={{ height: '100%', overflowY: 'auto' }}>
            <div className="p-3">
              {loading ? (
                <div className="text-center py-5">
                  <div className="loading-spinner mb-3"></div>
                  <p>Loading log history...</p>
                </div>
              ) : filteredRecords.length === 0 ? (
                <div className="text-center py-5">
                  <i className="fas fa-file-alt fa-3x text-muted mb-3"></i>
                  <h5>No records found</h5>
                  <p className="text-muted">
                    {selectedTag === 'all' ? 'No log records available' : `No records with tag "${selectedTag}"`}
                  </p>
                </div>
              ) : (
                <div className="table-responsive">
                  <Table hover className="history-table">
                    <thead>
                      <tr>
                        <th style={{ width: '200px' }}>Log ID</th>
                        <th style={{ width: '100px' }}>Owner</th>
                        <th style={{ width: '180px' }}>Time</th>
                        <th style={{ width: '150px' }}>Raw Log</th>
                        <th style={{ minWidth: '300px' }}>Summary</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRecords.map((record) => (
                        <tr key={record.record_id}>
                          <td>
                            <Button 
                              variant="link" 
                              className="p-0 text-decoration-none text-start"
                              onClick={() => {
                                onViewRecord(record.record_id);
                                onHide(); // Close the Log History modal
                              }}
                              style={{ wordBreak: 'break-all' }}
                            >
                              {record.record_id}
                            </Button>
                          </td>
                          <td>
                            <span className="fw-bold text-primary">
                              {record.owner_username || record.owner_user_id || record.user_id || record.userid || '-'} ({record.team_name || record.team_id || '-'})
                            </span>
                          </td>
                          <td>
                            <small>{formatLocalTime(record.created_at)}</small>
                          </td>
                          <td>
                            {record.raw_file_path ? (
                              <Button
                                variant="outline-primary"
                                size="sm"
                                onClick={() => handleDownload(record.raw_file_path)}
                              >
                                <i className="fas fa-download me-1"></i>
                                Download
                              </Button>
                            ) : (
                              <span className="text-muted">No file</span>
                            )}
                          </td>
                          <td>
                            <div 
                              className="summary-text" 
                              style={{ 
                                maxWidth: 'none', 
                                whiteSpace: 'pre-wrap',
                                wordBreak: 'break-word',
                                lineHeight: '1.4'
                              }}
                              title={record.genapi?.summary || record.overall_summary || 'No summary available'}
                            >
                              {record.genapi?.summary || record.overall_summary || 'No summary available'}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>
              )}
            </div>
          </Col>
        </Row>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default LogHistory;
