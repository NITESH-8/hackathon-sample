import React, { useState } from 'react';
import { Modal, Button, Form, Alert } from 'react-bootstrap';

const QuestionModal = ({ show, onHide, onSubmit, record }) => {
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;

    try {
      setLoading(true);
      const result = await onSubmit(question);
      setResponse(result.response || 'No response received');
    } catch (error) {
      setResponse('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setQuestion('');
    setResponse('');
    onHide();
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <i className="fas fa-question-circle me-2"></i>
          Ask a Question
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {record && (
          <div className="mb-3">
            <small className="text-muted">
              Asking about record: <strong>{record.record_id}</strong>
            </small>
          </div>
        )}

        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Your Question</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              placeholder="Ask a question about this log..."
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              disabled={loading}
            />
          </Form.Group>

          <Button 
            type="submit" 
            variant="primary" 
            disabled={loading || !question.trim()}
          >
            {loading ? (
              <>
                <span className="loading-spinner me-2"></span>
                Asking...
              </>
            ) : (
              <>
                <i className="fas fa-paper-plane me-2"></i>
                Ask Question
              </>
            )}
          </Button>
        </Form>

        {response && (
          <div className="mt-4">
            <h6>Response:</h6>
            <Alert variant="info">
              <p className="mb-0">{response}</p>
            </Alert>
          </div>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default QuestionModal;
