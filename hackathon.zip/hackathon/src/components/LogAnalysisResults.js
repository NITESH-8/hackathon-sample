import React from 'react';
import { Card, Button, Badge, Row, Col } from 'react-bootstrap';

const LogAnalysisResults = ({ records, loading, onViewRecord, getSeverityClass, getSeverityText }) => {
  if (loading) {
    return (
      <div className="text-center py-5">
        <div className="loading-spinner mb-3"></div>
        <p>Loading analysis results...</p>
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="text-center py-5">
        <i className="fas fa-chart-line fa-3x text-muted mb-3"></i>
        <h5>No Analysis Results</h5>
        <p className="text-muted">Upload a log file to see analysis results here</p>
      </div>
    );
  }

  return (
    <div className="log-analysis-results">
      <Row className="g-4">
        {records.map((record) => (
          <Col key={record.record_id} lg={6} xl={4}>
            <Card className="record-item h-100">
              <Card.Body className="d-flex flex-column">
                <div className="mb-3">
                  <h6 className="record-title text-truncate" title={record.record_id}>
                    {record.record_id}
                  </h6>
                  <p className="record-summary mb-3">
                    {record.genapi?.summary || record.overall_summary || 'No summary available'}
                  </p>
                </div>

                <div className="mb-3 flex-grow-1">
                  <div className="d-flex flex-wrap gap-1 mb-2">
                    {record.genapi?.overall_severity && (
                      <Badge 
                        className={`severity-badge severity-${getSeverityClass(record.genapi.overall_severity)}`}
                      >
                        {getSeverityText(record.genapi.overall_severity)}
                      </Badge>
                    )}
                    {(record.tags || []).slice(0, 6).map((tag, index) => (
                      <span key={index} className="tag">
                        {tag}
                      </span>
                    ))}
                    {(record.tags || []).length > 6 && (
                      <span className="tag text-muted">
                        +{(record.tags || []).length - 6} more
                      </span>
                    )}
                  </div>
                </div>

                <div className="record-meta mt-auto">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <small className="text-muted">
                        {(() => {
                          const ts = record.created_at;
                          const hasZone = /Z|[+-]\d{2}:\d{2}$/.test(ts || '');
                          const d = new Date(hasZone ? ts : (ts ? ts + 'Z' : ''));
                          return isNaN(d.getTime()) ? '-' : d.toLocaleDateString();
                        })()}
                      </small>
                      <div className="small text-muted">
                        {record.processed_stats?.line_count || 0} lines processed
                        {record.processed_stats?.error_window_count > 0 && (
                          <span className="text-warning ms-2">
                            <i className="fas fa-exclamation-triangle me-1"></i>
                            {record.processed_stats.error_window_count} issues
                          </span>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => onViewRecord(record.record_id)}
                    >
                      <i className="fas fa-eye me-1"></i>
                      View Details
                    </Button>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default LogAnalysisResults;
