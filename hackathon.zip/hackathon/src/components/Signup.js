import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import AuthService from '../services/AuthService';

const Signup = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    userid: '',
    password: '',
    confirmPassword: '',
    teamid: ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      setLoading(false);
      return;
    }

    try {
      const response = await AuthService.signup(
        formData.userid,
        formData.password,
        formData.teamid
      );
      onLogin(response);
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <div className="auth-container">
        <div className="auth-card">
          <div className="text-center mb-5">
            <div className="mb-4">
              <div className="d-inline-flex align-items-center justify-content-center rounded-circle bg-success text-white" 
                   style={{ width: '80px', height: '80px', fontSize: '2rem' }}>
                <i className="fas fa-user-plus"></i>
              </div>
            </div>
            <h2 className="fw-bold mb-2" style={{ 
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
              Create Account
            </h2>
            <p className="text-muted fs-5">Join MediaTek's BugPredictor</p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="userid" className="form-label">User ID</label>
              <input
                type="text"
                className="form-control"
                id="userid"
                name="userid"
                value={formData.userid}
                onChange={handleChange}
                required
                placeholder="Choose a unique user ID"
              />
            </div>

            <div className="mb-3">
              <label htmlFor="teamid" className="form-label">Team ID</label>
              <input
                type="text"
                className="form-control"
                id="teamid"
                name="teamid"
                value={formData.teamid}
                onChange={handleChange}
                required
                placeholder="Enter your team ID"
              />
            </div>

            <div className="mb-3">
              <label htmlFor="password" className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="Create a strong password"
                minLength="6"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
              <input
                type="password"
                className="form-control"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                placeholder="Confirm your password"
                minLength="6"
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary w-100 mb-4 py-3"
              disabled={loading}
              style={{ fontSize: '1.1rem', fontWeight: '600' }}
            >
              {loading ? (
                <>
                  <span className="loading-spinner me-2"></span>
                  Creating Account...
                </>
              ) : (
                <>
                  <i className="fas fa-user-plus me-2"></i>
                  Create Account
                </>
              )}
            </button>

            <div className="text-center">
              <p className="mb-0">
                Already have an account?{' '}
                <Link to="/login" className="text-decoration-none">
                  Sign in here
                </Link>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Signup;
