import React from 'react';

const RecordsList = ({ records, loading, onViewRecord, getSeverityClass, getSeverityText }) => {
  if (loading) {
    return (
      <div className="text-center py-5">
        <div className="loading-spinner mb-3"></div>
        <p>Loading your records...</p>
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="empty-state">
        <i className="fas fa-file-alt"></i>
        <h5>No records found</h5>
        <p>Upload a log file to get started</p>
      </div>
    );
  }

  return (
    <div className="row">
      {records.map((record) => (
        <div key={record.record_id} className="col-md-6 col-lg-4 mb-3">
          <div className="record-item fade-in">
            <div className="record-title">
              {record.title || 'Untitled Log'}
            </div>
            
            <div className="record-summary">
              {record.genapi?.summary || record.overall_summary || 'No summary available'}
            </div>
            
            <div className="record-meta">
              <div>
                <span className={`severity-badge severity-${getSeverityClass(record.overall_severity)}`}>
                  {getSeverityText(record.overall_severity)}
                </span>
                {record.tags?.map(tag => (
                  <span key={tag} className="tag">{tag}</span>
                ))}
              </div>
              
              <div>
                <small className="text-muted">
                  {(() => {
                    const ts = record.created_at;
                    const hasZone = /Z|[+-]\d{2}:\d{2}$/.test(ts || '');
                    const d = new Date(hasZone ? ts : (ts ? ts + 'Z' : ''));
                    return isNaN(d.getTime()) ? '-' : d.toLocaleDateString();
                  })()}
                </small>
                <button
                  className="btn btn-sm btn-outline-primary ms-2"
                  onClick={() => onViewRecord(record.record_id)}
                >
                  <i className="fas fa-eye me-1"></i>
                  View Details
                </button>
              </div>
            </div>

            {/* Quick stats */}
            <div className="mt-2">
              <small className="text-muted">
                <i className="fas fa-file-alt me-1"></i>
                {record.raw_stats?.line_count || 0} lines
                <span className="ms-3">
                  <i className="fas fa-chart-bar me-1"></i>
                  {record.processed_stats?.line_count || 0} processed
                </span>
                {record.genapi?.problems?.length > 0 && (
                  <span className="ms-3 text-warning">
                    <i className="fas fa-exclamation-triangle me-1"></i>
                    {record.genapi.problems.length} issues
                  </span>
                )}
              </small>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RecordsList;
