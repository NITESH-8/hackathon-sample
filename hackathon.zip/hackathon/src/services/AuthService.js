import ApiService from './ApiService';

class AuthService {
  async login(userid, password) {
    try {
      const response = await ApiService.login({ userid, password });
      if (response.token) {
        localStorage.setItem('auth_token', response.token);
        return response;
      }
      throw new Error(response.error || 'Login failed');
    } catch (error) {
      throw new Error(error.response?.data?.error || error.message || 'Login failed');
    }
  }

  async signup(userid, password, teamid) {
    try {
      const response = await ApiService.signup({ userid, password, teamid });
      if (response.token) {
        localStorage.setItem('auth_token', response.token);
        return response;
      }
      throw new Error(response.error || 'Signup failed');
    } catch (error) {
      throw new Error(error.response?.data?.error || error.message || 'Signup failed');
    }
  }

  async getProfile() {
    try {
      return await ApiService.getProfile();
    } catch (error) {
      throw new Error(error.response?.data?.error || error.message || 'Failed to load profile');
    }
  }

  async updateProfile(updateData) {
    try {
      return await ApiService.updateProfile(updateData);
    } catch (error) {
      throw new Error(error.response?.data?.error || error.message || 'Failed to update profile');
    }
  }

  logout() {
    localStorage.removeItem('auth_token');
  }

  isAuthenticated() {
    return !!localStorage.getItem('auth_token');
  }
}

export default new AuthService();
