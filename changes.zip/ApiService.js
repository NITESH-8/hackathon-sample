import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000';

class ApiService {
  constructor() {
    this.api = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add request interceptor to include auth token
    this.api.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('auth_token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Add response interceptor for error handling
    this.api.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          localStorage.removeItem('auth_token');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // Auth endpoints
  async login(credentials) {
    const response = await this.api.post('/auth/login', credentials);
    return response.data;
  }

  async signup(userData) {
    const response = await this.api.post('/auth/signup', userData);
    return response.data;
  }

  // Profile endpoints
  async getProfile() {
    const response = await this.api.get('/profile/me');
    return response.data;
  }

  async updateProfile(updateData) {
    const response = await this.api.patch('/profile/me', updateData);
    return response.data;
  }

  // Records endpoints
  async getRecords(visibility = 'mine') {
    const response = await this.api.get(`/records?visibility=${visibility}`);
    return response.data;
  }

  async getRecord(recordId) {
    const response = await this.api.get(`/records/${recordId}`);
    return response.data;
  }

  async getSimilarRecords(recordId) {
    const response = await this.api.get(`/records/${recordId}/similar`);
    return response.data;
  }

  async updateRecordVisibility(recordId, visibility) {
    const response = await this.api.patch(`/records/${recordId}/visibility`, { visibility });
    return response.data;
  }

  // Upload endpoint
  async uploadLog(file, context = '', visibility = 'self') {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('context', context);
    formData.append('visibility', visibility);

    const response = await this.api.post('/records', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  }

  // GenAPI endpoints
  async analyzeRecord(recordId, context = '') {
    const response = await this.api.post('/genapi/analyze', {
      record_id: recordId,
      context: context,
    });
    return response.data;
  }

  async askQuestion(recordId, question) {
    const response = await this.api.post('/ask', {
      record_id: recordId,
      question: question,
    });
    return response.data;
  }

  // Download endpoint
  getDownloadUrl(filePath) {
    return `${API_BASE_URL}/download?path=${encodeURIComponent(filePath)}`;
  }

  // Download file with authentication
  async downloadFile(filePath) {
    try {
      const response = await this.api.get('/download', {
        params: { path: filePath },
        responseType: 'blob'
      });
      
      // Create blob URL and trigger download
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Extract filename from path
      const filename = filePath.split('/').pop() || 'download.log';
      link.download = filename;
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      return { success: true };
    } catch (error) {
      console.error('Download error:', error);
      throw error;
    }
  }

  // Signals aggregation
  async getSignals({ visibility = 'all', q = '', size = 50 } = {}) {
    const params = new URLSearchParams();
    params.set('visibility', visibility);
    if (q) params.set('q', q);
    if (size) params.set('size', size);
    const response = await this.api.get(`/records/signals?${params.toString()}`);
    return response.data;
  }

  // Chat/Conversation methods
  async getConversation(recordId) {
    const response = await this.api.get(`/chat/conversation/${recordId}`);
    return response.data;
  }

  async sendChatMessage(conversationId, message) {
    const response = await this.api.post(`/chat/conversation/${conversationId}/message`, {
      message: message,
    });
    return response.data;
  }

  async getConversationHistory(conversationId) {
    const response = await this.api.get(`/chat/conversation/${conversationId}/history`);
    return response.data;
  }
}

export default new ApiService();
