import React, { useState, useEffect, useRef } from 'react';
import { toast } from 'react-toastify';
import Navbar from './Navbar';
import UploadArea from './UploadArea';
import LogHistory from './LogHistory';
import RecordModal from './RecordModal';
import AnalysisModal from './AnalysisModal';
import QuestionModal from './QuestionModal';
import AnalysisLoadingModal from './AnalysisLoadingModal';
import ApiService from '../services/ApiService';

const Dashboard = ({ user, onLogout }) => {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [showQuestion, setShowQuestion] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);
  const [activeJob, setActiveJob] = useState(null);
  // Removed inline analysis display on dashboard
  const [lastProcessedRecordId, setLastProcessedRecordId] = useState(null);
  const processedRecordsRef = useRef(new Set());
  
  // Analysis loading states
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisStatus, setAnalysisStatus] = useState('');
  const [analysisStartTime, setAnalysisStartTime] = useState(null);

  useEffect(() => {
    // Load records on component mount
    loadRecords();
    
    // Attach a small timer to pull active job state if present
    const interval = setInterval(() => {
      if (window.__activeJob) {
        setActiveJob(window.__activeJob);
      } else {
        // Clear activeJob if window.__activeJob is null/undefined
        setActiveJob(null);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleUploadSuccess = async (newRecord) => {
    // Check if this record has already been processed to prevent duplicate toasts
    if (newRecord && newRecord.record_id) {
      if (processedRecordsRef.current.has(newRecord.record_id)) {
        console.log('Record already processed, skipping duplicate:', newRecord.record_id);
        return; // Skip if already processed
      }
      
      // Mark as processed
      processedRecordsRef.current.add(newRecord.record_id);
      setLastProcessedRecordId(newRecord.record_id);
    }
    
    toast.success('Log uploaded and processed successfully!');
    // Load the latest records
    await loadRecords();
    
    // Automatically load and display the newly uploaded record
    // Do not open inline analysis on upload anymore
  };

  const loadRecords = async () => {
    try {
      setLoading(true);
      const response = await ApiService.getRecords('mine');
      setRecords(response.records || []);
    } catch (error) {
      toast.error('Failed to load records: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleViewRecord = async (recordId) => {
    try {
      const record = await ApiService.getRecord(recordId);
      setSelectedRecord(record);
    } catch (error) {
      toast.error('Failed to load record: ' + error.message);
    }
  };

  const handleAnalyzeRecord = async () => {
    if (!selectedRecord || isAnalyzing) return;

    try {
      console.log('Starting GenAPI analysis for record:', selectedRecord.record_id);
      
      // Initialize analysis state
      setIsAnalyzing(true);
      setAnalysisProgress(0);
      setAnalysisStatus('Initializing analysis...');
      setAnalysisStartTime(Date.now());
      
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setAnalysisProgress(prev => {
          if (prev < 90) {
            return prev + Math.random() * 10;
          }
          return prev;
        });
      }, 500);
      
      // Update status messages
      const statusMessages = [
        'Initializing analysis...',
        'Connecting to GenAPI...',
        'Processing log content...',
        'Analyzing patterns and errors...',
        'Generating insights...',
        'Finalizing results...'
      ];
      
      let statusIndex = 0;
      const statusInterval = setInterval(() => {
        if (statusIndex < statusMessages.length - 1) {
          statusIndex++;
          setAnalysisStatus(statusMessages[statusIndex]);
        }
      }, 2000);
      
      toast.info('Starting AI analysis...', { autoClose: 2000 });
      
      const analysis = await ApiService.analyzeRecord(
        selectedRecord.record_id,
        selectedRecord.context || ''
      );
      
      // Clear intervals
      clearInterval(progressInterval);
      clearInterval(statusInterval);
      
      // Complete the progress
      setAnalysisProgress(100);
      setAnalysisStatus('Analysis completed!');
      
      console.log('GenAPI analysis result:', analysis);
      setAnalysisResults(analysis);
      // Do not open the results popup; results are visible in the record modal below
      
      // Refresh the selected record to include the new GenAPI analysis data
      const updatedRecord = await ApiService.getRecord(selectedRecord.record_id);
      setSelectedRecord(updatedRecord);
      
      // Calculate elapsed time
      const elapsedTime = Math.round((Date.now() - analysisStartTime) / 1000);
      toast.success(`Analysis completed and saved automatically in ${elapsedTime}s!`);
      
    } catch (error) {
      console.error('GenAPI analysis error:', error);
      toast.error('Analysis failed: ' + error.message);
    } finally {
      // Reset analysis state
      setTimeout(() => {
        setIsAnalyzing(false);
        setAnalysisProgress(0);
        setAnalysisStatus('');
        setAnalysisStartTime(null);
      }, 2000);
    }
  };

  const handleAskQuestion = () => {
    setShowQuestion(true);
  };

  const handleDownload = async (filePath) => {
    try {
      await ApiService.downloadFile(filePath);
      toast.success('File download started');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Download failed: ' + error.message);
    }
  };


  const handleAskQuestionSubmit = async (question) => {
    if (!selectedRecord) return;

    try {
      const response = await ApiService.askQuestion(selectedRecord.record_id, question);
      toast.success('Question submitted successfully!');
      setShowQuestion(false);
      return response;
    } catch (error) {
      toast.error('Failed to submit question: ' + error.message);
    }
  };

  const getSeverityClass = (severity) => {
    if (severity >= 90) return 'critical';
    if (severity >= 70) return 'high';
    if (severity >= 50) return 'medium';
    if (severity >= 20) return 'low';
    return 'normal';
  };

  const getSeverityText = (severity) => {
    if (severity >= 90) return 'Critical';
    if (severity >= 70) return 'High';
    if (severity >= 50) return 'Medium';
    if (severity >= 20) return 'Low';
    return 'Normal';
  };

  return (
    <div className="dashboard-container">
      <Navbar user={user} onLogout={onLogout} onShowHistory={() => setShowHistory(true)} />
      
      <div className="container-fluid p-4">
        <div className="row">
          <div className="col-12">
            <div className="d-flex justify-content-between align-items-center mb-5">
              <div>
                <h2 className="mb-2 fw-bold" style={{ 
                  background: 'linear-gradient(135deg, #667eea, #764ba2)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text'
                }}>
                  Welcome back, {user?.userid || user?.user_id || 'User'}! 👋
                </h2>
                <p className="text-muted mb-0 fs-5">Upload and analyze your log files with AI</p>
              </div>
              <div className="text-end">
                <div className="d-flex align-items-center">
                  <i className="fas fa-users me-2 text-primary"></i>
                  <div>
                    <small className="text-muted d-block">Team</small>
                    <strong className="text-dark">{user?.team_id || 'N/A'}</strong>
                  </div>
                </div>
              </div>
            </div>

            <UploadArea onUploadSuccess={handleUploadSuccess} />

            {activeJob && (
              <div className="card shadow-sm mt-4">
                <div className="card-body">
                  <div className="d-flex align-items-center mb-2">
                    <i className="fas fa-tasks text-primary me-2"></i>
                    <strong>Background Processing</strong>
                    <span className="ms-2 text-muted">({activeJob.status || 'running'})</span>
                    <span className="ms-auto">{activeJob.progress || 0}%</span>
                  </div>
                  <div className="progress" style={{ height: '6px' }}>
                    <div className="progress-bar" role="progressbar" style={{ width: `${activeJob.progress || 0}%` }}></div>
                  </div>
                  <ul className="mt-3 mb-0 small text-muted">
                    <li className={activeJob.progress >= 10 ? 'text-success' : ''}>Upload received</li>
                    <li className={activeJob.progress >= 30 ? 'text-success' : ''}>Preprocessing</li>
                    <li className={activeJob.progress >= 60 ? 'text-success' : ''}>Vector embedding</li>
                    <li className={activeJob.progress >= 90 ? 'text-success' : ''}>Storing & indexing</li>
                    <li className={activeJob.progress >= 100 ? 'text-success' : ''}>Similarity & finalize</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Inline Log Analysis Display intentionally removed from home dashboard */}


          </div>
        </div>
      </div>

      {/* Modals */}
      <LogHistory 
        show={showHistory} 
        onHide={() => setShowHistory(false)}
        onViewRecord={handleViewRecord}
      />

      <RecordModal
        record={selectedRecord}
        show={!!selectedRecord}
        onHide={() => setSelectedRecord(null)}
        onAnalyze={handleAnalyzeRecord}
        onAskQuestion={handleAskQuestion}
        getSeverityClass={getSeverityClass}
        getSeverityText={getSeverityText}
        isAnalyzing={isAnalyzing}
        analysisProgress={analysisProgress}
        analysisStatus={analysisStatus}
      />

      <AnalysisModal
        show={showAnalysis}
        onHide={() => setShowAnalysis(false)}
        analysis={analysisResults}
      />

      <QuestionModal
        show={showQuestion}
        onHide={() => setShowQuestion(false)}
        onSubmit={handleAskQuestionSubmit}
        record={selectedRecord}
      />

      <AnalysisLoadingModal
        show={isAnalyzing}
        progress={analysisProgress}
        status={analysisStatus}
        elapsedTime={analysisStartTime ? Math.round((Date.now() - analysisStartTime) / 1000) : 0}
      />
    </div>
  );
};

export default Dashboard;
