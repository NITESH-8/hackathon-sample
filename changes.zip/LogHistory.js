import React, { useState, useEffect } from 'react';
import { Modal, Button, Table, Badge, Row, Col, Dropdown, Form } from 'react-bootstrap';
import { toast } from 'react-toastify';
import ApiService from '../services/ApiService';

const LogHistory = ({ show, onHide, onViewRecord }) => {
  const [records, setRecords] = useState([]);
  const [allRecords, setAllRecords] = useState([]); // union for cross-team tags
  const [loading, setLoading] = useState(false);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [selectedTag, setSelectedTag] = useState('all');
  const [selectedTeam, setSelectedTeam] = useState('all');
  const [selectedSignal, setSelectedSignal] = useState('all');
  const [tagCounts, setTagCounts] = useState({});
  const [teamCounts, setTeamCounts] = useState({});
  const [signalCounts, setSignalCounts] = useState({});
  const [tagQuery, setTagQuery] = useState('');
  const [teamQuery, setTeamQuery] = useState('');
  const [signalQuery, setSignalQuery] = useState('');
  const [tagsCollapsed, setTagsCollapsed] = useState(true);
  const [signalsCollapsed, setSignalsCollapsed] = useState(true);
  const [teamsCollapsed, setTeamsCollapsed] = useState(true);

  const getTeamDisplayName = (record) => {
    try {
      const raw = String(record.team_name || record.team_id || 'No Team');
      const cleaned = raw.replace(/^\s*[Tt]eam[:\s]*/,'').trim();
      return cleaned || 'No Team';
    } catch {
      return 'No Team';
    }
  };
  const [visibility, setVisibility] = useState('all');

  // Collect signals from record.genapi.problems[].signals or record.problems[].signals
  const getRecordSignals = (record) => {
    try {
      const sigs = new Set();
      if (record && record.genapi && Array.isArray(record.genapi.problems)) {
        record.genapi.problems.forEach(p => {
          (p.signals || []).forEach(s => {
            if (s && typeof s === 'string') sigs.add(s.toLowerCase());
          });
        });
      }
      if (record && Array.isArray(record.problems)) {
        record.problems.forEach(p => {
          (p.signals || []).forEach(s => {
            if (s && typeof s === 'string') sigs.add(s.toLowerCase());
          });
        });
      }
      return Array.from(sigs);
    } catch {
      return [];
    }
  };

  useEffect(() => {
    if (show) {
      loadRecords();
    }
  }, [show]);

  useEffect(() => {
    filterRecords();
  }, [records, allRecords, selectedTag, selectedTeam, selectedSignal, visibility]);

  const loadRecords = async (visibilityLevel = visibility) => {
    try {
      setLoading(true);
      const response = await ApiService.getRecords(visibilityLevel);
      const recordsData = response.records || [];
      setRecords(recordsData);

      // Also fetch 'all' visibility to aggregate cross-team tags and enable team filtering
      try {
        const allRes = await ApiService.getRecords('all');
        const allData = allRes.records || [];
        setAllRecords(allData);

        // Build tag counts from the current-visibility dataset
        const tagC = { all: recordsData.length };
        recordsData.forEach(record => {
          (record.tags || []).forEach(tag => {
            tagC[tag] = (tagC[tag] || 0) + 1;
          });
        });
        setTagCounts(tagC);

        // Build team counts from the wider set so all teams appear
        const teamC = {};
        allData.forEach(record => {
          const teamTag = getTeamDisplayName(record);
          teamC[teamTag] = (teamC[teamTag] || 0) + 1;
        });
        setTeamCounts(teamC);

        // Build signals from broader dataset (top N only client-side as fallback)
        const sigC = {};
        allData.forEach(record => {
          getRecordSignals(record).forEach(sig => {
            sigC[sig] = (sigC[sig] || 0) + 1;
          });
        });
        // If backend supports aggregation, prefer it on demand in UI fetch; keep initial snapshot minimal
        setSignalCounts(sigC);
      } catch (e) {
        // Fallback to current dataset for tags and teams
        const tagC = { all: recordsData.length };
        const teamC = {};
        recordsData.forEach(record => {
          (record.tags || []).forEach(tag => {
            tagC[tag] = (tagC[tag] || 0) + 1;
          });
          const teamTag = getTeamDisplayName(record);
          teamC[teamTag] = (teamC[teamTag] || 0) + 1;
        });
        setTagCounts(tagC);
        setTeamCounts(teamC);
        const sigC2 = {};
        recordsData.forEach(record => {
          getRecordSignals(record).forEach(sig => {
            sigC2[sig] = (sigC2[sig] || 0) + 1;
          });
        });
        setSignalCounts(sigC2);
      }
    } catch (error) {
      toast.error('Failed to load log history: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const filterRecords = () => {
    // Choose base dataset: if team filter applied, use wider set; else current visibility set
    const useAll = selectedTeam !== 'all' && visibility === 'all' && allRecords.length > 0;
    let base = useAll ? allRecords : records;

    // Apply team filter
    if (selectedTeam !== 'all') {
      base = base.filter(record => getTeamDisplayName(record) === selectedTeam);
    }

    // Apply tag filter
    if (selectedTag !== 'all') {
      base = base.filter(record => (record.tags || []).includes(selectedTag));
    }

    // Apply signal filter
    if (selectedSignal !== 'all') {
      base = base.filter(record => getRecordSignals(record).includes(selectedSignal.toLowerCase()));
    }

    setFilteredRecords(base);
  };

  const handleTagFilter = (tag) => {
    setSelectedTag(tag);
  };

  const handleTeamFilter = (team) => {
    setSelectedTeam(team);
  };

  const handleSignalFilter = (sig) => {
    setSelectedSignal(sig);
  };

  const handleDownload = async (filePath) => {
    try {
      await ApiService.downloadFile(filePath);
      toast.success('File download started');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Download failed: ' + error.message);
    }
  };

  // Ensure consistent local-time display even if ISO string lacks timezone
  const formatLocalTime = (ts) => {
    try {
      if (!ts) return '-';
      const hasZone = /Z|[+-]\d{2}:\d{2}$/.test(ts);
      const d = new Date(hasZone ? ts : ts + 'Z');
      if (isNaN(d.getTime())) return ts;
      return d.toLocaleString();
    } catch {
      return ts;
    }
  };


  return (
    <Modal 
      show={show} 
      onHide={onHide} 
      size="xl" 
      centered
      className="history-modal"
      style={{ 
        maxWidth: '100vw', 
        width: '100vw',
        height: '100vh',
        margin: 0
      }}
    >
      <Modal.Header>
        <div className="d-flex align-items-center justify-content-between w-100">
          <Modal.Title>
            <i className="fas fa-clock me-2"></i>
            Log History
          </Modal.Title>
          <div className="d-flex align-items-center gap-3">
            <select
              className="form-select"
              value={visibility}
              onChange={(e) => {
                setVisibility(e.target.value);
                loadRecords(e.target.value);
              }}
              style={{ minWidth: '150px' }}
            >
              <option value="mine">My Records</option>
              <option value="all">All Records</option>
            </select>
            <span
              role="button"
              onClick={() => { if (!loading) loadRecords(); }}
              title="Refresh"
              aria-label="Refresh"
              className="ms-1"
              style={{ cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? 0.6 : 1, padding: '6px' }}
            >
              {loading ? (
                <span className="loading-spinner"></span>
              ) : (
                <i className="fas fa-sync-alt"></i>
              )}
            </span>
          </div>
        </div>
      </Modal.Header>
      <Modal.Body className="p-0" style={{ height: 'calc(100vh - 120px)', overflow: 'hidden' }}>
        <Row className="g-0 h-100">
          <Col md={3} style={{ height: '100%', overflowY: 'auto' }}>
            <div className="history-sidebar p-3">
              <h6 className="fw-bold mb-2">Filter by Tags</h6>
              <div className="mb-2">
                <Form.Control
                  size="sm"
                  type="text"
                  placeholder="Search tags..."
                  value={tagQuery}
                  onChange={(e) => setTagQuery(e.target.value)}
                />
              </div>
              <div className="d-grid gap-2 mb-2" style={{ maxHeight: (tagsCollapsed ? 96 : 220), overflowY: 'auto' }}>
                <Button
                  variant={selectedTag === 'all' ? 'primary' : 'outline-secondary'}
                  size="sm"
                  onClick={() => handleTagFilter('all')}
                >
                  All ({tagCounts.all || 0})
                </Button>
                {Object.entries(tagCounts)
                  .filter(([tag]) => tag !== 'all')
                  .filter(([tag]) => tag.toLowerCase().includes((tagQuery || '').toLowerCase()))
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([tag, count]) => (
                    <Button
                      key={tag}
                      variant={selectedTag === tag ? 'primary' : 'outline-secondary'}
                      size="sm"
                      onClick={() => handleTagFilter(tag)}
                    >
                      {tag} ({count})
                    </Button>
                  ))}
              </div>
              <div className="text-end mb-4">
                <Button
                  variant="link"
                  size="sm"
                  className="p-0 text-decoration-none"
                  onClick={() => setTagsCollapsed(!tagsCollapsed)}
                >
                  {tagsCollapsed ? 'Show more' : 'Show less'}
                </Button>
              </div>
              <h6 className="fw-bold mb-2">Filter by Error</h6>
              <div className="mb-2">
                <Form.Control
                  size="sm"
                  type="text"
                  placeholder="Search signals..."
                  value={signalQuery}
                  onChange={(e) => setSignalQuery(e.target.value)}
                  onInput={async (e) => {
                    const q = e.target.value || '';
                    try {
                      // Debounced via browser input cadence; keep size modest
                      const res = await ApiService.getSignals({ visibility, q, size: 100 });
                      setSignalCounts(res.signals || {});
                    } catch (_) {
                      // ignore; fall back to local counts
                    }
                  }}
                />
              </div>
              <div className="d-grid gap-2" style={{ maxHeight: (signalsCollapsed ? 96 : 220), overflowY: 'auto' }}>
                <Button
                  variant={selectedSignal === 'all' ? 'primary' : 'outline-secondary'}
                  size="sm"
                  onClick={() => handleSignalFilter('all')}
                >
                  All Errors ({Object.values(signalCounts).reduce((a, b) => a + b, 0) || 0})
                </Button>
                {Object.entries(signalCounts)
                  .filter(([sig]) => (sig || '').toLowerCase().includes((signalQuery || '').toLowerCase()))
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([sig, count]) => (
                    <Button
                      key={sig}
                      variant={selectedSignal === sig ? 'primary' : 'outline-secondary'}
                      size="sm"
                      onClick={() => handleSignalFilter(sig)}
                    >
                      {sig} ({count})
                    </Button>
                  ))}
              </div>
              <div className="text-end mb-4">
                <Button
                  variant="link"
                  size="sm"
                  className="p-0 text-decoration-none"
                  onClick={() => setSignalsCollapsed(!signalsCollapsed)}
                >
                  {signalsCollapsed ? 'Show more' : 'Show less'}
                </Button>
              </div>

              <hr className="my-4" />

              <h6 className="fw-bold mb-2">Filter by Team</h6>
              <div className="mb-2">
                <Form.Control
                  size="sm"
                  type="text"
                  placeholder="Search teams..."
                  value={teamQuery}
                  onChange={(e) => setTeamQuery(e.target.value)}
                />
              </div>
              <div className="d-grid gap-2" style={{ maxHeight: (teamsCollapsed ? 96 : 220), overflowY: 'auto' }}>
                <Button
                  variant={selectedTeam === 'all' ? 'primary' : 'outline-secondary'}
                  size="sm"
                  onClick={() => handleTeamFilter('all')}
                >
                  All Teams ({Object.values(teamCounts).reduce((a, b) => a + b, 0) || 0})
                </Button>
                {Object.entries(teamCounts)
                  .filter(([team]) => team.toLowerCase().includes((teamQuery || '').toLowerCase()))
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([team, count]) => (
                    <Button
                      key={team}
                      variant={selectedTeam === team ? 'primary' : 'outline-secondary'}
                      size="sm"
                      onClick={() => handleTeamFilter(team)}
                    >
                      {team} ({count})
                    </Button>
                  ))}
              </div>
              <div className="text-end mb-1">
                <Button
                  variant="link"
                  size="sm"
                  className="p-0 text-decoration-none"
                  onClick={() => setTeamsCollapsed(!teamsCollapsed)}
                >
                  {teamsCollapsed ? 'Show more' : 'Show less'}
                </Button>
              </div>
            </div>
          </Col>
          <Col md={9} style={{ height: '100%', overflowY: 'auto' }}>
            <div className="p-3">
              {loading ? (
                <div className="text-center py-5">
                  <div className="loading-spinner mb-3"></div>
                  <p>Loading log history...</p>
                </div>
              ) : filteredRecords.length === 0 ? (
                <div className="text-center py-5">
                  <i className="fas fa-file-alt fa-3x text-muted mb-3"></i>
                  <h5>No records found</h5>
                  <p className="text-muted">
                    {selectedTag === 'all' ? 'No log records available' : `No records with tag "${selectedTag}"`}
                  </p>
                </div>
              ) : (
                <div className="table-responsive">
                  <Table hover className="history-table">
                    <thead>
                      <tr>
                        <th style={{ width: '200px' }}>Log ID</th>
                        <th style={{ width: '100px' }}>Owner</th>
                        <th style={{ width: '180px' }}>Time</th>
                        <th style={{ width: '150px' }}>Raw Log</th>
                        <th style={{ minWidth: '300px' }}>Summary</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRecords.map((record) => (
                        <tr key={record.record_id}>
                          <td>
                            <Button 
                              variant="link" 
                              className="p-0 text-decoration-none text-start"
                              onClick={() => {
                                onViewRecord(record.record_id);
                                onHide(); // Close the Log History modal
                              }}
                              style={{ wordBreak: 'break-all' }}
                            >
                              {record.record_id}
                            </Button>
                          </td>
                          <td>
                            <span className="fw-bold text-primary">
                              {record.owner_username || record.owner_user_id || record.user_id || record.userid || '-'} ({record.team_name || record.team_id || '-'})
                            </span>
                          </td>
                          <td>
                            <small>{formatLocalTime(record.created_at)}</small>
                          </td>
                          <td>
                            {record.raw_file_path ? (
                              <Button
                                variant="outline-primary"
                                size="sm"
                                onClick={() => handleDownload(record.raw_file_path)}
                              >
                                <i className="fas fa-download me-1"></i>
                                Download
                              </Button>
                            ) : (
                              <span className="text-muted">No file</span>
                            )}
                          </td>
                          <td>
                            <div 
                              className="summary-text" 
                              style={{ 
                                maxWidth: 'none', 
                                whiteSpace: 'pre-wrap',
                                wordBreak: 'break-word',
                                lineHeight: '1.4'
                              }}
                              title={record.genapi?.summary || record.overall_summary || 'No summary available'}
                            >
                              {record.genapi?.summary || record.overall_summary || 'No summary available'}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>
              )}
            </div>
          </Col>
        </Row>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default LogHistory;
