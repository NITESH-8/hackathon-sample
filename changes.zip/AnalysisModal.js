import React from 'react';
import { Modal, Button, Alert } from 'react-bootstrap';

const AnalysisModal = ({ show, onHide, analysis }) => {
  if (!analysis) return null;

  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <i className="fas fa-brain me-2"></i>
          Log Analysis Results
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {/* Removed success banner to reduce visual noise; results are below */}
        
        <div className="mb-3">
          <h6>Analysis Summary</h6>
          <Alert variant="info">
            <p className="mb-0">{analysis.summary}</p>
          </Alert>
        </div>

        {analysis.problems && analysis.problems.length > 0 ? (
          <div className="mb-3">
            <h6>Problems Found</h6>
            {analysis.problems.map((problem, index) => (
              <div key={index} className="problem-item">
                <div className="problem-title">{problem.title}</div>
                <div className="problem-details">
                  <p><strong>Severity:</strong> {problem.severity}/100</p>
                  <p><strong>Root Cause:</strong> {problem.root_cause || 'Not specified'}</p>
                  <p><strong>Recommendations:</strong> {problem.recommendations || 'None'}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Alert variant="success">
            <i className="fas fa-check-circle me-2"></i>
            No problems detected!
          </Alert>
        )}

        {analysis.key_insights && analysis.key_insights.length > 0 && (
          <div className="mb-3">
            <h6>Key Insights</h6>
            <ul className="mb-0">
              {analysis.key_insights.map((insight, index) => (
                <li key={index}>{insight}</li>
              ))}
            </ul>
          </div>
        )}

        {analysis.recommendations && analysis.recommendations.length > 0 && (
          <div className="mb-3">
            <h6>Recommendations</h6>
            <ul className="mb-0">
              {analysis.recommendations.map((rec, index) => (
                <li key={index}>{rec}</li>
              ))}
            </ul>
          </div>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={onHide}>
          <i className="fas fa-check me-2"></i>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AnalysisModal;
