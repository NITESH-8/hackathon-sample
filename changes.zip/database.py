from elasticsearch import Elasticsearch
from typing import Dict, List, Optional, Any
import uuid
from datetime import datetime
import json
import os

class DatabaseManager:
    def __init__(self):
        # Elasticsearch client configuration for version 8.x
        es_url = os.getenv('ELASTICSEARCH_URL', 'https://192.168.1.109:9200/')
        self.es = Elasticsearch(
            es_url,
            request_timeout=30,
            max_retries=10,
            retry_on_timeout=True,
            verify_certs=False,
            ssl_show_warn=False,
            basic_auth=('elastic', 'eyAGQwkN-FI3Jyl+a6oH')
        )
        self.index_prefix = 'log_analysis'
        self.indices = {
            'users': f'{self.index_prefix}_users_v1',
            'teams': f'{self.index_prefix}_teams_v1',
            'records': f'{self.index_prefix}_records_v1',
            'record_chunks': f'{self.index_prefix}_record_chunks_v1',
            'conversations': f'{self.index_prefix}_conversations_v1',
            'jobs': f'{self.index_prefix}_jobs_v1'
        }
    
    def initialize_database(self):
        """Initialize all Elasticsearch indices with proper mappings"""
        self._create_users_index()
        self._create_teams_index()
        self._create_records_index()
        self._create_record_chunks_index()
        self._create_conversations_index()
        self._create_jobs_index()
    
    def _create_users_index(self):
        """Create users index with mapping"""
        mapping = {
            "mappings": {
                "properties": {
                    "user_id": {"type": "keyword"},
                    "userid": {"type": "keyword"},
                    "team_id": {"type": "keyword"},
                    "password_hash": {"type": "keyword"},
                    "roles": {"type": "keyword"},
                    "status": {"type": "keyword"},
                    "created_at": {"type": "date"},
                    "updated_at": {"type": "date"},
                    "last_login_at": {"type": "date"},
                    "profile": {
                        "properties": {
                            "display_name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
                            "email": {"type": "keyword"}
                        }
                    }
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        self._create_index_if_not_exists(self.indices['users'], mapping)
    
    def _create_teams_index(self):
        """Create teams index with mapping"""
        mapping = {
            "mappings": {
                "properties": {
                    "team_id": {"type": "keyword"},
                    "name": {
                        "type": "text",
                        "fields": {"keyword": {"type": "keyword"}}
                    },
                    "created_at": {"type": "date"},
                    "members_count": {"type": "integer"},
                    "meta": {"type": "object", "dynamic":  False}
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        self._create_index_if_not_exists(self.indices['teams'], mapping)
    
    def _create_records_index(self):
        """Create records index with mapping"""
        mapping = {
            "mappings": {
                "properties": {
                    "record_id": {"type": "keyword"},
                    "owner_user_id": {"type": "keyword"},
                    "team_id": {"type": "keyword"},
                    "visibility": {"type": "keyword"},
                    "title": {
                        "type": "text",
                        "fields": {"keyword": {"type": "keyword"}}
                    },
                    "tags": {"type": "keyword"},
                    "context": {"type": "text"},
                    "raw_file_path": {"type": "keyword"},
                    "processed_file_path": {"type": "keyword"},
                    "raw_stats": {
                        "properties": {
                            "line_count": {"type": "integer"},
                            "size_bytes": {"type": "long"},
                            "file_name": {"type": "keyword"}
                        }
                    },
                    "processed_stats": {
                        "properties": {
                            "line_count": {"type": "integer"},
                            "size_bytes": {"type": "long"},
                            "error_window_count": {"type": "integer"}
                        }
                    },
                    "overall_summary": {"type": "text"},
                    "overall_severity": {"type": "integer"},
                    "problems": {
                        "type": "nested",
                        "properties": {
                            "problem_id": {"type": "keyword"},
                            "title": {
                                "type": "text",
                                "fields": {"keyword": {"type": "keyword"}}
                            },
                            "severity": {"type": "integer"},
                            "start_line": {"type": "integer"},
                            "end_line": {"type": "integer"},
                            "root_cause": {"type": "text"},
                            "signals": {"type": "keyword"}
                        }
                    },
                    "embedding": {
                        "type": "float"
                    },
                    "created_at": {"type": "date"},
                    "updated_at": {"type": "date"},
                    "genapi": {
                        "properties": {
                            "analyzed": {"type": "boolean"},
                            "result_version": {"type": "integer"},
                            "summary": {"type": "text"},
                            "problems": {
                                "type": "nested",
                                "properties": {
                                    "problem_id": {"type": "keyword"},
                                    "title": {
                                        "type": "text",
                                        "fields": {"keyword": {"type": "keyword"}}
                                    },
                                    "severity": {"type": "integer"},
                                    "start_line": {"type": "integer"},
                                    "end_line": {"type": "integer"},
                                    "root_cause": {"type": "text"},
                                    "signals": {"type": "keyword"}
                                }
                            }
                        }
                    }
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0,
            }
        }
        self._create_index_if_not_exists(self.indices['records'], mapping)
    
    def _create_record_chunks_index(self):
        """Create record chunks index with mapping"""
        mapping = {
            "mappings": {
                "properties": {
                    "chunk_id": {"type": "keyword"},
                    "record_id": {"type": "keyword"},
                    "owner_user_id": {"type": "keyword"},
                    "team_id": {"type": "keyword"},
                    "visibility": {"type": "keyword"},
                    "start_line": {"type": "integer"},
                    "end_line": {"type": "integer"},
                    "is_error_window": {"type": "boolean"},
                    "text": {"type": "text"},
                    "summary": {"type": "text"},
                    "signals": {"type": "keyword"},
                    "embedding": {
                        "type": "float"
                    },
                    "created_at": {"type": "date"}
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0,
            }
        }
        self._create_index_if_not_exists(self.indices['record_chunks'], mapping)
    
    def _create_conversations_index(self):
        """Create conversations index with mapping"""
        mapping = {
            "mappings": {
                "properties": {
                    "conversation_id": {"type": "keyword"},
                    "record_id": {"type": "keyword"},
                    "user_id": {"type": "keyword"},
                    "team_id": {"type": "keyword"},
                    "status": {"type": "keyword"},
                    "created_at": {"type": "date"},
                    "updated_at": {"type": "date"},
                    "messages": {
                        "type": "nested",
                        "properties": {
                            "message_id": {"type": "keyword"},
                            "content": {"type": "text"},
                            "sender": {"type": "keyword"},
                            "timestamp": {"type": "date"}
                        }
                    }
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        self._create_index_if_not_exists(self.indices['conversations'], mapping)
    
    def _create_jobs_index(self):
        """Create jobs index with mapping"""
        mapping = {
            "mappings": {
                "properties": {
                    "job_id": {"type": "keyword"},
                    "user_id": {"type": "keyword"},
                    "team_id": {"type": "keyword"},
                    "record_id": {"type": "keyword"},
                    "type": {"type": "keyword"},
                    "status": {"type": "keyword"},
                    "progress_pct": {"type": "integer"},
                    "started_at": {"type": "date"},
                    "finished_at": {"type": "date"},
                    "error_message": {"type": "text"}
                }
            },
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        self._create_index_if_not_exists(self.indices['jobs'], mapping)
    
    def _create_index_if_not_exists(self, index_name: str, mapping: Dict):
        """Create index if it doesn't exist"""
        if not self.es.indices.exists(index=index_name):
            self.es.indices.create(index=index_name, body=mapping)
    
    # User management methods
    def create_user(self, user_data: Dict) -> Dict:
        """Create a new user"""
        try:
            self.es.index(
                index=self.indices['users'],
                id=user_data['user_id'],
                body=user_data
            )
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def user_exists(self, userid: str) -> bool:
        """Check if user exists by userid"""
        try:
            query = {
                "query": {
                    "term": {"userid": userid}
                }
            }
            result = self.es.search(index=self.indices['users'], body=query)
            return result['hits']['total']['value'] > 0
        except Exception:
            return False
    
    def get_user_by_userid(self, userid: str) -> Optional[Dict]:
        """Get user by userid"""
        try:
            query = {
                "query": {
                    "term": {"userid": userid}
                }
            }
            result = self.es.search(index=self.indices['users'], body=query)
            if result['hits']['total']['value'] > 0:
                return result['hits']['hits'][0]['_source']
            return None
        except Exception:
            return None
    
    def get_user_profile(self, user_id: str) -> Dict:
        """Get user profile"""
        try:
            result = self.es.get(index=self.indices['users'], id=user_id)
            user_data = result['_source']
            
            # Remove sensitive data
            user_data.pop('password_hash', None)
            return user_data
        except Exception:
            return {}
    
    def update_user_profile(self, user_id: str, update_data: Dict) -> Dict:
        """Update user profile"""
        try:
            # Only allow updating certain fields
            allowed_fields = ['team_id', 'profile']
            update_body = {}
            
            for field in allowed_fields:
                if field in update_data:
                    update_body[field] = update_data[field]
            
            if update_body:
                update_body['updated_at'] = datetime.now().isoformat()
                self.es.update(
                    index=self.indices['users'],
                    id=user_id,
                    body={'doc': update_body}
                )
            
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def update_last_login(self, user_id: str):
        """Update last login timestamp"""
        try:
            self.es.update(
                index=self.indices['users'],
                id=user_id,
                body={
                    'doc': {
                        'last_login_at': datetime.now().isoformat()
                    }
                }
            )
        except Exception:
            pass
    
    def get_user_conversations(self, user_id: str) -> List[Dict]:
        """Get user's conversations"""
        try:
            query = {
                "query": {
                    "term": {"owner_user_id": user_id}
                },
                "sort": [{"last_activity_at": {"order": "desc"}}],
                "size": 50
            }
            result = self.es.search(index=self.indices['conversations'], body=query)
            return [hit['_source'] for hit in result['hits']['hits']]
        except Exception:
            return []
    
    # Record management methods
    def get_records(self, user_id: str, team_id: str, visibility: str = 'all') -> List[Dict]:
        """Get records based on visibility and user permissions"""
        try:
            print(f"DEBUG DB: user_id={user_id}, team_id={team_id}, visibility={visibility}")
            
            # Build query based on visibility
            tag_filter = None
            # Extract tag filter from environment variable passed by the API layer (quick approach)
            import os
            if os.getenv('REQ_TAG'):
                tag_filter = os.getenv('REQ_TAG')
            if visibility == 'mine':
                query = {
                    "query": {
                        "term": {"owner_user_id": user_id}
                    }
                }
            elif visibility == 'team':
                if team_id and team_id.strip():
                    query = {
                        "query": {
                            "bool": {
                                "should": [
                                    {"term": {"owner_user_id": user_id}},
                                    {
                                        "bool": {
                                            "must": [
                                                {"term": {"team_id": team_id}},
                                                {"term": {"visibility": "team"}}
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    }
                else:
                    # If no team_id, only show user's own records
                    query = {
                        "query": {
                            "term": {"owner_user_id": user_id}
                        }
                    }
            elif visibility == 'public':
                # Treat missing/empty visibility as public too (backward compatibility)
                query = {
                    "query": {
                        "bool": {
                            "should": [
                                {"term": {"visibility": "public"}},
                                {"match": {"visibility": "public"}},
                                {"bool": {"must_not": {"exists": {"field": "visibility"}}}},
                                {"term": {"visibility": ""}},
                                {"bool": {"must_not": {"terms": {"visibility": ["self", "team"]}}}}
                            ],
                            "minimum_should_match": 1
                        }
                    }
                }
            else:  # all
                if team_id and team_id.strip():
                    query = {
                        "query": {
                            "bool": {
                                "should": [
                                    {"term": {"owner_user_id": user_id}},
                                    {
                                        "bool": {
                                            "must": [
                                                {"term": {"team_id": team_id}},
                                                {"term": {"visibility": "team"}}
                                            ]
                                        }
                                    },
                                    {"term": {"visibility": "public"}},
                                    {"bool": {"must_not": {"terms": {"visibility": ["self", "team"]}}}},
                                    {"bool": {"must_not": {"exists": {"field": "visibility"}}}},
                                    {"term": {"visibility": ""}}
                                ]
                            }
                        }
                    }
                else:
                    # If no team_id, show user's own records and public records
                    query = {
                        "query": {
                            "bool": {
                                "should": [
                                    {"term": {"owner_user_id": user_id}},
                                    {"term": {"visibility": "public"}},
                                    {"bool": {"must_not": {"terms": {"visibility": ["self", "team"]}}}},
                                    {"bool": {"must_not": {"exists": {"field": "visibility"}}}},
                                    {"term": {"visibility": ""}}
                                ]
                            }
                        }
                    }
            
            query["sort"] = [{"created_at": {"order": "desc"}}]
            # Increase page size to surface more records
            query["size"] = 2000
            
            print(f"DEBUG DB: Query = {json.dumps(query, indent=2)}")
            
            try:
                result = self.es.search(index=self.indices['records'], body=query)
                items = [hit['_source'] for hit in result['hits']['hits']]
                print(f"DEBUG DB: Found {len(items)} records, total hits: {result['hits']['total']['value']}")
            except Exception as e:
                print(f"DEBUG DB: Elasticsearch query failed: {e}")
                # Fallback: get all records and filter in Python
                fallback_query = {"query": {"match_all": {}}, "size": 1000}
                result = self.es.search(index=self.indices['records'], body=fallback_query)
                all_items = [hit['_source'] for hit in result['hits']['hits']]
                
                # Filter based on visibility
                if visibility == 'mine':
                    items = [item for item in all_items if item.get('owner_user_id') == user_id]
                elif visibility == 'team':
                    items = [item for item in all_items if 
                            item.get('owner_user_id') == user_id or 
                            (item.get('team_id') == team_id and item.get('visibility') == 'team')]
                elif visibility == 'public':
                    items = [item for item in all_items if item.get('visibility') not in ['self', 'team']]
                else:  # all
                    items = [item for item in all_items if 
                            item.get('owner_user_id') == user_id or 
                            (item.get('team_id') == team_id and item.get('visibility') == 'team') or
                            (item.get('visibility') not in ['self', 'team'])]
                
                print(f"DEBUG DB: Fallback found {len(items)} records")

            # Attach small raw preview from the RAW file when possible (best-effort)
            for it in items:
                try:
                    rp = it.get('raw_file_path')
                    if rp:
                        with open(rp, 'r', encoding='utf-8', errors='ignore') as f:
                            first = f.readline().strip()
                            second = f.readline().strip()
                            it['raw_preview'] = (first + ('\n' + second if second else ''))
                except Exception:
                    pass
                
                # Add owner username and team name by fetching from users and teams indices
                # Handle username lookup separately from team lookup
                owner_id = it.get('owner_user_id')
                team_id = it.get('team_id')
                
                # Username lookup
                try:
                    if owner_id:
                        user_result = self.es.get(index=self.indices['users'], id=owner_id)
                        user_data = user_result['_source']
                        it['owner_username'] = user_data.get('userid', owner_id)
                    else:
                        it['owner_username'] = it.get('owner_user_id', '-')
                except Exception as e:
                    it['owner_username'] = it.get('owner_user_id', '-')
                
                # Team name lookup
                try:
                    if team_id:
                        team_result = self.es.get(index=self.indices['teams'], id=team_id)
                        team_data = team_result['_source']
                        it['team_name'] = team_data.get('name', f'Team {team_id}')
                    else:
                        it['team_name'] = f'Team {team_id}' if team_id else 'No Team'
                except Exception as e:
                    it['team_name'] = f'Team {it.get("team_id", "Unknown")}'

            # Optional tag filter client-side if not supported in query
            if tag_filter:
                items = [x for x in items if tag_filter in (x.get('tags') or [])]
            return items
        except Exception:
            return []
    
    def get_record(self, record_id: str, user_id: str, team_id: str) -> Optional[Dict]:
        """Get specific record with permission check"""
        try:
            result = self.es.get(index=self.indices['records'], id=record_id)
            record = result['_source']
            
            # Check permissions
            if (record['owner_user_id'] == user_id or 
                (record['team_id'] == team_id and record['visibility'] in ['team', 'public']) or
                record['visibility'] == 'public'):
                return record
            return None
        except Exception:
            return None

    def aggregate_signals(self, user_id: str, team_id: str, visibility: str = 'all', prefix: Optional[str] = None, size: int = 50) -> Dict[str, int]:
        """Aggregate signal counts from both preprocessing problems and genapi problems.
        Uses nested aggregations on keyword fields.
        """
        try:
            # Build visibility filter (reuse simplified variant of get_records logic)
            if visibility == 'mine':
                base_query = {"term": {"owner_user_id": user_id}}
            else:  # all
                if team_id and team_id.strip():
                    base_query = {
                        "bool": {
                            "should": [
                                {"term": {"owner_user_id": user_id}},
                                {"bool": {"must": [{"term": {"team_id": team_id}}, {"term": {"visibility": "team"}}]}},
                                {"term": {"visibility": "public"}},
                                {"bool": {"must_not": {"terms": {"visibility": ["self", "team"]}}}},
                                {"bool": {"must_not": {"exists": {"field": "visibility"}}}},
                                {"term": {"visibility": ""}}
                            ],
                            "minimum_should_match": 1
                        }
                    }
                else:
                    base_query = {
                        "bool": {
                            "should": [
                                {"term": {"owner_user_id": user_id}},
                                {"term": {"visibility": "public"}},
                                {"bool": {"must_not": {"terms": {"visibility": ["self", "team"]}}}},
                                {"bool": {"must_not": {"exists": {"field": "visibility"}}}},
                                {"term": {"visibility": ""}}
                            ],
                            "minimum_should_match": 1
                        }
                    }

            include_regex = None
            if prefix:
                # escape regex special chars except letters/numbers/underscore and hyphen
                import re
                esc = re.escape(prefix)
                include_regex = f"{esc}.*"

            aggs = {
                "problems": {
                    "nested": {"path": "problems"},
                    "aggs": {
                        "signals": {
                            "terms": {
                                "field": "problems.signals",
                                "size": size,
                                "order": {"_count": "desc"},
                                **({"include": include_regex} if include_regex else {})
                            }
                        }
                    }
                },
                "genapi_problems": {
                    "nested": {"path": "genapi.problems"},
                    "aggs": {
                        "signals": {
                            "terms": {
                                "field": "genapi.problems.signals",
                                "size": size,
                                "order": {"_count": "desc"},
                                **({"include": include_regex} if include_regex else {})
                            }
                        }
                    }
                }
            }

            body = {"size": 0, "query": {"bool": {"filter": [base_query]}}, "aggs": aggs}
            res = self.es.search(index=self.indices['records'], body=body)

            counts: Dict[str, int] = {}
            try:
                for b in res['aggregations']['problems']['signals']['buckets']:
                    key = (b.get('key') or '').lower()
                    if key:
                        counts[key] = counts.get(key, 0) + int(b.get('doc_count', 0))
            except Exception:
                pass
            try:
                for b in res['aggregations']['genapi_problems']['signals']['buckets']:
                    key = (b.get('key') or '').lower()
                    if key:
                        counts[key] = counts.get(key, 0) + int(b.get('doc_count', 0))
            except Exception:
                pass

            # Return top 'size' by count
            top = dict(sorted(counts.items(), key=lambda x: x[1], reverse=True)[:size])
            return top
        except Exception as e:
            print(f"Error aggregating signals: {e}")
            return {}
    
    def create_record(self, record_data: Dict) -> Dict:
        """Create a new record"""
        try:
            self.es.index(
                index=self.indices['records'],
                id=record_data['record_id'],
                body=record_data
            )
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def update_record_analysis(self, record_id: str, analysis: Dict):
        """Update record with GenAPI analysis"""
        try:
            self.es.update(
                index=self.indices['records'],
                id=record_id,
                body={
                    'doc': {
                        'genapi': analysis,
                        'updated_at': datetime.now().isoformat()
                    }
                }
            )
        except Exception:
            pass
    
    def update_record_visibility(self, record_id: str, user_id: str, visibility: str) -> Dict:
        """Update record visibility"""
        try:
            # First check if user owns the record
            record = self.es.get(index=self.indices['records'], id=record_id)
            if record['_source']['owner_user_id'] != user_id:
                return {'success': False, 'error': 'Not authorized'}
            
            self.es.update(
                index=self.indices['records'],
                id=record_id,
                body={
                    'doc': {
                        'visibility': visibility,
                        'updated_at': datetime.now().isoformat()
                    }
                }
            )
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def update_record_tags(self, record_id: str, user_id: str, tags: List[str]) -> Dict:
        """Add tags to a record (owner-only)."""
        try:
            # Load record and verify ownership
            res = self.es.get(index=self.indices['records'], id=record_id)
            source = res.get('_source', {})
            if source.get('owner_user_id') != user_id:
                return {'success': False, 'error': 'Not authorized'}

            existing = set((source.get('tags') or []))
            incoming = set([t for t in (tags or []) if isinstance(t, str) and t.strip()])
            updated = list(existing.union(incoming))

            self.es.update(
                index=self.indices['records'],
                id=record_id,
                body={'doc': {'tags': updated, 'updated_at': datetime.now().isoformat()}}
            )
            return {'success': True, 'tags': updated}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def remove_record_tags(self, record_id: str, user_id: str, tags: List[str]) -> Dict:
        """Remove tags from a record (owner-only)."""
        try:
            res = self.es.get(index=self.indices['records'], id=record_id)
            source = res.get('_source', {})
            if source.get('owner_user_id') != user_id:
                return {'success': False, 'error': 'Not authorized'}

            to_remove = set([t for t in (tags or []) if isinstance(t, str)])
            if not to_remove:
                return {'success': True, 'tags': source.get('tags') or []}

            existing = source.get('tags') or []
            updated = [t for t in existing if t not in to_remove]

            self.es.update(
                index=self.indices['records'],
                id=record_id,
                body={'doc': {'tags': updated, 'updated_at': datetime.now().isoformat()}}
            )
            return {'success': True, 'tags': updated}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def store_record_chunks(self, record_id: str, chunk_embeddings: List[Dict[str, Any]], 
                           user_id: str, team_id: str, visibility: str):
        """Store chunk embeddings in the database"""
        try:
            for chunk_data in chunk_embeddings:
                chunk_id = str(uuid.uuid4())
                
                chunk_doc = {
                    'chunk_id': chunk_id,
                    'record_id': record_id,
                    'owner_user_id': user_id,
                    'team_id': team_id,
                    'visibility': visibility,
                    'start_line': chunk_data.get('start_line', 0),
                    'end_line': chunk_data.get('end_line', 0),
                    'is_error_window': chunk_data.get('is_error_window', False),
                    'text': chunk_data.get('text', ''),
                    'summary': chunk_data.get('summary', ''),
                    'signals': chunk_data.get('signals', []),
                    'embedding': chunk_data.get('embedding', []),
                    'created_at': datetime.now().isoformat()
                }
                
                self.es.index(
                    index=self.indices['record_chunks'],
                    id=chunk_id,
                    body=chunk_doc
                )
                
        except Exception as e:
            print(f"Error storing record chunks: {e}")
