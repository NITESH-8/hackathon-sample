import requests
import json
from typing import Dict, List, Any, Optional
import uuid
from datetime import datetime
from .database import DatabaseManager
import os

class GenAPIService:
    def __init__(self):
        # Read from environment; fallback to empty so we can detect misconfig
        self.api_key = os.getenv('GENAPI_KEY', '').strip()
        self.base_url = os.getenv('GENAPI_URL', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent').strip()
        self.db = DatabaseManager()
    
    def analyze_log(self, processed_file_path: str, context: str = '') -> Dict[str, Any]:
        """
        Stage 7: Analyze log using GenAPI
        """
        try:
            # Read processed file
            with open(processed_file_path, 'r', encoding='utf-8') as f:
                log_content = f.read()
            
            # Prepare prompt for GenAPI
            prompt = self._create_analysis_prompt(log_content, context)
            
            # Call GenAPI (simulated for now)
            analysis_result = self._call_genapi(prompt)
            
            # Parse and structure the response
            structured_analysis = self._parse_analysis_response(analysis_result)
            
            return structured_analysis
            
        except Exception as e:
            print(f"Error analyzing log with GenAPI: {e}")
            return self._create_fallback_analysis()
    
    def _create_analysis_prompt(self, log_content: str, context: str) -> str:
        """Create a comprehensive prompt for log analysis"""
        # Use string concatenation instead of f-string to avoid format specifier issues
        prompt = """
        Analyze the following processed log file and provide a structured JSON output.

        User Context (use this to guide the analysis, naming, and focus):
        """ + (context if context else "No additional context provided.") + """

        Log Content:
        """ + log_content + """

        Output Format:
        {
        "summary": "Overall summary of the log analysis (reflect user context if relevant)",
        "problems": [
            {
            "problem_id": "unique_id",
            "title": "Problem title",
            "severity": 0-100,           // A number representing how severe the issue is
            "root_cause": "Explanation of what caused the issue",
            "signals": ["error", "timeout", "exception"],  // Keywords or signals associated with the issue
            "raw_log": [                 // List of relevant log lines showing the error
                "2025-09-10 12:15:22 [ERROR] Something went wrong...",
                "... more log lines ..."
            ],
            "recommendations": "Specific action steps or modules to resolve the issue"
            }
        ],
        "overall_severity": 0-100,       // Overall severity of the log
        "key_insights": [
            "Short key insight 1",
            "Short key insight 2"
        ],
        "recommendations": [
            "General recommendation 1",
            "General recommendation 2"
        ]
        }

        Requirements:
        - Detect and return multiple issues separately.
        - Do NOT include line numbers.
        - For each problem, include the raw log snippet relevant to it.
        - Keep the JSON clean, accurate, and complete.
        - Respect the User Context. If the context asks for a concise bug name or emphasis, reflect it in the summary and problem titles without changing the schema.
        - If the log appears healthy or no significant issues are detected, set "problems": [] and provide a detailed, plain-English summary explaining normal behavior and why no problems were found. In that case, set "overall_severity" near 0 and omit problem sections entirely.

        """
        return prompt
    
    def _call_genapi(self, prompt: str) -> Dict[str, Any]:
        """Call real GenAPI (Gemini) if configured; otherwise return fallback mock."""
        try:
            if not self.api_key or not self.base_url:
                raise ValueError("GENAPI_KEY/GENAPI_URL not configured")

            # Gemini Generate Content format
            url = self.base_url
            if 'generativelanguage.googleapis.com' in url and 'key=' not in url:
                connector = '&' if '?' in url else '?'
                url = f"{url}{connector}key={self.api_key}"

            payload = {
                "contents": [
                    {
                        "parts": [{"text": prompt}]
                    }
                ]
            }
            headers = {"Content-Type": "application/json"}
            resp = requests.post(url, headers=headers, json=payload, timeout=60)
            resp.raise_for_status()
            data = resp.json()

            # Try to extract text
            text = None
            try:
                text = data["candidates"][0]["content"]["parts"][0]["text"]
            except Exception:
                # Some providers use different shapes
                text = json.dumps(data)

            # If the model returned structured JSON, parse it; otherwise wrap in summary
            try:
                # Handle markdown code blocks
                if text.startswith('```json'):
                    # Extract JSON from markdown code block
                    json_start = text.find('```json') + 7
                    json_end = text.find('```', json_start)
                    if json_end > json_start:
                        text = text[json_start:json_end].strip()
                elif text.startswith('```'):
                    # Extract JSON from generic code block
                    json_start = text.find('```') + 3
                    json_end = text.find('```', json_start)
                    if json_end > json_start:
                        text = text[json_start:json_end].strip()
                
                parsed = json.loads(text)
                if isinstance(parsed, dict) and ("summary" in parsed or "problems" in parsed):
                    return parsed
            except Exception:
                pass

            return {
                "summary": text or "GenAPI returned no content.",
                "problems": [],
                "overall_severity": 0,
                "key_insights": [],
                "recommendations": []
            }
        except Exception as e:
            # Fall back to lightweight heuristic if API not configured/failed
            if "ERROR DETECTED" in prompt:
                return {
                    "summary": "Log analysis completed. Multiple errors detected requiring attention.",
                    "problems": [
                        {
                            "problem_id": str(uuid.uuid4()),
                            "title": "System Error Detected",
                            "severity": 85,
                            "root_cause": "Critical system error requiring immediate attention",
                            "signals": ["error", "critical"],
                            "recommendations": "Check system logs and restart affected services"
                        }
                    ],
                    "overall_severity": 85,
                    "key_insights": ["Multiple error patterns detected"],
                    "recommendations": ["Review error patterns for root cause"]
                }
            return {
                "summary": f"GenAPI call failed: {str(e)}",
                "problems": [],
                "overall_severity": 0,
                "key_insights": [],
                "recommendations": []
            }
    
    def _parse_analysis_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Parse and structure the GenAPI response"""
        try:
            # Ensure all required fields are present
            structured_response = {
                "analyzed": True,
                "result_version": 1,
                "summary": response.get("summary", "Analysis completed"),
                "problems": response.get("problems", []),
                "overall_severity": response.get("overall_severity", 0),
                "key_insights": response.get("key_insights", []),
                "recommendations": response.get("recommendations", []),
                "analyzed_at": datetime.now().isoformat()
            }
            
            # Ensure problems have required fields
            for problem in structured_response["problems"]:
                if "problem_id" not in problem:
                    problem["problem_id"] = str(uuid.uuid4())
                if "signals" not in problem:
                    problem["signals"] = []
                if "recommendations" not in problem:
                    problem["recommendations"] = "No specific recommendations available"
            
            return structured_response
            
        except Exception as e:
            print(f"Error parsing analysis response: {e}")
            return self._create_fallback_analysis()
    
    def _create_fallback_analysis(self) -> Dict[str, Any]:
        """Create a fallback analysis when GenAPI fails"""
        return {
            "analyzed": True,
            "result_version": 1,
            "summary": "Log analysis completed with basic processing",
            "problems": [],
            "overall_severity": 0,
            "key_insights": ["Basic analysis completed"],
            "recommendations": ["Review log manually for detailed analysis"],
            "analyzed_at": datetime.now().isoformat(),
            "fallback": True
        }
    
    def handle_question(self, question: str, record_id: str, user_id: str, team_id: str, 
                       conversation_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Stage 8: Handle user questions (DB query or GenAPI call)
        """
        try:
            # Determine if question needs DB query or GenAPI call
            question_type = self._classify_question(question)
            
            if question_type == "database":
                return self._handle_database_question(question, record_id, user_id, team_id)
            else:
                return self._handle_genapi_question(question, record_id, user_id, team_id, conversation_id)
                
        except Exception as e:
            print(f"Error handling question: {e}")
            return {
                "success": False,
                "error": str(e),
                "response": "I'm sorry, I encountered an error processing your question."
            }
    
    def _classify_question(self, question: str) -> str:
        """Classify question as database or GenAPI type"""
        question_lower = question.lower()
        
        # Database query indicators
        db_indicators = [
            "how many", "count", "list all", "show me all", "find all",
            "from last", "in the past", "between", "since", "until",
            "records", "logs", "files", "history", "previous"
        ]
        
        # GenAPI indicators
        genapi_indicators = [
            "explain", "what is", "why", "how does", "tell me about",
            "analyze", "interpret", "meaning", "cause", "reason",
            "recommend", "suggest", "help", "fix", "resolve"
        ]
        
        # Check for database indicators
        for indicator in db_indicators:
            if indicator in question_lower:
                return "database"
        
        # Check for GenAPI indicators
        for indicator in genapi_indicators:
            if indicator in question_lower:
                return "genapi"
        
        # Default to GenAPI for complex questions
        return "genapi"
    
    def _handle_database_question(self, question: str, record_id: str, user_id: str, team_id: str) -> Dict[str, Any]:
        """Handle database-related questions"""
        try:
            # Parse question to extract query parameters
            query_params = self._parse_database_question(question)
            
            # Execute database query
            results = self._execute_database_query(query_params, user_id, team_id)
            
            # Format response
            response = self._format_database_response(question, results)
            
            return {
                "success": True,
                "response": response,
                "question_type": "database",
                "results": results
            }
            
        except Exception as e:
            print(f"Error handling database question: {e}")
            return {
                "success": False,
                "error": str(e),
                "response": "I'm sorry, I couldn't process your database query."
            }
    
    def _handle_genapi_question(self, question: str, record_id: str, user_id: str, team_id: str, 
                               conversation_id: Optional[str]) -> Dict[str, Any]:
        """Handle GenAPI-related questions"""
        try:
            # Get record data
            record = self.db.get_record(record_id, user_id, team_id)
            if not record:
                return {
                    "success": False,
                    "error": "Record not found",
                    "response": "I couldn't find the record you're asking about."
                }
            
            # Read processed file
            with open(record['processed_file_path'], 'r', encoding='utf-8') as f:
                log_content = f.read()
            
            # Create prompt for the question
            prompt = self._create_question_prompt(question, log_content, record.get('context', ''))
            
            # Call GenAPI
            response = self._call_genapi(prompt)
            
            # Store conversation if conversation_id provided
            if conversation_id:
                self._store_conversation_message(conversation_id, question, response.get('summary', ''), user_id, team_id)
            
            return {
                "success": True,
                "response": response.get('summary', 'No response generated'),
                "question_type": "genapi",
                "conversation_id": conversation_id
            }
            
        except Exception as e:
            print(f"Error handling GenAPI question: {e}")
            return {
                "success": False,
                "error": str(e),
                "response": "I'm sorry, I couldn't process your question."
            }
    
    def _parse_database_question(self, question: str) -> Dict[str, Any]:
        """Parse database question to extract query parameters"""
        # Simple parsing - can be enhanced with NLP
        question_lower = question.lower()
        
        params = {
            "time_range": None,
            "severity_filter": None,
            "category_filter": None,
            "limit": 10
        }
        
        # Extract time range
        if "last month" in question_lower:
            params["time_range"] = "1M"
        elif "last week" in question_lower:
            params["time_range"] = "1w"
        elif "last day" in question_lower:
            params["time_range"] = "1d"
        
        # Extract severity
        if "critical" in question_lower:
            params["severity_filter"] = "critical"
        elif "high" in question_lower:
            params["severity_filter"] = "high"
        elif "error" in question_lower:
            params["severity_filter"] = "error"
        
        return params
    
    def _execute_database_query(self, params: Dict[str, Any], user_id: str, team_id: str) -> List[Dict[str, Any]]:
        """Execute database query based on parameters"""
        try:
            # Build Elasticsearch query
            query = {
                "query": {
                    "bool": {
                        "should": [
                            {"term": {"owner_user_id": user_id}},
                            {
                                "bool": {
                                    "must": [
                                        {"term": {"team_id": team_id}},
                                        {"term": {"visibility": "team"}}
                                    ]
                                }
                            },
                            {"term": {"visibility": "public"}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "size": params.get("limit", 10)
            }
            
            # Add severity filter if specified
            if params.get("severity_filter"):
                severity_map = {
                    "critical": 90,
                    "high": 70,
                    "error": 50
                }
                min_severity = severity_map.get(params["severity_filter"], 0)
                query["query"]["bool"]["must"] = [
                    {"range": {"overall_severity": {"gte": min_severity}}}
                ]
            
            result = self.db.es.search(index=self.db.indices['records'], body=query)
            return [hit['_source'] for hit in result['hits']['hits']]
            
        except Exception as e:
            print(f"Error executing database query: {e}")
            return []
    
    def _format_database_response(self, question: str, results: List[Dict[str, Any]]) -> str:
        """Format database query results into a readable response"""
        if not results:
            return "No records found matching your criteria."
        
        response = f"Found {len(results)} records:\n\n"
        
        for i, record in enumerate(results[:5], 1):  # Show top 5
            response += f"{i}. {record.get('title', 'Untitled')}\n"
            response += f"   Severity: {record.get('overall_severity', 0)}/100\n"
            response += f"   Created: {record.get('created_at', 'Unknown')}\n"
            response += f"   Summary: {record.get('overall_summary', 'No summary')[:100]}...\n\n"
        
        if len(results) > 5:
            response += f"... and {len(results) - 5} more records."
        
        return response
    
    def _create_question_prompt(self, question: str, log_content: str, context: str) -> str:
        """Create prompt for question answering"""
        return f"""
        Answer the following question about the log file:
        
        Question: {question}
        
        Context: {context if context else 'No additional context provided'}
        
        Log Content:
        {log_content}
        
        Please provide a clear, helpful answer based on the log content.
        """
    
    def _store_conversation_message(self, conversation_id: str, question: str, response: str, 
                                   user_id: str, team_id: str):
        """Store conversation message in database"""
        try:
            message_id = str(uuid.uuid4())
            message = {
                "msg_id": message_id,
                "role": "user",
                "text": question,
                "created_at": datetime.now().isoformat()
            }
            
            # Add user message
            self.db.es.update(
                index=self.db.indices['conversations'],
                id=conversation_id,
                body={
                    "script": {
                        "source": "ctx._source.messages.add(params.message); ctx._source.last_activity_at = params.timestamp",
                        "params": {
                            "message": message,
                            "timestamp": datetime.now().isoformat()
                        }
                    }
                }
            )
            
            # Add assistant response
            response_message = {
                "msg_id": str(uuid.uuid4()),
                "role": "assistant",
                "text": response,
                "created_at": datetime.now().isoformat()
            }
            
            self.db.es.update(
                index=self.db.indices['conversations'],
                id=conversation_id,
                body={
                    "script": {
                        "source": "ctx._source.messages.add(params.message); ctx._source.last_activity_at = params.timestamp",
                        "params": {
                            "message": response_message,
                            "timestamp": datetime.now().isoformat()
                        }
                    }
                }
            )
            
        except Exception as e:
            print(f"Error storing conversation message: {e}")
    
    def ask_question(self, question: str, context: str) -> str:
        """Ask a question about a log and get AI response"""
        try:
            # Create a chat prompt
            prompt = self._create_chat_prompt(question, context)
            
            # Call GenAPI
            response = self._call_genapi(prompt)
            
            # Extract text response
            if isinstance(response, dict):
                return response.get('summary', response.get('answer', response.get('response', 'No response available')))
            else:
                return str(response)
                
        except Exception as e:
            print(f"Error asking question: {e}")
            return f"I apologize, but I encountered an error while processing your question: {str(e)}"
    
    def _create_chat_prompt(self, question: str, context: str) -> str:
        """Create a prompt for chat interaction"""
        prompt = f"""You are an AI assistant specialized in log analysis. A user is asking a question about a log file.

Context Information:
{context}

User Question: {question}

Please provide a helpful, detailed answer based on the log information provided. If the question is about:
- When the log was uploaded: Use the "Created" timestamp from the context
- Log content: Reference the actual log content provided
- Problems found: Reference the identified problems and their details
- General analysis: Use the previous analysis summary and insights

Be conversational, helpful, and specific. If you need more information to answer the question, ask for clarification.

Answer:"""
        
        return prompt
