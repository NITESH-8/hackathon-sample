from __future__ import annotations

import csv
import os
import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from PySide6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from .data_sources import Subsystem, get_timestamp, get_cpu_core_count, get_cpu_core_percent
from .comm_console import CommConsole


class TimeAxis(pg.AxisItem):
	"""Custom bottom axis that formats seconds to friendly time strings.

	- < 60s: show seconds with optional decimals (e.g., 12s, 12.5s)
	- 1–60 min: show mm:ss (e.g., 2:05)
	- >= 60 min: show h:mm (e.g., 1h05m)
	"""

	def tickStrings(self, values, scale, spacing):  # type: ignore[override]
		# Be defensive: PyQtGraph may call with None/0 values during layout
		labels: List[str] = []
		try:
			sc = float(scale) if isinstance(scale, (int, float)) else 1.0
			sps = float(spacing) if isinstance(spacing, (int, float)) and float(spacing) > 0 else 1.0
		except Exception:
			sc = 1.0
			sps = 1.0
		for v in values:
			try:
				sec = float(v) * sc
			except Exception:
				sec = 0.0
			if sec >= 3600:
				hours = int(sec // 3600)
				minutes = int((sec % 3600) // 60)
				labels.append(f"{hours}h{minutes:02d}m")
			elif sec >= 60:
				minutes = int(sec // 60)
				seconds = int(sec % 60)
				labels.append(f"{minutes}:{seconds:02d}")
			else:
				# show 1 decimal when spacing is small
				if sps < 1:
					labels.append(f"{sec:.1f}s")
				else:
					labels.append(f"{int(sec)}s")
		return labels


def _nice_tick_seconds(raw_step: float) -> float:
	"""Return a 'nice' tick step in seconds close to raw_step.

	Uses 1-2-5 progression scaled by powers of 10.
	"""
	if raw_step <= 0:
		return 1.0
	import math
	exp = math.floor(math.log10(raw_step))
	frac = raw_step / (10 ** exp)
	if frac < 1.5:
		nice = 1.0
	elif frac < 3.5:
		nice = 2.0
	elif frac < 7.5:
		nice = 5.0
	else:
		nice = 10.0
	return nice * (10 ** exp)


SUBSYSTEMS = [Subsystem.CPU, Subsystem.GPU, Subsystem.DRAM]


@dataclass
class SubsystemState:
	name: str
	target_percent: int = 50
	values: List[Tuple[float, float]] = field(default_factory=list)
	curve: Optional[pg.PlotDataItem] = None
	target_line: Optional[pg.InfiniteLine] = None


@dataclass
class CoreState:
	core_id: int
	target_percent: int = 50
	values: List[Tuple[float, float]] = field(default_factory=list)
	curve: Optional[pg.PlotDataItem] = None
	target_line: Optional[pg.InfiniteLine] = None


class PerformanceApp(QtWidgets.QMainWindow):
	def __init__(self) -> None:
		super().__init__()
		self.setWindowTitle("Performance Dashboard")
		self.resize(1200, 720)

		self.states: Dict[str, SubsystemState] = {name: SubsystemState(name=name) for name in SUBSYSTEMS}
		self.core_states: Dict[int, CoreState] = {}
		self.active_subsystems: List[str] = []
		self.active_cores: List[int] = []
		self.is_running: bool = False
		self.end_time_epoch: Optional[float] = None

		self.process: Optional[QtCore.QProcess] = None
		self.line_buffer: bytes = b""

		# Initialize CPU cores
		self._init_cpu_cores()
		
		# Initialize scheduling system
		# Each entry: (time_offset_seconds, subsystem, target_value, mode)
		# mode: "sudden" or "harmonic"
		self.scheduled_changes: List[Tuple[float, str, int, str]] = []
		self.schedule_timer: Optional[QtCore.QTimer] = None
		self.test_start_time: Optional[float] = None
		# Active harmonic ramps: subsystem -> (start_time_s, end_time_s, start_value, end_value)
		self.active_harmonics: Dict[str, Tuple[float, float, int, int]] = {}

		self._build_ui()
		self._build_toolbar()
		self._configure_plot()
		# Initialize the active combo with all subsystems
		self._rebuild_active_combo()
		# Start maximized with window controls visible
		self.showMaximized()
		self._apply_dark_theme()
		# Internal sampler (used when no external command is needed)
		self._sample_timer = QtCore.QTimer(self)
		self._sample_timer.setInterval(500)
		self._sample_timer.timeout.connect(self._sample_metrics)
		# File tail reader for stress tool output
		self._file_tail_timer = QtCore.QTimer(self)
		self._file_tail_timer.setInterval(500)
		self._file_tail_timer.timeout.connect(self._read_stress_file_tail)
		self._file_tail_path: Optional[str] = None
		self._file_tail_pos: int = 0
		self._file_tail_rem: bytes = b""
		self._file_block_idx: int = -1
		self._file_start_epoch: float = 0.0
		self._file_watcher = QtCore.QFileSystemWatcher(self)
		self._file_watcher.fileChanged.connect(lambda _p: self._read_stress_file_tail())
		# Block playback queue and scheduler (emit blocks every 5s)
		self._block_queue: List[Tuple[Optional[float], Dict[int, float], Optional[float], Optional[float]]] = []
		self._next_block_due_epoch: Optional[float] = None
		self._block_timer = QtCore.QTimer(self)
		self._block_timer.setInterval(250)
		self._block_timer.timeout.connect(self._maybe_emit_block)
		# Persistent parse state for partial blocks across timer ticks
		self._blk_active: bool = False
		self._blk_cpu_overall: Optional[float] = None
		self._blk_core_vals: Dict[int, float] = {}
		self._blk_dram_val: Optional[float] = None
		self._blk_gpu_val: Optional[float] = None

	# No app-level event filter required; handled inside CommConsole

	def _init_cpu_cores(self) -> None:
		"""Initialize CPU core states."""
		core_count = get_cpu_core_count()
		self.core_states = {i: CoreState(core_id=i) for i in range(core_count)}

	def _build_ui(self) -> None:
		central = QtWidgets.QWidget(self)
		central.setObjectName("rootCentral")
		self.setCentralWidget(central)

		root = QtWidgets.QHBoxLayout(central)

		# Left panel inside a scroll area to avoid forcing huge window height
		controls_scroll = QtWidgets.QScrollArea()
		controls_scroll.setWidgetResizable(True)
		controls_container = QtWidgets.QWidget()
		controls_container.setObjectName("controlsContainer")
		controls = QtWidgets.QVBoxLayout(controls_container)
		controls.setContentsMargins(10, 10, 10, 10)
		controls.setSpacing(10)
		controls_scroll.setWidget(controls_container)
		# Keep reference for collapse/expand animation
		self.controls_scroll = controls_scroll
		self.controls_container = controls_container
		self.controls_collapsed = False
		self.controls_initial_width = 320
		controls_scroll.setMinimumWidth(0)
		controls_scroll.setMaximumWidth(self.controls_initial_width)
		controls_scroll.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
		root.addWidget(controls_scroll, 0)
		# Slider-like handle next to the panel to toggle visibility (top-right aligned)
		handle = QtWidgets.QToolButton()
		handle.setObjectName("panelHandle")
		handle.setCheckable(True)
		handle.setChecked(True)
		handle.setFixedWidth(36)
		handle.setFixedHeight(36)
		handle.setText("")
		handle.setArrowType(QtCore.Qt.LeftArrow)
		handle.setAutoRaise(True)
		handle.setIconSize(QtCore.QSize(20, 20))
		handle.setToolTip("Hide/Show controls")
		handle.toggled.connect(lambda _: self._toggle_controls())
		self.panel_handle = handle
		handle_container = QtWidgets.QWidget()
		handle_container.setFixedWidth(40)
		vc = QtWidgets.QVBoxLayout(handle_container)
		vc.setContentsMargins(2, 4, 2, 0)
		vc.setSpacing(0)
		vc.addWidget(handle, 0, QtCore.Qt.AlignTop)
		vc.addStretch(1)
		root.addWidget(handle_container, 0)

		# Subsystems group
		sys_group = QtWidgets.QGroupBox("Subsystems")
		sys_layout = QtWidgets.QVBoxLayout(sys_group)
		sys_layout.setContentsMargins(10, 8, 10, 10)
		sys_layout.setSpacing(6)
		self.checkbox_group: Dict[str, QtWidgets.QCheckBox] = {}
		for name in SUBSYSTEMS:
			cb = QtWidgets.QCheckBox(name)
			cb.setToolTip(f"Toggle {name} tracking and target controls")
			cb.stateChanged.connect(self._on_subsystem_toggled)
			sys_layout.addWidget(cb)
			self.checkbox_group[name] = cb
		controls.addWidget(sys_group)

		# CPU Cores section (initially hidden)
		controls.addSpacing(8)
		self.cpu_cores_group = QtWidgets.QGroupBox("CPU Cores")
		self.cpu_cores_group.setVisible(False)
		cores_layout = QtWidgets.QVBoxLayout(self.cpu_cores_group)
		cores_layout.setContentsMargins(10, 8, 10, 10)
		cores_layout.setSpacing(4)
		
		# Header above cores to label slider column
		header_row = QtWidgets.QHBoxLayout()
		header_row.setSpacing(6)
		header_row.addWidget(QtWidgets.QLabel(""))  # spacer for checkbox column
		header_target = QtWidgets.QLabel("Target (%)")
		header_row.addWidget(header_target)
		header_row.addWidget(QtWidgets.QLabel(""))  # spacer for live value column
		header_row.addStretch(1)
		cores_layout.addLayout(header_row)
		
		self.core_checkboxes: Dict[int, QtWidgets.QCheckBox] = {}
		self.core_sliders: Dict[int, QtWidgets.QSlider] = {}
		self.core_labels: Dict[int, QtWidgets.QLabel] = {}
		self.core_texts: Dict[int, QtWidgets.QLineEdit] = {}
		controls.addWidget(self._make_label("Targets (%)", bold=True))
		# CPU Target row (replaces Core 0)
		cpu_target_row = QtWidgets.QHBoxLayout()
		cpu_target_cb = QtWidgets.QCheckBox("CPU Target")
		cpu_target_cb.stateChanged.connect(self._on_cpu_target_toggled)
		cpu_target_row.addWidget(cpu_target_cb)
		self.cpu_target_checkbox = cpu_target_cb
		
		# CPU Target slider
		cpu_target_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
		cpu_target_slider.setRange(0, 100)
		cpu_target_slider.setValue(self.states[Subsystem.CPU].target_percent)
		cpu_target_slider.setMinimumWidth(120)
		cpu_target_slider.setMaximumWidth(16777215)
		cpu_target_slider.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
		cpu_target_slider.valueChanged.connect(lambda val: self._on_cpu_target_changed(val))
		cpu_target_row.addWidget(cpu_target_slider)
		self.cpu_target_slider = cpu_target_slider
		cpu_target_slider.setVisible(False)
		
		# CPU Target text box
		cpu_target_text = QtWidgets.QLineEdit(str(self.states[Subsystem.CPU].target_percent))
		cpu_target_text.setValidator(QtGui.QIntValidator(0, 100, self))
		cpu_target_text.setFixedWidth(40)
		cpu_target_text.setAlignment(QtCore.Qt.AlignCenter)
		cpu_target_slider.valueChanged.connect(lambda val, field=cpu_target_text: field.setText(str(int(val))))
		def _apply_cpu_target_txt():
			try:
				val_int = int(cpu_target_text.text() or 0)
				val_int = max(0, min(100, val_int))
				if cpu_target_slider.value() != val_int:
					cpu_target_slider.setValue(val_int)
			except Exception:
				pass
		cpu_target_text.editingFinished.connect(_apply_cpu_target_txt)
		cpu_target_row.addWidget(cpu_target_text)
		self.cpu_target_text = cpu_target_text
		
		cpu_target_row.addStretch(1)
		cores_layout.addLayout(cpu_target_row)
		
		# CPU cores 0-6 (7 cores total)
		for core_id in range(7):
			# Create horizontal layout for each core
			core_row = QtWidgets.QHBoxLayout()
			core_row.setSpacing(6)
			
			# Checkbox
			cb = QtWidgets.QCheckBox(f"Core {core_id}")
			cb.stateChanged.connect(self._on_core_toggled)
			core_row.addWidget(cb)
			self.core_checkboxes[core_id] = cb
			
			# Slider
			slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
			slider.setRange(0, 100)
			slider.setValue(self.core_states[core_id].target_percent)
			slider.setMinimumWidth(120)
			slider.setMaximumWidth(16777215)
			slider.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
			slider.valueChanged.connect(lambda val, cid=core_id: self._on_core_target_changed(cid, val))
			core_row.addWidget(slider)
			self.core_sliders[core_id] = slider
			slider.setVisible(False)
			
			# Editable percent to the right of slider
			txt = QtWidgets.QLineEdit(str(self.core_states[core_id].target_percent))
			txt.setValidator(QtGui.QIntValidator(0, 100, self))
			txt.setFixedWidth(40)
			txt.setAlignment(QtCore.Qt.AlignCenter)
			slider.valueChanged.connect(lambda val, field=txt: field.setText(str(int(val))))
			def _apply_txt(cid=core_id, field_ref=None):
				# On edit, push to slider and target
				try:
					val_int = int((field_ref or txt).text() or 0)
					val_int = max(0, min(100, val_int))
					sel_slider = self.core_sliders[cid]
					if sel_slider.value() != val_int:
						sel_slider.setValue(val_int)
				except Exception:
					pass
			txt.editingFinished.connect(lambda cid=core_id, field_ref=txt: _apply_txt(cid, field_ref))
			core_row.addWidget(txt)
			self.core_texts[core_id] = txt
			
			# Add stretch to push everything to the left
			core_row.addStretch(1)
			
			cores_layout.addLayout(core_row)
		
		controls.addWidget(self.cpu_cores_group)

		controls.addSpacing(8)
		self.slider_container = QtWidgets.QWidget()
		self.slider_form = QtWidgets.QFormLayout(self.slider_container)
		self.slider_form.setFieldGrowthPolicy(QtWidgets.QFormLayout.ExpandingFieldsGrow)
		self.slider_form.setHorizontalSpacing(10)
		self.slider_form.setVerticalSpacing(6)
		controls.addWidget(self.slider_container, 0)

		# User Setup group
		controls.addSpacing(8)
		user_group = QtWidgets.QGroupBox("User Setup")
		user_group.setObjectName("userGroup")
		user_v = QtWidgets.QVBoxLayout(user_group)
		user_v.setContentsMargins(10, 8, 10, 10)
		user_v.addWidget(self._make_label("Duration", bold=True))
		duration_row = QtWidgets.QHBoxLayout()
		self.duration_spin = QtWidgets.QSpinBox()
		self.duration_spin.setRange(1, 24 * 60 * 60)
		self.duration_spin.setValue(60)
		self.duration_spin.setSuffix(" s")
		duration_row.addWidget(self.duration_spin)
		user_v.addLayout(duration_row)
		# Log file path input
		log_file_row = QtWidgets.QHBoxLayout()
		log_file_row.addWidget(self._make_label("Log file path:"))
		self.log_file_edit = QtWidgets.QLineEdit()
		self.log_file_edit.setText(os.path.join(os.getcwd(), "random_output", "stress_too_output.txt"))
		self.log_file_edit.setToolTip("Full path to the stress tool output file")
		log_file_row.addWidget(self.log_file_edit)
		user_v.addLayout(log_file_row)
		# Slider + editable text field synced with the spinbox
		slider_row = QtWidgets.QHBoxLayout()
		self.duration_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
		self.duration_slider.setRange(1, 3600)
		self.duration_slider.setValue(60)
		slider_row.addWidget(self.duration_slider, 1)
		self.duration_text = QtWidgets.QLineEdit()
		self.duration_text.setFixedWidth(64)
		self.duration_text.setText("60")
		self.duration_text.setValidator(QtGui.QIntValidator(1, 24 * 60 * 60, self))
		slider_row.addWidget(self.duration_text)
		user_v.addLayout(slider_row)
		# Wiring: keep all three in sync
		self.duration_slider.valueChanged.connect(lambda v: (self.duration_spin.setValue(int(v)), self._update_command_preview()))
		self.duration_spin.valueChanged.connect(lambda v: (self.duration_text.setText(str(int(v))), self._update_command_preview()))
		self.duration_spin.valueChanged.connect(lambda v: (self.duration_slider.setValue(int(v)) if 1 <= int(v) <= 3600 else None))
		self.duration_text.editingFinished.connect(lambda: (self.duration_spin.setValue(int(self.duration_text.text() or 60)), self._update_command_preview()))
		# Generated command preview (for Linux stress tool)
		user_v.addWidget(self._make_label("Generated command (auto-updates):", bold=True))
		cmd_row = QtWidgets.QHBoxLayout()
		self.command_preview = QtWidgets.QTextEdit()
		self.command_preview.setObjectName("commandPreview")
		mono = QtGui.QFont()
		mono.setFamily("Consolas")
		mono.setPointSize(10)
		self.command_preview.setFont(mono)
		self.command_preview.setReadOnly(True)
		self.command_preview.setLineWrapMode(QtWidgets.QTextEdit.WidgetWidth)
		self.command_preview.setFixedHeight(72)
		cmd_row.addWidget(self.command_preview, 1)
		self.btn_copy_cmd = QtWidgets.QToolButton()
		self.btn_copy_cmd.setText("Copy")
		self.btn_copy_cmd.setToolTip("Copy command to clipboard")
		self.btn_copy_cmd.clicked.connect(lambda: QtWidgets.QApplication.clipboard().setText(self.command_preview.toPlainText()))
		cmd_row.addWidget(self.btn_copy_cmd)
		user_v.addLayout(cmd_row)
		
		# Test mode removed
		controls.addWidget(user_group)

		# Actions moved to toolbar; keep object handles for shortcuts
		self.btn_start = QtWidgets.QPushButton()
		self.btn_start.clicked.connect(self._on_start)
		self.btn_stop = QtWidgets.QPushButton()
		self.btn_stop.clicked.connect(self._on_stop)
		self.btn_clear = QtWidgets.QPushButton()
		self.btn_clear.clicked.connect(self._on_clear)
		self.btn_export_csv = QtWidgets.QPushButton()
		self.btn_export_csv.clicked.connect(self._on_export_csv)
		self.btn_export_png = QtWidgets.QPushButton()
		self.btn_export_png.clicked.connect(self._on_export_png)
		self.btn_schedule_load = QtWidgets.QPushButton()
		self.btn_schedule_load.clicked.connect(self._on_schedule_load)
		# Shortcuts
		QtGui.QShortcut(QtGui.QKeySequence("Ctrl+R"), self, activated=self._on_start)
		QtGui.QShortcut(QtGui.QKeySequence("Escape"), self, activated=self._on_stop)
		QtGui.QShortcut(QtGui.QKeySequence("Ctrl+S"), self, activated=self._on_export_csv)
		QtGui.QShortcut(QtGui.QKeySequence("Ctrl+P"), self, activated=self._on_export_png)
		controls.addStretch(1)

		# View Data card (replaces Current Values)
		values_group = QtWidgets.QGroupBox("View Data")
		values_layout = QtWidgets.QVBoxLayout(values_group)
		values_layout.setContentsMargins(8, 6, 8, 8)
		# Toggle button
		toggle_row = QtWidgets.QHBoxLayout()
		self.view_data_btn = QtWidgets.QPushButton("Show Log")
		self.view_data_btn.clicked.connect(self._open_log_dialog)
		toggle_row.addWidget(self.view_data_btn)
		toggle_row.addStretch(1)
		values_layout.addLayout(toggle_row)
		# Keep compact list inside the card
		self.numeric_list = QtWidgets.QListWidget()
		self.numeric_list.setMinimumWidth(260)
		self.numeric_list.setAlternatingRowColors(True)
		values_layout.addWidget(self.numeric_list)
		controls.addWidget(values_group, 1)

		right = QtWidgets.QVBoxLayout()
		root.addLayout(right, 1)

		select_row = QtWidgets.QHBoxLayout()
		select_row.addWidget(self._make_label("Active graph:"))
		self.combo_active = QtWidgets.QComboBox()
		self.combo_active.currentTextChanged.connect(self._on_active_changed)
		select_row.addWidget(self.combo_active)
		select_row.addStretch(1)
		# KPI header chips (clickable)
		self.kpi_cpu = self._create_kpi_label("CPU")
		self.kpi_gpu = self._create_kpi_label("GPU")
		self.kpi_dram = self._create_kpi_label("DRAM")
		select_row.addWidget(self.kpi_cpu)
		select_row.addWidget(self.kpi_gpu)
		select_row.addWidget(self.kpi_dram)
		select_row.addStretch(1)
		# Tail status (debug)
		self.tail_status = QtWidgets.QLabel("")
		self.tail_status.setMinimumWidth(140)
		select_row.addWidget(self.tail_status)
		# Toggle UART / Graph button
		self.btn_uart_toggle = QtWidgets.QPushButton("Access UART")
		self.btn_uart_toggle.setCheckable(True)
		self.btn_uart_toggle.toggled.connect(self._on_toggle_uart)
		select_row.addWidget(self.btn_uart_toggle)
		# Move Reset View into the same row to keep a single compact header
		reset_button = QtWidgets.QPushButton("Reset View")
		reset_button.setMaximumHeight(28)
		reset_button.clicked.connect(self._on_reset_graph)
		select_row.addWidget(reset_button)
		select_row.setContentsMargins(0, 0, 0, 0)
		right.addLayout(select_row)

		# Stacked area: Graph view and Communication console
		self.main_stack = QtWidgets.QStackedWidget()
		# Graph page
		graph_page = QtWidgets.QWidget()
		graph_v = QtWidgets.QVBoxLayout(graph_page)
		graph_v.setContentsMargins(0, 0, 0, 0)
		self.plot_widget = pg.PlotWidget(axisItems={'bottom': TimeAxis(orientation='bottom')})
		self.plot_widget.setBackground("w")
		graph_v.addWidget(self.plot_widget, 1)
		self.main_stack.addWidget(graph_page)  # index 0
		# Communication console page (UART now; extensible for SSH/ADB)
		self.comm_console = CommConsole(self)
		self.main_stack.addWidget(self.comm_console)  # index 1
		self.main_stack.setCurrentIndex(0)
		right.addWidget(self.main_stack, 1)

	def _configure_plot(self) -> None:
		self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
		self.plot_widget.setLabel("left", "Performance", units="%")
		self.plot_widget.setLabel("bottom", "Time", units="s")
		self.plot_widget.setYRange(0, 100)
		
		# Label the custom time axis
		bottom_axis = self.plot_widget.getAxis('bottom')
		bottom_axis.setLabel(text="Time")
		
		# Enhanced scrolling and interaction
		self.plot_widget.setMouseEnabled(x=True, y=True)
		self.plot_widget.setLimits(xMin=0, yMin=0, yMax=100)
		
		# Better axis formatting
		self.plot_widget.getAxis('left').setTickSpacing(10, 5)
		
		# Improved scrolling behavior
		self.plot_widget.setAutoVisible(y=True)
		self.plot_widget.enableAutoRange(axis='y')
		
		# Set initial view range
		self.plot_widget.setXRange(0, 60)
		
		# Enable smooth scrolling and better performance
		self.plot_widget.setClipToView(True)
		self.plot_widget.setDownsampling(mode='peak')
		self.plot_widget.setDownsampling(auto=True)
		
		# Better performance for real-time updates
		self.plot_widget.setCacheMode(QtWidgets.QGraphicsView.CacheBackground)
		
		# Configure mouse interaction for better scrolling
		viewbox = self.plot_widget.getViewBox()
		viewbox.setMouseMode(pg.ViewBox.PanMode)
		viewbox.setAspectLocked(False)
		viewbox.setLimits(xMin=0, yMin=0, yMax=100)
		
		# Enable smooth mouse interaction
		viewbox.setMouseEnabled(x=True, y=True)
		
		# Connect to view range change for dynamic time scaling
		viewbox.sigRangeChanged.connect(self._on_view_range_changed)

	def _build_toolbar(self) -> None:
		"""Create a compact toolbar for primary actions."""
		toolbar = QtWidgets.QToolBar("Main")
		toolbar.setMovable(False)
		toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
		self.addToolBar(toolbar)
		# Actions
		a_start = QtGui.QAction("Execute Test", self)
		a_start.triggered.connect(self._on_start)
		a_stop = QtGui.QAction("Stop", self)
		a_stop.triggered.connect(self._on_stop)
		a_clear = QtGui.QAction("Clear Data", self)
		a_clear.triggered.connect(self._on_clear)
		a_csv = QtGui.QAction("Export CSV", self)
		a_csv.triggered.connect(self._on_export_csv)
		a_png = QtGui.QAction("Export PNG", self)
		a_png.triggered.connect(self._on_export_png)
		a_sched = QtGui.QAction("Schedule Load", self)
		a_sched.triggered.connect(self._on_schedule_load)
		# Collapse/expand handled by side handle; Reset View exists in plot header
		for act in [a_start, a_stop, a_clear, a_sched, a_csv, a_png]:
			toolbar.addAction(act)

		# Push the theme toggle to the extreme right
		spacer = QtWidgets.QWidget()
		spacer.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
		toolbar.addWidget(spacer)
		self.btn_theme = QtWidgets.QToolButton()
		self.btn_theme.setText("Light Mode")  # default we start in dark
		self.btn_theme.clicked.connect(self._toggle_theme)
		toolbar.addWidget(self.btn_theme)
		# Remove text action toggle; handled by side handle now
	def _apply_dark_theme(self) -> None:
		"""Apply a subtle dark theme and modern widget styling."""
		pal = self.palette()
		pal.setColor(QtGui.QPalette.Window, QtGui.QColor(15, 17, 20))
		pal.setColor(QtGui.QPalette.Base, QtGui.QColor(20, 23, 28))
		pal.setColor(QtGui.QPalette.AlternateBase, QtGui.QColor(23, 26, 31))
		pal.setColor(QtGui.QPalette.Text, QtGui.QColor(232, 236, 239))
		pal.setColor(QtGui.QPalette.WindowText, QtGui.QColor(237, 242, 247))
		pal.setColor(QtGui.QPalette.Button, QtGui.QColor(28, 32, 38))
		pal.setColor(QtGui.QPalette.ButtonText, QtGui.QColor(232, 236, 239))
		pal.setColor(QtGui.QPalette.Highlight, QtGui.QColor(59, 130, 246))
		pal.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor(255, 255, 255))
		self.setPalette(pal)
		self.setStyleSheet(
			"""
			QWidget { font-size: 12px; color: #E8ECEF; }
			QScrollArea { background: #0F1114; border: none; }
			#controlsContainer { background: #0F1114; }
			QCheckBox { spacing: 8px; }
			QCheckBox::indicator { width: 16px; height: 16px; border-radius: 4px; border: 1px solid #3A404A; background: #1C2127; }
			QCheckBox::indicator:hover { border-color: #3B82F6; }
			QCheckBox::indicator:checked { background: #3B82F6; border-color: #3B82F6; }
			QMenu, QAbstractItemView { background: #14171C; color: #E8ECEF; border: 1px solid #2A2F36; }
			QComboBox QAbstractItemView { background: #14171C; selection-background-color: #1E2530; selection-color: #E8ECEF; }
			QGraphicsView { background: #101114; }
			QGroupBox { border: 1px solid #2A2F36; border-radius: 8px; margin-top: 8px; }
			QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #A0AEC0; }
			QPushButton, QToolButton { background: #1D2228; border: 1px solid #2D333B; border-radius: 6px; padding: 6px 10px; }
			QPushButton:hover, QToolButton:hover { background: #242A32; }
			QPushButton:disabled { color: #7D8896; }
			QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
				background: #1E2329; border: 1px solid #323842; border-radius: 6px; padding: 6px 8px; color: #E8ECEF;
			}
			QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {
				border-color: #3B82F6;
			}
			#userGroup { border: 1px solid #2A2F36; }
			#commandPreview { background: #14171C; border-radius: 6px; }
			QSlider::groove:horizontal { height: 6px; background: #2A2F36; border-radius: 3px; }
			QSlider::handle:horizontal { width: 14px; background: #3B82F6; margin: -5px 0; border-radius: 7px; }
			QListWidget { background: #161A1F; border: 1px solid #2A2F36; border-radius: 6px; }
			QToolBar { background: #0F1114; border: 0; spacing: 8px; }
			#panelHandle { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1B2026, stop:1 #13171B); border: 1px solid #2D333B; border-radius: 18px; color: #EAF2FF; font-weight: 700; }
			#panelHandle:hover { border-color: #3B82F6; }
			#panelHandle:pressed { background: #1D2228; }
			#kpiButton { background: #14171C; border: 1px solid #2A2F36; border-radius: 12px; padding: 6px 12px; color: #A0AEC0; }
			#kpiButton:hover { border-color: #3B82F6; color: #E8F0FF; }
			"""
		)
		self._is_dark = True
		if hasattr(self, 'btn_theme') and self.btn_theme is not None:
			self.btn_theme.setText("Light Mode")
		self._apply_plot_theme(True)

	def _apply_light_theme(self) -> None:
		"""Apply a bright light theme alternative."""
		pal = self.palette()
		pal.setColor(QtGui.QPalette.Window, QtGui.QColor(248, 250, 255))
		pal.setColor(QtGui.QPalette.Base, QtGui.QColor(255, 255, 255))
		pal.setColor(QtGui.QPalette.AlternateBase, QtGui.QColor(248, 250, 252))
		pal.setColor(QtGui.QPalette.Text, QtGui.QColor(15, 23, 42))
		pal.setColor(QtGui.QPalette.WindowText, QtGui.QColor(15, 23, 42))
		pal.setColor(QtGui.QPalette.Button, QtGui.QColor(255, 255, 255))
		pal.setColor(QtGui.QPalette.ButtonText, QtGui.QColor(15, 23, 42))
		pal.setColor(QtGui.QPalette.Highlight, QtGui.QColor(14, 165, 233))
		pal.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor(255, 255, 255))
		self.setPalette(pal)
		self.setStyleSheet(
			"""
			QWidget { font-size: 11px; color: #0B1220; }
			QScrollArea { background: #F8FAFF; border: none; }
			#controlsContainer { background: #F8FAFF; }
			QCheckBox { spacing: 8px; }
			QCheckBox::indicator { width: 16px; height: 16px; border-radius: 4px; border: 1px solid #CBD5E1; background: #FFFFFF; }
			QCheckBox::indicator:hover { border-color: #0EA5E9; }
			QCheckBox::indicator:checked { background: #0EA5E9; border-color: #0EA5E9; }
			QMenu, QAbstractItemView { background: #FFFFFF; color: #0F172A; border: 1px solid #E2E8F0; }
			QComboBox QAbstractItemView { background: #FFFFFF; selection-background-color: #E2E8F0; selection-color: #0F172A; }
			QGraphicsView { background: #FFFFFF; }
			QGroupBox { border: 1px solid #E5E7EB; border-radius: 10px; margin-top: 6px; background: #FFFFFF; }
			QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 1px 8px; color: #374151; }
			QPushButton, QToolButton { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 8px; padding: 6px 10px; }
			QPushButton:hover, QToolButton:hover { background: #F3F4F6; border-color: #D1D5DB; }
			QPushButton:disabled { color: #94A3B8; }
			QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {
				background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 8px; padding: 5px 8px; color: #0F172A;
			}
			QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {
				border-color: #3B82F6;
			}
			#userGroup { border: 1px solid #E5E7EB; }
			#commandPreview { background: #FFFFFF; border-radius: 8px; }
			QSlider::groove:horizontal { height: 6px; background: #E5E7EB; border-radius: 3px; }
			QSlider::handle:horizontal { width: 14px; background: #3B82F6; margin: -5px 0; border-radius: 7px; }
			QListWidget { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 8px; }
			QToolBar { background: #FFFFFF; border: 0; spacing: 8px; border-bottom: 1px solid #E5E7EB; }
			#panelHandle { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #FFFFFF, stop:1 #F3F4F6); border: 1px solid #E5E7EB; border-radius: 18px; color: #0F172A; font-weight: 700; }
			#panelHandle:hover { border-color: #3B82F6; }
			#panelHandle:pressed { background: #FFFFFF; }
			#kpiButton { background: #F8FAFF; border: 1px solid #E5E7EB; border-radius: 12px; padding: 6px 12px; color: #6B7280; }
			#kpiButton:hover { border-color: #3B82F6; color: #0F172A; }
			/* Extra polish for Light Mode */
			QMainWindow, #rootCentral { background: #F8FAFF; }
			QScrollArea > QWidget > QWidget { background: #F8FAFF; }
			QAbstractItemView::item:selected { background: #DBEAFE; color: #0B1220; }
			QListWidget::item:selected { background: #DBEAFE; color: #0B1220; }
			QScrollBar:vertical, QScrollBar:horizontal { background: #F3F4F6; }
			"""
		)
		self._is_dark = False
		if hasattr(self, 'btn_theme') and self.btn_theme is not None:
			self.btn_theme.setText("Dark Mode")
		self._apply_plot_theme(False)

	def _on_toggle_uart(self, checked: bool) -> None:
		"""Switch between graph and UART views."""
		if hasattr(self, 'main_stack'):
			self.main_stack.setCurrentIndex(1 if checked else 0)
		if hasattr(self, 'btn_uart_toggle'):
			self.btn_uart_toggle.setText("Access Graph" if checked else "Access UART")
		# Refresh COM ports when entering console view
		if checked and hasattr(self, 'comm_console'):
			self.comm_console.refresh_ports()

	def _toggle_theme(self) -> None:
		if getattr(self, '_is_dark', True):
			self._apply_light_theme()
		else:
			self._apply_dark_theme()

	def _toggle_controls(self) -> None:
		"""Smoothly collapse/expand the left controls panel."""
		if not hasattr(self, 'controls_scroll'):
			return
		self.controls_collapsed = not getattr(self, 'controls_collapsed', False)
		start = self.controls_scroll.width()
		end = 0 if self.controls_collapsed else self.controls_initial_width
		anim = QtCore.QPropertyAnimation(self.controls_scroll, b"maximumWidth", self)
		anim.setDuration(220)
		anim.setStartValue(start)
		anim.setEndValue(end)
		anim.setEasingCurve(QtCore.QEasingCurve.InOutCubic)
		anim.start()
		self._controls_anim = anim
		# Update handle arrow
		if hasattr(self, 'panel_handle') and self.panel_handle:
			self.panel_handle.setArrowType(QtCore.Qt.RightArrow if self.controls_collapsed else QtCore.Qt.LeftArrow)

	def _apply_plot_theme(self, is_dark: bool) -> None:
		"""Adjust plot background and axis pens to match theme."""
		if not hasattr(self, 'plot_widget'):
			return
		if is_dark:
			self.plot_widget.setBackground(QtGui.QColor(16, 17, 20))
			axis_pen = pg.mkPen(color=(220, 224, 228))
		else:
			self.plot_widget.setBackground('w')
			axis_pen = pg.mkPen(color=(60, 60, 60))
		for axis in ['left', 'bottom']:
			ax = self.plot_widget.getAxis(axis)
			ax.setPen(axis_pen)
			ax.setTextPen(axis_pen)

	def _create_kpi_label(self, text: str) -> QtWidgets.QToolButton:
		btn = QtWidgets.QToolButton()
		btn.setObjectName("kpiButton")
		btn.setText(text + ": --%")
		btn.setAutoRaise(True)
		btn.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
		btn.clicked.connect(lambda _, name=text: self._select_graph(name))
		return btn

	# UART/console UI is provided by CommConsole

	# All UART logic moved into CommConsole

	def _select_graph(self, name: str) -> None:
		index = self.combo_active.findText(name)
		if index >= 0:
			self.combo_active.setCurrentIndex(index)
			self._on_active_changed(name)

	def _on_view_range_changed(self) -> None:
		"""Dynamically adjust time axis tick spacing based on zoom level."""
		viewbox = self.plot_widget.getViewBox()
		view_range = viewbox.viewRange()
		x_range = view_range[0]  # (x_min, x_max)
		time_span = x_range[1] - x_range[0]
		
		# Only apply custom spacing if we have a reasonable time span
		if time_span < 1:
			return  # Don't format if time span is too small
		
		# Determine tick spacing based on time span with nice rounding
		# Aim for ~6-8 major ticks across the current view
		ideal_major = max(1.0, time_span / 7.0)
		major_tick = _nice_tick_seconds(ideal_major)
		minor_tick = max(1.0, major_tick / 5.0)
		
		# Apply the new tick spacing
		self.plot_widget.getAxis('bottom').setTickSpacing(major_tick, minor_tick)

	def _setup_time_axis_formatting(self, time_span: float) -> None:
		"""Setup time axis formatting to show seconds and minutes format."""
		# For now, let PyQtGraph handle the default formatting
		# The custom tick spacing will provide the main benefit
		pass

	def _on_reset_graph(self) -> None:
		"""Reset graph zoom and pan to show full data range."""
		# Get all data points to determine the range
		all_x_values = []
		all_y_values = []
		
		# Collect data from all subsystems
		for state in self.states.values():
			if state.values:
				for ts, val in state.values:
					all_x_values.append(ts)
					all_y_values.append(val)
		
		# Collect data from all CPU cores
		for core_state in self.core_states.values():
			if core_state.values:
				for ts, val in core_state.values:
					all_x_values.append(ts)
					all_y_values.append(val)
		
		if not all_x_values:
			# No data yet, reset to default view
			self.plot_widget.setXRange(0, 60)
			self.plot_widget.setYRange(0, 100)
			return
		
		# Calculate data range
		min_x = min(all_x_values)
		max_x = max(all_x_values)
		min_y = min(all_y_values)
		max_y = max(all_y_values)
		
		# Convert to relative time (seconds from start)
		if min_x > 0:
			# Data exists, show from 0 to max relative time
			max_relative_time = max_x - min_x
			self.plot_widget.setXRange(0, max_relative_time + 10)  # Add 10 seconds padding
		else:
			# No data yet, show default range
			self.plot_widget.setXRange(0, 60)
		
		# Set Y range with some padding
		y_padding = (max_y - min_y) * 0.1 if max_y > min_y else 10
		self.plot_widget.setYRange(max(0, min_y - y_padding), min(100, max_y + y_padding))
		
		# Reset the view to auto-range for better display
		self.plot_widget.enableAutoRange(axis='xy')

	def _make_label(self, text: str, bold: bool = False) -> QtWidgets.QLabel:
		lbl = QtWidgets.QLabel(text)
		if bold:
			font = lbl.font()
			font.setBold(True)
			lbl.setFont(font)
		return lbl

	def _get_core_pen(self, core_id: int) -> pg.mkPen:
		# Use distinct color per core via color wheel
		color = pg.intColor(core_id, hues=len(self.core_states) or 8, maxValue=200)
		return pg.mkPen(color=color, width=2)

	def _on_subsystem_toggled(self) -> None:
		self.active_subsystems = [name for name, cb in self.checkbox_group.items() if cb.isChecked()]
		
		# Show/hide CPU cores section when CPU is selected
		cpu_selected = self.checkbox_group[Subsystem.CPU].isChecked()
		self.cpu_cores_group.setVisible(cpu_selected)
		
		# If CPU is deselected, clear active cores and hide sliders
		if not cpu_selected:
			for cb in self.core_checkboxes.values():
				cb.setChecked(False)
			self.active_cores.clear()
			for slider in self.core_sliders.values():
				slider.setVisible(False)
			for label in self.core_labels.values():
				label.setVisible(False)
		
		self._rebuild_sliders()
		self._rebuild_active_combo()
		self._refresh_numeric_list()
		self._refresh_plot_items()
		self._update_command_preview()

	def _on_cpu_target_toggled(self) -> None:
		"""Handle CPU Target checkbox toggle."""
		cpu_target_selected = self.cpu_target_checkbox.isChecked()
		self.cpu_target_slider.setVisible(cpu_target_selected)
		self.cpu_target_text.setVisible(cpu_target_selected)
		
		# Update active subsystems
		if cpu_target_selected:
			if Subsystem.CPU not in self.active_subsystems:
				self.active_subsystems.append(Subsystem.CPU)
			# Enable all CPU cores when CPU Target is selected
			self._setting_all_cores = True  # Flag to prevent core toggle from unchecking CPU Target
			for core_id, cb in self.core_checkboxes.items():
				cb.setChecked(True)
			self.active_cores = list(self.core_checkboxes.keys())
			# Show sliders for all cores
			for slider in self.core_sliders.values():
				slider.setVisible(True)
			delattr(self, '_setting_all_cores')  # Remove the flag
		else:
			if Subsystem.CPU in self.active_subsystems:
				self.active_subsystems.remove(Subsystem.CPU)
			# Don't automatically disable cores when CPU Target is deselected
			# Let the user manually manage individual cores
			# Just hide the sliders for cores that aren't individually selected
			for core_id, slider in self.core_sliders.items():
				slider.setVisible(core_id in self.active_cores)
		
		self._rebuild_active_combo()
		self._refresh_plot_items()
		self._update_command_preview()

	def _on_core_toggled(self) -> None:
		self.active_cores = [core_id for core_id, cb in self.core_checkboxes.items() if cb.isChecked()]
		
		# If CPU Target is checked and any core is unchecked, uncheck CPU Target
		# But only if we're not in the middle of setting all cores (which happens when CPU Target is toggled)
		if (hasattr(self, 'cpu_target_checkbox') and 
			self.cpu_target_checkbox.isChecked() and 
			len(self.active_cores) < len(self.core_checkboxes) and
			not hasattr(self, '_setting_all_cores')):
			self.cpu_target_checkbox.setChecked(False)
			# CPU Target unchecking will be handled by _on_cpu_target_toggled
		
		# Update slider visibility
		for core_id, slider in self.core_sliders.items():
			slider.setVisible(core_id in self.active_cores)
		for core_id, label in self.core_labels.items():
			label.setVisible(core_id in self.active_cores)
		self._rebuild_active_combo()
		self._refresh_numeric_list()
		self._refresh_plot_items()
		self._update_command_preview()

	def _rebuild_sliders(self) -> None:
		while self.slider_form.rowCount() > 0:
			self.slider_form.removeRow(0)
		
		# Add sliders for regular subsystems (excluding CPU)
		for name in self.active_subsystems:
			if name == Subsystem.CPU:
				continue  # Skip CPU, cores have their own sliders
			slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
			slider.setRange(0, 100)
			slider.setValue(self.states[name].target_percent)
			slider.valueChanged.connect(lambda val, n=name: self._on_target_changed(n, val))
			# Composite row widget with slider and editable percent to the right
			row_widget = QtWidgets.QWidget()
			row_layout = QtWidgets.QHBoxLayout(row_widget)
			row_layout.setContentsMargins(0, 0, 0, 0)
			row_layout.addWidget(slider, 1)
			txt = QtWidgets.QLineEdit(str(self.states[name].target_percent))
			txt.setValidator(QtGui.QIntValidator(0, 100, self))
			txt.setFixedWidth(40)
			slider.valueChanged.connect(lambda val, field=txt: field.setText(str(int(val))))
			def _apply_txt_sys(sys_name=name, field_ref=None):
				try:
					val_int = int((field_ref or txt).text() or 0)
					val_int = max(0, min(100, val_int))
					if slider.value() != val_int:
						slider.setValue(val_int)
				except Exception:
					pass
			txt.editingFinished.connect(lambda sys_name=name, field_ref=txt: _apply_txt_sys(sys_name, field_ref))
			row_layout.addWidget(txt)
			self.slider_form.addRow(QtWidgets.QLabel(f"{name} Target:"), row_widget)

	def _rebuild_active_combo(self) -> None:
		current = self.combo_active.currentText()
		self.combo_active.blockSignals(True)
		self.combo_active.clear()
		
		# Always show all subsystems regardless of checkbox selection
		for name in SUBSYSTEMS:
			self.combo_active.addItem(name)
		
		# Always show CPU cores option
		self.combo_active.addItem("CPU (cores)")
		
		# Always show individual CPU cores
		for core_id in range(7):  # Assuming 7 cores
			self.combo_active.addItem(f"Core {core_id}")
		
		self.combo_active.blockSignals(False)
		if current in [self.combo_active.itemText(i) for i in range(self.combo_active.count())]:
			self.combo_active.setCurrentText(current)
		elif self.combo_active.count() > 0:
			self.combo_active.setCurrentIndex(0)
		self._refresh_plot_items()
		self._update_command_preview()

	def _on_target_changed(self, name: str, value: int) -> None:
		self.states[name].target_percent = int(value)
		if self.combo_active.currentText() == name and self.states[name].target_line is not None:
			self.states[name].target_line.setValue(value)
		self._update_numeric_colors()
		self._update_command_preview()

	def _on_cpu_target_changed(self, value: int) -> None:
		"""Handle CPU target slider changes."""
		self.states[Subsystem.CPU].target_percent = int(value)
		
		# When CPU Target is selected, update all core targets to match
		if (hasattr(self, 'cpu_target_checkbox') and 
			self.cpu_target_checkbox.isChecked()):
			for core_id in self.core_states:
				self.core_states[core_id].target_percent = int(value)
				# Update core sliders if they exist
				if core_id in self.core_sliders:
					self.core_sliders[core_id].setValue(int(value))
				# Update core text fields if they exist
				if core_id in self.core_texts:
					self.core_texts[core_id].setText(str(int(value)))
		
		if self.combo_active.currentText() == Subsystem.CPU and self.states[Subsystem.CPU].target_line is not None:
			self.states[Subsystem.CPU].target_line.setValue(value)
		self._update_numeric_colors()
		self._update_command_preview()

	def _on_core_target_changed(self, core_id: int, value: int) -> None:
		self.core_states[core_id].target_percent = int(value)
		active = self.combo_active.currentText()
		if (active == "CPU (cores)" or active == f"Core {core_id}") and self.core_states[core_id].target_line is not None:
			self.core_states[core_id].target_line.setValue(value)
		self._update_numeric_colors()
		self._update_command_preview()

	def _refresh_plot_items(self) -> None:
		self.plot_widget.clear()
		active = self.combo_active.currentText()
		if not active:
			return
		
		if active == "CPU (cores)":
			# Plot all CPU cores with distinct colors and own target lines
			for core_id in range(7):  # Show all cores, not just active ones
				state = self.core_states[core_id]
				state.curve = self.plot_widget.plot([], [], pen=self._get_core_pen(core_id))
				# Only show target line if this core is active (has target set)
				if core_id in self.active_cores:
					line = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen(color=self._get_core_pen(core_id).color(), width=1, style=QtCore.Qt.DotLine))
					line.setValue(state.target_percent)
					self.plot_widget.addItem(line)
					state.target_line = line
			return
		
		# Single item view - show all subsystems but only targets for active ones
		if active.startswith("Core "):
			core_id = int(active.split()[1])
			state = self.core_states[core_id]
		else:
			state = self.states[active]
		
		curve = self.plot_widget.plot([], [], pen=pg.mkPen(color=(0, 122, 204), width=2))
		state.curve = curve
		
		# Only show target line if this subsystem is active (has target set)
		if (active in self.active_subsystems or 
			(active.startswith("Core ") and int(active.split()[1]) in self.active_cores)):
			line = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen(color=(200, 0, 0), width=2, style=QtCore.Qt.DotLine))
			line.setValue(state.target_percent)
			self.plot_widget.addItem(line)
			state.target_line = line

	def _on_active_changed(self, _: str) -> None:
		self._refresh_plot_items()
		self._redraw_curve()
		self._update_export_enabled()

	def _on_start(self) -> None:
		# Always allow starting; we'll read from the file regardless of selections
		# Clear all time series to start fresh
		for name in self.states:
			self.states[name].values.clear()
		for core_id in self.core_states:
			self.core_states[core_id].values.clear()
		self.is_running = True
		duration_s = int(self.duration_spin.value())
		self.end_time_epoch = get_timestamp() + duration_s
		# Start external command if provided
		cmd = self.command_preview.toPlainText().strip()
		if cmd:
			self._start_process(cmd)
		# For file-driven updates, disable internal sampler to avoid mixed data
		self._sample_timer.stop()
		# Begin tailing the stress output file (use user-specified path)
		tail_path = self.log_file_edit.text().strip()
		if not tail_path:
			QtWidgets.QMessageBox.warning(self, "No Log File", "Please specify the log file path.")
			return
		self._start_tail_file(tail_path)
		# Start schedule timer if there are scheduled changes
		self._start_schedule_timer()
		# Disable inputs while running
		self.btn_start.setEnabled(False)
		self.btn_stop.setEnabled(True)
		self.duration_spin.setEnabled(False)
		# Command input removed

	def _start_process(self, cmd: str) -> None:
		self._stop_process()
		self.process = QtCore.QProcess(self)
		self.process.setProcessChannelMode(QtCore.QProcess.MergedChannels)
		self.process.readyReadStandardOutput.connect(self._on_process_output)
		self.process.finished.connect(self._on_process_finished)
		# Use shell for Windows to interpret full command line
		self.process.start("powershell.exe", ["-NoProfile", "-Command", cmd])
		if not self.process.waitForStarted(3000):
			QtWidgets.QMessageBox.critical(self, "Error", "Failed to start command.")
			self._on_stop()

	def _stop_process(self) -> None:
		if self.process is not None:
			self.process.kill()
			self.process = None
		# Stop tailing file when stopping
		self._stop_tail_file()

	def _on_stop(self) -> None:
		self.is_running = False
		self._stop_process()
		self.end_time_epoch = None
		# Stop schedule timer
		self._stop_schedule_timer()
		# Re-enable inputs
		self.btn_start.setEnabled(True)
		self.btn_stop.setEnabled(False)
		self.duration_spin.setEnabled(True)
		# Stop internal sampler
		self._sample_timer.stop()
		# No test mode

	def _on_process_finished(self) -> None:
		self.is_running = False
		self._stop_process()
		self._sample_timer.stop()

	def _on_process_output(self) -> None:
		now = get_timestamp()
		if self.is_running and self.end_time_epoch is not None and now >= self.end_time_epoch:
			self._on_stop()
			return
		if self.process is not None:
			self.line_buffer += self.process.readAllStandardOutput().data()
			lines = self.line_buffer.split(b"\n")
			self.line_buffer = lines[-1]
			for raw in lines[:-1]:
				line = raw.decode(errors="ignore").strip()
				if not line:
					continue
				self._try_parse_and_store(line, now)
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()

	def _try_parse_and_store(self, line: str, ts: float) -> None:
		# Parse Linux stress tool output format
		# Examples: cpu0: 61.38619%, DRAM usage: 4.87443%, GPU usage: 0%
		
		# Parse CPU cores (cpu0: 61.38619%, cpu1: 80%, etc.)
		for core_id in self.active_cores:
			core_patterns = [
				rf"cpu{core_id}:\s*([0-9]+(?:\.[0-9]+)?)%",
				rf"Core\s+{core_id}:\s*([0-9]+(?:\.[0-9]+)?)%",
			]
			for pat in core_patterns:
				m = re.search(pat, line)
				if m:
					val = float(m.group(1))
					self.core_states[core_id].values.append((ts, val))
					break
		
		# Parse DRAM usage
		if Subsystem.DRAM in self.active_subsystems:
			dram_patterns = [
				r"DRAM usage:\s*([0-9]+(?:\.[0-9]+)?)%",
				r"DRAM\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%",
			]
			for pat in dram_patterns:
				m = re.search(pat, line)
				if m:
					val = float(m.group(1))
					self.states[Subsystem.DRAM].values.append((ts, val))
					break
		
		# Parse GPU usage
		if Subsystem.GPU in self.active_subsystems:
			gpu_patterns = [
				r"GPU usage:\s*([0-9]+(?:\.[0-9]+)?)%",
				r"GPU\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%",
			]
			for pat in gpu_patterns:
				m = re.search(pat, line)
				if m:
					val = float(m.group(1))
					self.states[Subsystem.GPU].values.append((ts, val))
					break
		
		# Fallback to old patterns for compatibility
		patterns = {
			Subsystem.CPU: [r"CPU\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"cpu\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%"],
			Subsystem.GPU: [r"GPU\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"gpu\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%"],
			Subsystem.DRAM: [r"DRAM\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"MEM(?:ORY)?\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%", r"mem\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)%"],
		}
		
		# Parse regular subsystems (excluding CPU)
		for name in self.active_subsystems:
			if name != Subsystem.CPU:  # Skip CPU, handle cores separately
				for pat in patterns.get(name, []):
					m = re.search(pat, line)
					if m:
						val = float(m.group(1))
						self.states[name].values.append((ts, val))
						break
		
		# If no specific core data found, try to get CPU core data from psutil
		if Subsystem.CPU in self.active_subsystems and self.active_cores:
			try:
				core_percentages = get_cpu_core_percent()
				for core_id in self.active_cores:
					if core_id < len(core_percentages):
						self.core_states[core_id].values.append((ts, core_percentages[core_id]))
			except Exception:
				pass

	def _sample_metrics(self) -> None:
		if not self.is_running:
			return
		ts = get_timestamp()
		
		# Always collect data for all CPU cores, regardless of selection
		try:
			core_percentages = get_cpu_core_percent()
			for core_id in range(7):  # Always collect for all 7 cores
				if core_id < len(core_percentages):
					core_value = max(0, min(100, core_percentages[core_id]))  # Clamp to 0-100%
					self.core_states[core_id].values.append((ts, core_value))
		except Exception:
			pass
		
		# Always calculate and store CPU aggregate
		try:
			vals = get_cpu_core_percent()
			avg = sum(vals) / max(1, len(vals))
			cpu_value = max(0, min(100, avg))  # Clamp to 0-100%
			self.states[Subsystem.CPU].values.append((ts, cpu_value))
		except Exception:
			pass
		
		# Always collect DRAM data
		try:
			import psutil
			mem = psutil.virtual_memory()
			dram_value = max(0, min(100, float(mem.percent)))  # Clamp to 0-100%
			self.states[Subsystem.DRAM].values.append((ts, dram_value))
		except Exception:
			pass
		
		# Always collect GPU data
		try:
			import pynvml
			pynvml.nvmlInit()
			h = pynvml.nvmlDeviceGetHandleByIndex(0)
			util = pynvml.nvmlDeviceGetUtilizationRates(h)
			gpu_value = max(0, min(100, float(util.gpu)))  # Clamp to 0-100%
			self.states[Subsystem.GPU].values.append((ts, gpu_value))
			pynvml.nvmlShutdown()
		except (ImportError, Exception):
			# If no NVIDIA GPU or drivers, set GPU to 0
			self.states[Subsystem.GPU].values.append((ts, 0.0))
		
		self._redraw_curve()
		self._refresh_numeric_list()

	def _redraw_curve(self) -> None:
		active = self.combo_active.currentText()
		if not active:
			return
		
		if active == "CPU (cores)":
			# For each core, draw its curve (show all cores, not just active ones)
			for core_id in range(7):  # Show all cores
				state = self.core_states[core_id]
				if state.curve is None or not state.values:
					if state.curve is not None and not state.values:
						state.curve.setData([], [])
					continue
				t0 = state.values[0][0]
				x = [ts - t0 for ts, _ in state.values]
				y = [max(0, min(100, v)) for _, v in state.values]  # Clamp values to 0-100%
				state.curve.setData(x, y)
			if any(self.core_states[c].values for c in range(7)):
				last_x = max((self.core_states[c].values[-1][0] - self.core_states[c].values[0][0]) for c in range(7) if self.core_states[c].values)
				if last_x > 60:
					# Smooth scrolling: show last 60 seconds
					self.plot_widget.setXRange(max(0, last_x - 60), last_x)
				else:
					# Show from 0 to at least 60 seconds
					self.plot_widget.setXRange(0, max(60, last_x + 10))
				# Trigger dynamic time scaling
				self._on_view_range_changed()
			return
		
		# Single item view
		if active.startswith("Core "):
			core_id = int(active.split()[1])
			state = self.core_states[core_id]
		else:
			state = self.states[active]
		
		if state.curve is None:
			return
		if not state.values:
			state.curve.setData([], [])
			return
		t0 = state.values[0][0]
		x = [ts - t0 for ts, _ in state.values]
		y = [max(0, min(100, v)) for _, v in state.values]  # Clamp values to 0-100%
		state.curve.setData(x, y)
		if x:
			span = x[-1]
			# Dynamic trailing window that grows with total span but caps for readability
			# 0-2min: show last 60s, 2-10min: last 3min, 10-60min: last 10min, >1h: last 20min
			if span > 3600:
				window = 1200  # 20 min
			elif span > 600:
				window = 600   # 10 min
			elif span > 120:
				window = 180   # 3 min
			else:
				window = 60
			left = max(0, span - window)
			self.plot_widget.setXRange(left, span)
		# Trigger dynamic time scaling
		self._on_view_range_changed()

	def _refresh_numeric_list(self) -> None:
		self.numeric_list.clear()
		
		# Add all subsystems (show all, not just active ones)
		for name in SUBSYSTEMS:
			state = self.states[name]
			val: Optional[float] = state.values[-1][1] if state.values else None
			# Show target only if this subsystem is active
			target_text = f" (target {state.target_percent}%)" if name in self.active_subsystems else " (no target)"
			text = f"{name}: {val:.1f}%{target_text}" if val is not None else f"{name}: --{target_text}"
			item = QtWidgets.QListWidgetItem(text)
			self.numeric_list.addItem(item)
		
		# Add all CPU cores (show all, not just active ones)
		for core_id in range(7):  # Show all cores
			state = self.core_states[core_id]
			val: Optional[float] = state.values[-1][1] if state.values else None
			# Show target only if this core is active
			target_text = f" (target {state.target_percent}%)" if core_id in self.active_cores else " (no target)"
			text = f"Core {core_id}: {val:.1f}%{target_text}" if val is not None else f"Core {core_id}: --{target_text}"
			item = QtWidgets.QListWidgetItem(text)
			self.numeric_list.addItem(item)
		
		self._update_numeric_colors()
		# Update KPI header labels with latest values
		cpu_val = self.states[Subsystem.CPU].values[-1][1] if self.states[Subsystem.CPU].values else None
		gpu_val = self.states[Subsystem.GPU].values[-1][1] if self.states[Subsystem.GPU].values else None
		dram_val = self.states[Subsystem.DRAM].values[-1][1] if self.states[Subsystem.DRAM].values else None
		if hasattr(self, 'kpi_cpu'):
			self.kpi_cpu.setText(f"CPU: {cpu_val:.1f}%" if cpu_val is not None else "CPU: --%")
		if hasattr(self, 'kpi_gpu'):
			self.kpi_gpu.setText(f"GPU: {gpu_val:.1f}%" if gpu_val is not None else "GPU: --%")
		if hasattr(self, 'kpi_dram'):
			self.kpi_dram.setText(f"DRAM: {dram_val:.1f}%" if dram_val is not None else "DRAM: --%")

	def _update_numeric_colors(self) -> None:
		item_idx = 0
		
		# Color all subsystems
		for name in SUBSYSTEMS:
			state = self.states[name]
			val: Optional[float] = state.values[-1][1] if state.values else None
			item = self.numeric_list.item(item_idx)
			if item is not None:
				if val is None:
					item.setForeground(QtGui.QBrush(QtGui.QColor(120, 120, 120)))
				elif name in self.active_subsystems and val >= state.target_percent:
					item.setForeground(QtGui.QBrush(QtGui.QColor(0, 130, 0)))
				elif name in self.active_subsystems and val < state.target_percent:
					item.setForeground(QtGui.QBrush(QtGui.QColor(180, 0, 0)))
				else:
					# No target set - neutral color
					item.setForeground(QtGui.QBrush(QtGui.QColor(100, 100, 100)))
			item_idx += 1

	def _open_log_dialog(self) -> None:
		# Create a modal dialog to display the live log content
		d = QtWidgets.QDialog(self)
		d.setWindowTitle("Live Log Viewer")
		d.resize(900, 600)
		v = QtWidgets.QVBoxLayout(d)
		# Toolbar row
		row = QtWidgets.QHBoxLayout()
		row.addWidget(self._make_label("File:"))
		path_lbl = QtWidgets.QLabel(self.log_file_edit.text() if hasattr(self, 'log_file_edit') else "")
		row.addWidget(path_lbl)
		row.addStretch(1)
		btn_close = QtWidgets.QPushButton("Close")
		btn_close.clicked.connect(d.accept)
		row.addWidget(btn_close)
		v.addLayout(row)
		# Text area
		text = QtWidgets.QPlainTextEdit()
		text.setReadOnly(True)
		text.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
		mono = QtGui.QFont("Consolas", 10)
		text.setFont(mono)
		v.addWidget(text, 1)
		# Load current file content
		try:
			p = self.log_file_edit.text() if hasattr(self, 'log_file_edit') else ""
			if p and os.path.exists(p):
				with open(p, 'r', encoding='utf-8', errors='ignore') as f:
					text.setPlainText(f.read())
		except Exception:
			pass
		# Wire live updates: reuse tail to append new lines while dialog open
		append_timer = QtCore.QTimer(d)
		append_timer.setInterval(500)
		def _append_new():
			try:
				p2 = self.log_file_edit.text() if hasattr(self, 'log_file_edit') else ""
				if not p2 or not os.path.exists(p2):
					return
				with open(p2, 'rb') as f:
					f.seek(text.document().characterCount())
					data = f.read()
					if data:
						try:
							new_txt = data.decode(errors='ignore')
						except Exception:
							new_txt = str(data)
						text.moveCursor(QtGui.QTextCursor.End)
						text.insertPlainText(new_txt)
						text.moveCursor(QtGui.QTextCursor.End)
			except Exception:
				pass
		append_timer.timeout.connect(_append_new)
		append_timer.start()
		d.exec()

	def _parse_stress_output(self, output: str) -> None:
		"""Parse Linux stress tool output and update graph data."""
		import re
		ts = get_timestamp()
		
		# Parse CPU overall usage (from "cpu: XX.XX%" line)
		cpu_match = re.search(r'cpu:\s+([\d.]+)%', output)
		if cpu_match and Subsystem.CPU in self.active_subsystems:
			cpu_value = float(cpu_match.group(1))
			self.states[Subsystem.CPU].values.append((ts, cpu_value))
		
		# Parse CPU core usage (from "cpu0: XX.XX%" lines)
		for core_id in range(7):
			core_match = re.search(rf'cpu{core_id}:\s+([\d.]+)%', output)
			if core_match and core_id in self.active_cores:
				core_value = float(core_match.group(1))
				self.core_states[core_id].values.append((ts, core_value))
		
		# Parse DRAM usage (from "DRAM usage: XX.XXXXX%" line)
		dram_match = re.search(r'DRAM usage:\s+([\d.]+)%', output)
		if dram_match and Subsystem.DRAM in self.active_subsystems:
			dram_value = float(dram_match.group(1))
			self.states[Subsystem.DRAM].values.append((ts, dram_value))
		
		# Parse GPU usage (from "GPU usage: X%" line)
		gpu_match = re.search(r'GPU usage:\s+([\d.]+)%', output)
		if gpu_match and Subsystem.GPU in self.active_subsystems:
			gpu_value = float(gpu_match.group(1))
			self.states[Subsystem.GPU].values.append((ts, gpu_value))
		
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()
	# ===== END TEST MODE FUNCTIONS =====

	def _on_export_csv(self) -> None:
		has_data = any(self.states[name].values for name in self.active_subsystems) or any(self.core_states[core_id].values for core_id in self.active_cores)
		if not has_data:
			QtWidgets.QMessageBox.information(self, "Info", "No data to export.")
			return
		path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save CSV", os.path.join(os.getcwd(), "results.csv"), "CSV Files (*.csv)")
		if not path:
			return
		with open(path, "w", newline="", encoding="utf-8") as f:
			writer = csv.writer(f)
			writer.writerow(["timestamp", "subsystem", "value_percent", "target_percent"])
			for name in self.active_subsystems:
				state = self.states[name]
				for ts, val in state.values:
					writer.writerow([int(ts), name, f"{val:.3f}", state.target_percent])
			for core_id in self.active_cores:
				state = self.core_states[core_id]
				for ts, val in state.values:
					writer.writerow([int(ts), f"Core {core_id}", f"{val:.3f}", state.target_percent])

	def _on_export_png(self) -> None:
		if self.combo_active.currentText() == "":
			QtWidgets.QMessageBox.information(self, "Info", "No active graph to export.")
			return
		path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save PNG", os.path.join(os.getcwd(), "graph.png"), "PNG Files (*.png)")
		if not path:
			return
		try:
			from pyqtgraph.exporters import ImageExporter
			exporter = ImageExporter(self.plot_widget.plotItem)
			exporter.parameters()["width"] = 1200
			exporter.export(path)
		except Exception:
			pixmap = self.plot_widget.grab()
			pixmap.save(path, "PNG")

	def _on_clear(self) -> None:
		for name in self.states:
			self.states[name].values.clear()
		for core_id in self.core_states:
			self.core_states[core_id].values.clear()
		self._file_tail_pos = 0
		self._file_tail_rem = b""
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()

	def _update_export_enabled(self) -> None:
		has_data = any(self.states[name].values for name in self.active_subsystems) or any(self.core_states[core_id].values for core_id in self.active_cores)
		self.btn_export_csv.setEnabled(has_data)
		self.btn_export_png.setEnabled(self.combo_active.currentText() != "")

	def _update_command_preview(self) -> None:
		# Build Linux stress command from current selections
		parts: List[str] = ["stress"]
		
		# CPU load (overall CPU target) - only if CPU Target is checked
		if (Subsystem.CPU in self.active_subsystems and 
			hasattr(self, 'cpu_target_checkbox') and 
			self.cpu_target_checkbox.isChecked()):
			target = self.states[Subsystem.CPU].target_percent
			parts.extend(["--cpu-core", "all", "--cpu-load", str(target)])
		else:
			# CPU cores - only if individual cores are checked (and CPU Target is not checked)
			for core_id in self.active_cores:
				if (hasattr(self, 'core_checkboxes') and 
					core_id in self.core_checkboxes and 
					self.core_checkboxes[core_id].isChecked()):
					target = self.core_states[core_id].target_percent
					parts.extend(["--cpu-core-load", f"{core_id}:{target}"])
		
		# GPU - only if GPU is checked
		if Subsystem.GPU in self.active_subsystems:
			target = self.states[Subsystem.GPU].target_percent
			parts.extend(["--gpu-load", str(target)])
		
		# DRAM - only if DRAM is checked
		if Subsystem.DRAM in self.active_subsystems:
			target = self.states[Subsystem.DRAM].target_percent
			parts.extend(["--dram-load", str(target)])
		
		# Duration
		dur = int(self.duration_spin.value())
		parts.extend(["--duration", str(dur)])
		self.command_preview.setPlainText(" ".join(parts))

	def _start_tail_file(self, path: str) -> None:
		"""Start tailing the stress output file located at path."""
		try:
			self._file_tail_path = path
			# Start from the beginning so we read existing blocks first
			self._file_tail_pos = 0
			self._file_tail_rem = b""
			self._file_block_idx = -1
			self._file_start_epoch = get_timestamp()
			# Reset persistent block state
			self._blk_active = False
			self._blk_cpu_overall = None
			self._blk_core_vals = {}
			self._blk_dram_val = None
			self._blk_gpu_val = None
			# Immediately process current contents so first block shows at t=0
			self._read_stress_file_tail()
			# Continue listening for new blocks until completion line is seen
			self._file_tail_timer.start()
			# Add file watcher for immediate reaction on append/truncate
			try:
				self._file_watcher.removePaths(self._file_watcher.files())
			except Exception:
				pass
			if os.path.exists(path):
				self._file_watcher.addPath(path)
		except Exception:
			pass

	def _stop_tail_file(self) -> None:
		self._file_tail_timer.stop()
		self._file_tail_path = None
		self._file_tail_rem = b""
		self._file_block_idx = -1

	def _read_stress_file_tail(self) -> None:
		"""Read newly appended lines from the stress output file and parse blocks.

		We look for blocks beginning with '[Monitor] CPU Usage (per core):' and ending
		when we have seen DRAM and GPU lines that follow. Each block is timestamped
		by the time we process it so graphs advance with arrivals.
		"""
		if not self._file_tail_path:
			return
		try:
			# Handle truncation/rotation: if file shrank, restart at 0
			try:
				cur_size = os.path.getsize(self._file_tail_path)
				if cur_size < self._file_tail_pos:
					self._file_tail_pos = 0
			except Exception:
				pass
			with open(self._file_tail_path, 'rb') as f:
				f.seek(self._file_tail_pos)
				data = f.read()
				if not data:
					return
				self._file_tail_pos += len(data)
				buf = self._file_tail_rem + data
		except Exception:
			return
		# Split into lines keeping remainder
		lines = buf.split(b"\n")
		self._file_tail_rem = lines[-1]
		new_lines = [ln.decode(errors='ignore').rstrip('\r') for ln in lines[:-1] if ln]
		self._parse_stress_lines(new_lines)
		# Append raw lines to live log view if visible
		if hasattr(self, 'log_text_view') and self.view_data_stack.currentIndex() == 1 and new_lines:
			try:
				self.log_text_view.moveCursor(QtGui.QTextCursor.End)
				self.log_text_view.insertPlainText("\n".join(new_lines) + "\n")
				self.log_text_view.moveCursor(QtGui.QTextCursor.End)
			except Exception:
				pass
		# Stop tailing if completion marker is seen
		for s in new_lines:
			if "Stress test completed" in s:
				self._stop_tail_file()
				break
		# Update debug tail status
		if hasattr(self, 'tail_status'):
			try:
				file_size = os.path.getsize(self._file_tail_path) if self._file_tail_path and os.path.exists(self._file_tail_path) else 0
				self.tail_status.setText(f"size={file_size} pos={self._file_tail_pos} lines={len(new_lines)} q={len(self._block_queue)} idx={self._file_block_idx}")
			except Exception:
				pass

	def _parse_stress_lines(self, lines: List[str]) -> None:
		# Continue filling the current block across timer ticks
		for line in lines:
			if line.startswith('[Monitor] CPU Usage (per core):'):
				# If we were in a block, commit what we have before starting a new one
				if self._blk_active and any([self._blk_cpu_overall is not None, self._blk_core_vals, self._blk_dram_val is not None, self._blk_gpu_val is not None]):
					self._enqueue_block(self._blk_cpu_overall, self._blk_core_vals, self._blk_dram_val, self._blk_gpu_val)
				# Start a new block
				self._blk_active = True
				self._blk_cpu_overall = None
				self._blk_core_vals = {}
				self._blk_dram_val = None
				self._blk_gpu_val = None
				continue
			if not self._blk_active:
				continue
			# Parse CPU overall and per-core lines
			m = re.search(r"^\s*cpu:\s*([0-9]+(?:\.[0-9]+)?)%", line)
			if m:
				try:
					self._blk_cpu_overall = float(m.group(1))
				except Exception:
					pass
				continue
			m2 = re.search(r"^\s*cpu(\d+):\s*([0-9]+(?:\.[0-9]+)?)%", line)
			if m2:
				try:
					cid = int(m2.group(1))
					self._blk_core_vals[cid] = float(m2.group(2))
				except Exception:
					pass
				continue
			# DRAM and GPU (exact match to sample)
			m3 = re.search(r"^\[Monitor\]\s*DRAM\s*usage:\s*([0-9]+(?:\.[0-9]+)?)%", line)
			if m3:
				try:
					self._blk_dram_val = float(m3.group(1))
				except Exception:
					pass
				continue
			m4 = re.search(r"^\[Monitor\]\s*GPU\s*usage:\s*([0-9]+(?:\.[0-9]+)?)%", line)
			if m4:
				try:
					self._blk_gpu_val = float(m4.group(1))
				except Exception:
					pass
				# Commit a completed block when GPU arrives
				self._enqueue_block(self._blk_cpu_overall, self._blk_core_vals, self._blk_dram_val, self._blk_gpu_val)
				self._blk_active = False
				self._blk_cpu_overall = None
				self._blk_core_vals = {}
				self._blk_dram_val = None
				self._blk_gpu_val = None
				continue
			# If we see a new block start while active, flush the previous
			if self._blk_active and line.startswith('[Monitor] CPU Usage (per core):'):
				if any([self._blk_cpu_overall is not None, self._blk_core_vals, self._blk_dram_val is not None, self._blk_gpu_val is not None]):
					self._enqueue_block(self._blk_cpu_overall, self._blk_core_vals, self._blk_dram_val, self._blk_gpu_val)
				self._blk_active = True
				self._blk_cpu_overall = None
				self._blk_core_vals = {}
				self._blk_dram_val = None
				self._blk_gpu_val = None
			# Commit on blank separator if we have at least DRAM (and possibly GPU)
			if not line.strip() and self._blk_active and (self._blk_dram_val is not None or self._blk_gpu_val is not None):
				self._enqueue_block(self._blk_cpu_overall, self._blk_core_vals, self._blk_dram_val, self._blk_gpu_val)
				self._blk_active = False
				self._blk_cpu_overall = None
				self._blk_core_vals = {}
				self._blk_dram_val = None
				self._blk_gpu_val = None

	def _enqueue_block(self, cpu_overall: Optional[float], core_vals: Dict[int, float], dram_val: Optional[float], gpu_val: Optional[float]) -> None:
		"""Commit a parsed block to time series using current timestamp.

		Blocks are played back at 5s intervals via a queue, so even if the
		file already contains many blocks, the graph advances one step at a
		time instead of jumping all at once.
		"""
		self._block_queue.append((cpu_overall, dict(core_vals), dram_val, gpu_val))
		# If this is the first block queued, schedule immediate emit and 5s cadence
		if not self._block_timer.isActive():
			self._file_block_idx = -1
			self._next_block_due_epoch = get_timestamp()
			self._block_timer.start()

	def _maybe_emit_block(self) -> None:
		if not self._block_queue or self._next_block_due_epoch is None:
			return
		if get_timestamp() < self._next_block_due_epoch:
			return
		cpu_overall, core_vals, dram_val, gpu_val = self._block_queue.pop(0)
		self._file_block_idx += 1
		start_epoch = getattr(self, '_file_start_epoch', get_timestamp())
		block_ts = start_epoch + 5.0 * max(0, self._file_block_idx)
		if cpu_overall is not None:
			self.states[Subsystem.CPU].values.append((block_ts, max(0, min(100, cpu_overall))))
		for cid, v in core_vals.items():
			if cid in self.core_states:
				self.core_states[cid].values.append((block_ts, max(0, min(100, v))))
		if dram_val is not None:
			self.states[Subsystem.DRAM].values.append((block_ts, max(0, min(100, dram_val))))
		if gpu_val is not None:
			self.states[Subsystem.GPU].values.append((block_ts, max(0, min(100, gpu_val))))
		# Update UI
		self._redraw_curve()
		self._refresh_numeric_list()
		self._update_export_enabled()
		# Schedule next block 5s later (if any)
		self._next_block_due_epoch = get_timestamp() + 5.0
		if not self._block_queue:
			# Keep timer running to catch future blocks; do not stop
			pass

	# Command browse removed with command feature

	def _on_schedule_load(self) -> None:
		"""Open the schedule load dialog."""
		dialog = ScheduleLoadDialog(self, self.scheduled_changes)
		if dialog.exec() == QtWidgets.QDialog.Accepted:
			self.scheduled_changes = dialog.get_scheduled_changes()
			self._update_schedule_display()

	def _update_schedule_display(self) -> None:
		"""Update the schedule load button text to show number of scheduled changes."""
		if self.scheduled_changes:
			self.btn_schedule_load.setText(f"Schedule Load ({len(self.scheduled_changes)} scheduled)")
		else:
			self.btn_schedule_load.setText("Schedule Load")

	def _start_schedule_timer(self) -> None:
		"""Start the timer for checking scheduled changes."""
		if not self.scheduled_changes:
			return
		
		self.test_start_time = get_timestamp()
		self.schedule_timer = QtCore.QTimer(self)
		self.schedule_timer.setInterval(1000)  # Check every second
		self.schedule_timer.timeout.connect(self._check_scheduled_changes)
		self.schedule_timer.start()

	def _stop_schedule_timer(self) -> None:
		"""Stop the schedule timer."""
		if self.schedule_timer:
			self.schedule_timer.stop()
			self.schedule_timer = None
		self.test_start_time = None

	def _check_scheduled_changes(self) -> None:
		"""Check if any scheduled changes need to be applied."""
		if not self.is_running or not self.test_start_time:
			return
		
		elapsed_time = get_timestamp() - self.test_start_time

		# Handle harmonic ramps in progress
		if self.active_harmonics:
			to_delete = []
			for subsystem, (start_s, end_s, start_v, end_v) in self.active_harmonics.items():
				if elapsed_time >= end_s:
					self._apply_scheduled_change(subsystem, end_v)
					to_delete.append(subsystem)
				elif elapsed_time >= start_s:
					# Interpolate linearly between start and end
					span = max(1e-6, end_s - start_s)
					alpha = (elapsed_time - start_s) / span
					cur_val = int(round(start_v + (end_v - start_v) * alpha))
					self._apply_scheduled_change(subsystem, cur_val)
			for k in to_delete:
				self.active_harmonics.pop(k, None)

		# Find changes that should be applied or initialized now
		remaining_changes: List[Tuple[float, str, int, str]] = []
		RAMP_SECS = 120.0  # 2 minutes ramp window
		for time_offset, subsystem, target_value, mode in self.scheduled_changes:
			if mode.lower() == "harmonic":
				start_s = max(0.0, time_offset - RAMP_SECS)
				if elapsed_time >= time_offset:
					# Ensure final value is applied
					self._apply_scheduled_change(subsystem, target_value)
					continue
				elif elapsed_time >= start_s:
					# Initialize harmonic if not present
					if subsystem not in self.active_harmonics:
						# Determine current target as start value
						start_v = self._get_current_target_for(subsystem)
						self.active_harmonics[subsystem] = (start_s, time_offset, start_v, target_value)
					# Keep in list until completed
					remaining_changes.append((time_offset, subsystem, target_value, mode))
				else:
					# Already ramping; keep until end
					remaining_changes.append((time_offset, subsystem, target_value, mode))
			else:
				# sudden
				if elapsed_time >= time_offset:
					self._apply_scheduled_change(subsystem, target_value)
					continue
				else:
					remaining_changes.append((time_offset, subsystem, target_value, mode))

		self.scheduled_changes = remaining_changes
		self._update_schedule_display()

	def _get_current_target_for(self, subsystem: str) -> int:
		"""Return the current target value for a subsystem or core."""
		if subsystem == "CPU":
			return int(self.states[Subsystem.CPU].target_percent)
		elif subsystem.startswith("Core "):
			try:
				cid = int(subsystem.split()[1])
				return int(self.core_states.get(cid, CoreState(cid)).target_percent)
			except Exception:
				return 50
		elif subsystem in self.states:
			return int(self.states[subsystem].target_percent)
		return 50

	def _apply_scheduled_change(self, subsystem: str, target_value: int) -> None:
		"""Apply a scheduled change to a subsystem."""
		if subsystem == "CPU" and hasattr(self, 'cpu_target_checkbox'):
			# Apply to CPU Target
			self.states[Subsystem.CPU].target_percent = target_value
			self.cpu_target_slider.setValue(target_value)
			self.cpu_target_text.setText(str(target_value))
			# Update all core targets if CPU Target is checked
			if self.cpu_target_checkbox.isChecked():
				for core_id in self.core_states:
					self.core_states[core_id].target_percent = target_value
					if core_id in self.core_sliders:
						self.core_sliders[core_id].setValue(target_value)
					if core_id in self.core_texts:
						self.core_texts[core_id].setText(str(target_value))
		elif subsystem.startswith("Core ") and hasattr(self, 'core_states'):
			# Apply to individual CPU core
			try:
				core_id = int(subsystem.split()[1])
				if core_id in self.core_states:
					self.core_states[core_id].target_percent = target_value
					# Update core slider and text if they exist
					if core_id in self.core_sliders:
						self.core_sliders[core_id].setValue(target_value)
					if core_id in self.core_texts:
						self.core_texts[core_id].setText(str(target_value))
			except (ValueError, IndexError):
				pass
		elif subsystem in self.states:
			# Apply to regular subsystem
			self.states[subsystem].target_percent = target_value
			# Update slider if it exists
			for i in range(self.slider_form.rowCount()):
				label = self.slider_form.itemAt(i, QtWidgets.QFormLayout.LabelRole).widget()
				if label and label.text().startswith(f"{subsystem} Target:"):
					row_widget = self.slider_form.itemAt(i, QtWidgets.QFormLayout.FieldRole).widget()
					if row_widget:
						slider = row_widget.findChild(QtWidgets.QSlider)
						if slider:
							slider.setValue(target_value)
						text_field = row_widget.findChild(QtWidgets.QLineEdit)
						if text_field:
							text_field.setText(str(target_value))
					break
		
		self._update_command_preview()
		self._update_numeric_colors()


class InputValidationDelegate(QtWidgets.QStyledItemDelegate):
	"""Custom delegate for input validation in the schedule table."""
	
	def createEditor(self, parent, option, index):
		"""Create appropriate editor based on column."""
		if index.column() == 0:  # Time column
			editor = QtWidgets.QLineEdit(parent)
			editor.setValidator(QtGui.QDoubleValidator(0.0, 9999.9, 1, parent))
			editor.setPlaceholderText("e.g., 5.0 (5th minute)")
			# Select all text when editor is created
			editor.selectAll()
			return editor
		elif index.column() == 2:  # Target percentage column
			editor = QtWidgets.QLineEdit(parent)
			editor.setValidator(QtGui.QIntValidator(0, 100, parent))
			editor.setPlaceholderText("0-100")
			# Select all text when editor is created
			editor.selectAll()
			return editor
		else:
			return super().createEditor(parent, option, index)
	
	def setEditorData(self, editor, index):
		"""Set the data in the editor."""
		if index.column() in [0, 2]:  # Time or Target columns
			editor.setText(index.data(QtCore.Qt.DisplayRole) or "")
			# Select all text for easy replacement
			editor.selectAll()
		else:
			super().setEditorData(editor, index)
	
	def setModelData(self, editor, model, index):
		"""Set the data in the model."""
		if index.column() in [0, 2]:  # Time or Target columns
			text = editor.text().strip()
			if text:
				model.setData(index, text, QtCore.Qt.EditRole)
		else:
			super().setModelData(editor, model, index)


class ScheduleLoadDialog(QtWidgets.QDialog):
	"""Dialog for scheduling load changes during the test."""
	
	def __init__(self, parent, scheduled_changes: List[Tuple[float, str, int, str]]):
		super().__init__(parent)
		self.scheduled_changes = scheduled_changes.copy()
		self.setWindowTitle("Schedule Load Changes")
		self.setModal(True)
		self.resize(900, 480)
		
		self._build_ui()
		self._populate_table()

	def _build_ui(self) -> None:
		layout = QtWidgets.QVBoxLayout(self)
		
		# Instructions
		instructions = QtWidgets.QLabel(
			"Schedule load changes during the test. Time is the exact minute when the change should occur.\n"
			"Example: Enter '5' to set target at the 5th minute (300 seconds) of the test.\n"
			"Available subsystems: CPU, GPU, DRAM, and individual CPU cores (Core 0, Core 1, etc.)"
		)
		instructions.setWordWrap(True)
		layout.addWidget(instructions)
		
		# Table for scheduled changes
		self.table = QtWidgets.QTableWidget()
		# Columns: Time, CPU, Core0..Core6, GPU, DRAM, Graph Type
		self.core_count = 7
		self.col_time = 0
		self.col_cpu = 1
		self.col_core0 = 2
		self.col_gpu = self.col_core0 + self.core_count
		self.col_dram = self.col_gpu + 1
		self.col_type = self.col_dram + 1
		self.total_cols = self.col_type + 1
		self.table.setColumnCount(self.total_cols)
		headers = ["Time (min)", "CPU"] + [f"Core {i}" for i in range(self.core_count)] + ["GPU", "DRAM", "Graph Type"]
		self.table.setHorizontalHeaderLabels(headers)
		
		# Set column widths
		self.table.setColumnWidth(self.col_time, 100)
		for c in range(1, self.col_type):
			self.table.setColumnWidth(c, 80)
		self.table.setColumnWidth(self.col_type, 120)
		
		# Enable sorting
		self.table.setSortingEnabled(True)
		
		# Set up input validation
		self.table.setItemDelegate(InputValidationDelegate(self.table))
		
		layout.addWidget(self.table)
		
		# Buttons for adding/removing changes
		button_layout = QtWidgets.QHBoxLayout()
		
		self.btn_add = QtWidgets.QPushButton("Add Change")
		self.btn_add.clicked.connect(self._add_change)
		button_layout.addWidget(self.btn_add)
		
		self.btn_remove = QtWidgets.QPushButton("Remove Selected")
		self.btn_remove.clicked.connect(self._remove_change)
		button_layout.addWidget(self.btn_remove)
		
		button_layout.addStretch()
		layout.addLayout(button_layout)
		
		# Dialog buttons
		dialog_buttons = QtWidgets.QDialogButtonBox(
			QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
		)
		dialog_buttons.accepted.connect(self.accept)
		dialog_buttons.rejected.connect(self.reject)
		layout.addWidget(dialog_buttons)

	def _populate_table(self) -> None:
		"""Populate the table with existing scheduled changes."""
		# Group existing flat list into rows by (time, mode)
		# Build mapping so we can prefill cells
		rows: Dict[Tuple[float, str], Dict[str, int]] = {}
		for time_offset, subsystem, target_value, mode in self.scheduled_changes:
			key = (time_offset, mode)
			rows.setdefault(key, {})[subsystem] = target_value
		self.table.setRowCount(len(rows) if rows else 1)
		if not rows:
			self._init_row_widgets(0)
			return
		for row_index, ((time_offset, mode), subs_map) in enumerate(rows.items()):
			self._init_row_widgets(row_index)
			self.table.item(row_index, self.col_time).setText(f"{time_offset / 60:.1f}")
			# Fill CPU/cores/GPU/DRAM
			if "CPU" in subs_map:
				self.table.item(row_index, self.col_cpu).setText(str(subs_map["CPU"]))
			for i in range(self.core_count):
				val = subs_map.get(f"Core {i}")
				if val is not None:
					self.table.item(row_index, self.col_core0 + i).setText(str(val))
			if Subsystem.GPU in subs_map:
				self.table.item(row_index, self.col_gpu).setText(str(subs_map[Subsystem.GPU]))
			if Subsystem.DRAM in subs_map:
				self.table.item(row_index, self.col_dram).setText(str(subs_map[Subsystem.DRAM]))
			# Type
			combo: QtWidgets.QComboBox = self.table.cellWidget(row_index, self.col_type)
			idx = combo.findText(self._normalize_mode(mode), QtCore.Qt.MatchFixedString)
			if idx >= 0:
				combo.setCurrentIndex(idx)

	def _init_row_widgets(self, row: int) -> None:
		"""Create default widgets and validators for a new row."""
		if row >= self.table.rowCount():
			self.table.insertRow(row)
		time_item = QtWidgets.QTableWidgetItem("")
		self.table.setItem(row, self.col_time, time_item)
		# percentage cells
		for col in range(self.col_cpu, self.col_type):
			item = QtWidgets.QTableWidgetItem("")
			self.table.setItem(row, col, item)
		# type combo
		combo = QtWidgets.QComboBox()
		combo.addItems(["Sudden", "Harmonic"])
		self.table.setCellWidget(row, self.col_type, combo)

	def _normalize_mode(self, mode: str) -> str:
		return "Harmonic" if str(mode).lower().startswith("harm") else "Sudden"

	def _add_change(self) -> None:
		"""Add a new scheduled change."""
		row = self.table.rowCount()
		self.table.insertRow(row)
		self._init_row_widgets(row)

	def _remove_change(self) -> None:
		"""Remove the selected scheduled change."""
		current_row = self.table.currentRow()
		if current_row >= 0:
			self.table.removeRow(current_row)

	def get_scheduled_changes(self) -> List[Tuple[float, str, int, str]]:
		"""Get the scheduled changes from the table.
		Returns a flat list of (time_seconds, subsystem, target_value, mode)."""
		changes: List[Tuple[float, str, int, str]] = []
		for row in range(self.table.rowCount()):
			time_item = self.table.item(row, self.col_time)
			if not time_item:
				continue
			time_text = (time_item.text() or "").strip()
			if not time_text:
				continue
			try:
				time_minutes = float(time_text)
				when_s = time_minutes * 60.0
			except ValueError:
				continue
			mode_combo: QtWidgets.QComboBox = self.table.cellWidget(row, self.col_type)
			mode = (mode_combo.currentText() if mode_combo else "Sudden")
			mode_norm = "harmonic" if mode.lower().startswith("harm") else "sudden"
			# CPU
			cpu_txt = (self.table.item(row, self.col_cpu).text() if self.table.item(row, self.col_cpu) else "").strip()
			if cpu_txt:
				try:
					changes.append((when_s, "CPU", int(cpu_txt), mode_norm))
				except ValueError:
					pass
			# Cores
			for i in range(self.core_count):
				cell = self.table.item(row, self.col_core0 + i)
				val_txt = (cell.text() if cell else "").strip()
				if val_txt:
					try:
						changes.append((when_s, f"Core {i}", int(val_txt), mode_norm))
					except ValueError:
						pass
			# GPU / DRAM
			gpu_txt = (self.table.item(row, self.col_gpu).text() if self.table.item(row, self.col_gpu) else "").strip()
			if gpu_txt:
				try:
					changes.append((when_s, Subsystem.GPU, int(gpu_txt), mode_norm))
				except ValueError:
					pass
			dram_txt = (self.table.item(row, self.col_dram).text() if self.table.item(row, self.col_dram) else "").strip()
			if dram_txt:
				try:
					changes.append((when_s, Subsystem.DRAM, int(dram_txt), mode_norm))
				except ValueError:
					pass
		# Sort by time
		changes.sort(key=lambda x: x[0])
		return changes


def main() -> None:
	app = QtWidgets.QApplication(sys.argv)
	pg.setConfigOptions(antialias=True)
	w = PerformanceApp()
	w.show()
	sys.exit(app.exec())


if __name__ == "__main__":
	main()
