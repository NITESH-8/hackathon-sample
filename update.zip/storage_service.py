from typing import Dict, List, Any, Optional
import uuid
from datetime import datetime, timezone
import os
import hashlib
import re
from .database import DatabaseManager
from .log_processor import LogProcessor
from .embedding_service import EmbeddingService
from .similarity_service import SimilarityService

class StorageService:
    def __init__(self):
        self.db = DatabaseManager()
        self.log_processor = LogProcessor()
        self.embedding_service = EmbeddingService()
        self.similarity_service = SimilarityService()
    
    def _generate_meaningful_log_id(self, raw_file_path: str) -> str:
        """
        Generate a meaningful log ID in format: {filename}_{YYYYMMDD}_{HHMMSS}_{6char_hash}
        """
        try:
            # Extract filename without extension
            filename = os.path.splitext(os.path.basename(raw_file_path))[0]
            
            # Clean filename (remove special characters, keep only alphanumeric and dots)
            clean_filename = ''.join(c for c in filename if c.isalnum() or c in '.-_')
            
            # Smart truncation: if filename is too long, try to keep the meaningful part
            if len(clean_filename) > 25:
                # If it looks like a UUID prefix, try to extract a meaningful name
                if '_' in clean_filename:
                    # Split by underscore and try to find a meaningful part
                    parts = clean_filename.split('_')
                    meaningful_parts = [part for part in parts if not (len(part) > 8 and part.count('-') >= 4)]
                    if meaningful_parts:
                        clean_filename = '_'.join(meaningful_parts)[:25]
                    else:
                        clean_filename = clean_filename[:25]
                else:
                    clean_filename = clean_filename[:25]
            
            # Get current timestamp
            now = datetime.now()
            date_str = now.strftime("%Y%m%d")
            time_str = now.strftime("%H%M%S")
            
            # Generate a short hash for uniqueness
            hash_input = f"{raw_file_path}{now.isoformat()}"
            short_hash = hashlib.md5(hash_input.encode()).hexdigest()[:6]
            
            # Combine all parts
            log_id = f"{clean_filename}_{date_str}_{time_str}_{short_hash}"
            
            return log_id
        except Exception as e:
            # Fallback to UUID if anything goes wrong
            print(f"Error generating meaningful log ID: {e}")
            return str(uuid.uuid4())
    
    def store_record(self, user_id: str, team_id: str, raw_file_path: str, 
                    processed_file_path: str, context: str, embeddings: Dict[str, Any],
                    visibility: str = 'self') -> str:
        """
        Stage 9: Store processed record in database
        """
        try:
            record_id = self._generate_meaningful_log_id(raw_file_path)
            
            # Get file statistics
            raw_stats = self._get_file_stats(raw_file_path)
            processed_stats = self._get_file_stats(processed_file_path)
            
            # Extract problems from processed file
            problems = self.log_processor.extract_problems(processed_file_path)
            
            # Generate overall summary
            overall_summary = self._generate_overall_summary(processed_file_path)
            
            # Calculate overall severity
            overall_severity = self._calculate_overall_severity(problems)
            
            # Extract tags from content
            tags = self._extract_tags(processed_file_path)
            
            # Create record document
            record_doc = {
                'record_id': record_id,
                'owner_user_id': user_id,
                'team_id': team_id,
                'visibility': visibility,
                'title': self._generate_title(raw_file_path, context),
                'tags': tags,
                'context': context,
                'raw_file_path': raw_file_path,
                'processed_file_path': processed_file_path,
                'raw_stats': raw_stats,
                'processed_stats': processed_stats,
                'overall_summary': overall_summary,
                'overall_severity': overall_severity,
                'problems': problems,
                'embedding': embeddings.get('record_embedding', []),
                'created_at': datetime.now(timezone.utc).isoformat(),
                'updated_at': datetime.now(timezone.utc).isoformat(),
                'genapi': {
                    'analyzed': False,
                    'result_version': 0,
                    'summary': '',
                    'problems': [],
                    'overall_severity': 0,
                    'key_insights': [],
                    'recommendations': []
                }
            }
            
            # Store record in database
            result = self.db.create_record(record_doc)
            if not result['success']:
                raise Exception(f"Failed to create record: {result['error']}")
            
            # Store chunk embeddings
            if 'chunk_embeddings' in embeddings:
                self.db.store_record_chunks(
                    record_id, 
                    embeddings['chunk_embeddings'], 
                    user_id, 
                    team_id, 
                    visibility
                )

            # Compute similarity against existing accessible records and attach similarity list (>= 80%)
            try:
                queryable_records = self.db.get_records(user_id, team_id, 'all')
                top_sim = 0.0
                top_id = None
                above_threshold = []  # list of {record_id, similarity_score}
                current_emb = record_doc.get('embedding') or []
                if current_emb and queryable_records:
                    for rec in queryable_records:
                        if rec.get('record_id') == record_id:
                            continue
                        other_emb = rec.get('embedding') or []
                        if other_emb:
                            sim = self.embedding_service.compute_similarity(current_emb, other_emb)
                            if sim > top_sim:
                                top_sim = sim
                                top_id = rec.get('record_id')
                            if sim >= 0.80:
                                above_threshold.append({
                                    'record_id': rec.get('record_id'),
                                    'similarity_score': float(sim)
                                })
                # Persist similarity info (0-100)
                try:
                    self.db.es.update(
                        index=self.db.indices['records'],
                        id=record_id,
                        body={
                            'doc': {
                                'similarity_pct': int(round(top_sim * 100)),
                                'similar_to': top_id,
                                'similar_items': above_threshold,
                                'updated_at': datetime.now(timezone.utc).isoformat()
                            }
                        }
                    )
                except Exception:
                    pass
            except Exception:
                # Non-fatal; similarity will be computed later on demand
                pass
            
            return record_id
            
        except Exception as e:
            print(f"Error storing record: {e}")
            raise e
    
    def _get_file_stats(self, file_path: str) -> Dict[str, Any]:
        """Get file statistics"""
        try:
            if not os.path.exists(file_path):
                return {'line_count': 0, 'size_bytes': 0, 'file_name': 'unknown'}
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            return {
                'line_count': len(lines),
                'size_bytes': os.path.getsize(file_path),
                'file_name': os.path.basename(file_path)
            }
        except Exception as e:
            print(f"Error getting file stats: {e}")
            return {'line_count': 0, 'size_bytes': 0, 'file_name': 'unknown'}
    
    def _generate_overall_summary(self, processed_file_path: str) -> str:
        """Generate overall summary of the processed log"""
        try:
            with open(processed_file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Extract key information from processed content
            lines = content.split('\n')
            
            # Count different types of content
            total_chunks = sum(1 for line in lines if line.startswith('CHUNK'))
            error_chunks = sum(1 for line in lines if 'ERROR DETECTED' in line)
            raw_lines = sum(1 for line in lines if line.startswith('RAW:'))
            
            # Generate summary based on content
            if error_chunks > 0:
                summary = f"Log analysis completed. Found {error_chunks} error chunks out of {total_chunks} total chunks. "
                if error_chunks > total_chunks * 0.5:
                    summary += "High error rate detected - immediate attention required."
                elif error_chunks > total_chunks * 0.2:
                    summary += "Moderate error rate detected - review recommended."
                else:
                    summary += "Low error rate detected - system appears stable."
            else:
                summary = f"Log analysis completed. {total_chunks} chunks processed with no errors detected. System appears stable."
            
            return summary
            
        except Exception as e:
            print(f"Error generating overall summary: {e}")
            return "Log analysis completed with basic processing."
    
    def _calculate_overall_severity(self, problems: List[Dict[str, Any]]) -> int:
        """Calculate overall severity score (0-100)"""
        if not problems:
            return 0
        
        # Calculate weighted average of problem severities
        total_severity = sum(problem.get('severity', 0) for problem in problems)
        avg_severity = total_severity / len(problems)
        
        # Apply penalty for multiple problems
        if len(problems) > 1:
            avg_severity = min(avg_severity * (1 + len(problems) * 0.1), 100)
        
        return int(avg_severity)
    
    def _extract_tags(self, processed_file_path: str) -> List[str]:
        """Extract relevant tags from processed content"""
        try:
            with open(processed_file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tags = []
            text = content.lower()
            
            # Core high-level tags
            if 'kernel' in text:
                tags.append('Kernel')
            if any(k in text for k in ['network', 'tcp', 'udp', 'ip', 'socket', 'dns', 'firewall', 'routing']):
                tags.append('🖧 Networking')
            if any(k in text for k in ['database', 'sql', 'query']):
                tags.append('Database')
            if 'security' in text or any(k in text for k in ['auth', 'encrypt', 'integrity', 'privilege', 'sandbox', 'access control']):
                tags.append('🔒 Security')
            if any(k in text for k in ['cpu', 'gpu', 'sensor', 'peripheral', 'battery', 'temperature']):
                tags.append('💻 Hardware')
            if any(k in text for k in ['memory', 'heap', 'stack', 'page fault', 'swap', 'cache']):
                tags.append('Memory')
            if 'filesystem' in text or 'disk' in text:
                tags.append('Storage')
            if any(k in text for k in ['boot', 'driver', 'process', 'thread', 'scheduler', 'syscall', 'config', 'performance']):
                tags.append('System')

            # Networking sub-tags
            if 'tcp' in text:
                tags.append('TCP')
            if 'udp' in text:
                tags.append('UDP')
            if 'ip' in text:
                tags.append('IP')
            if 'socket' in text:
                tags.append('SOCKET')
            if 'firewall' in text:
                tags.append('FIREWALL')
            if 'routing' in text:
                tags.append('ROUTING')
            if 'dns' in text:
                tags.append('DNS')
            if 'protocol' in text:
                tags.append('PROTOCOL')
            if 'bandwidth' in text:
                tags.append('BANDWIDTH')
            if 'latency' in text:
                tags.append('LATENCY')

            # Memory sub-tags
            if 'heap' in text:
                tags.append('HEAP')
            if 'stack' in text:
                tags.append('STACK')
            if 'page fault' in text or 'pagefault' in text:
                tags.append('PAGEFAULT')
            if 'swap' in text:
                tags.append('SWAP')
            if 'cache' in text:
                tags.append('CACHE')
            if 'filesystem' in text:
                tags.append('FILESYSTEM')
            if 'disk' in text:
                tags.append('DISK')

            # Kernel sub-tags
            if 'interrupt' in text:
                tags.append('INTERRUPT')
            if 'context switch' in text or 'contextswitch' in text:
                tags.append('CONTEXTSWITCH')
            if 'deadlock' in text:
                tags.append('DEADLOCK')
            if 'race condition' in text or 'racecondition' in text:
                tags.append('RACECONDITION')
            if 'synchronization' in text or 'mutex' in text or 'semaphore' in text:
                tags.append('SYNCHRONIZATION')
            if 'module' in text:
                tags.append('MODULE')
            if 'driver' in text and 'api' in text:
                tags.append('DRIVERAPI')

            # Hardware sub-tags
            if 'cpu' in text:
                tags.append('CPU')
            if 'gpu' in text:
                tags.append('GPU')
            if 'power' in text:
                tags.append('POWER')
            if 'battery' in text:
                tags.append('BATTERY')
            if 'sensor' in text:
                tags.append('SENSOR')
            if 'temperature' in text:
                tags.append('TEMPERATURE')
            if 'peripheral' in text:
                tags.append('PERIPHERAL')
            if any(k in text for k in ['pci', 'i2c', 'spi']):
                tags.append('BUS')

            # Security sub-tags
            if 'authentication' in text or 'login failed' in text:
                tags.append('AUTHENTICATION')
            if 'authorization' in text:
                tags.append('AUTHORIZATION')
            if 'encrypt' in text:
                tags.append('ENCRYPTION')
            if 'integrity' in text:
                tags.append('INTEGRITY')
            if 'privilege' in text:
                tags.append('PRIVILEGE')
            if 'sandbox' in text:
                tags.append('SANDBOX')
            if 'access control' in text or 'accesscontrol' in text:
                tags.append('ACCESSCONTROL')
            
            # Add severity-based tags
            if 'CRITICAL' in content:
                tags.append('critical')
            elif 'HIGH' in content:
                tags.append('high-severity')
            elif 'ERROR' in content:
                tags.append('error')
            else:
                tags.append('normal')
            
            return list(set(tags))  # Remove duplicates
            
        except Exception as e:
            print(f"Error extracting tags: {e}")
            return ['unknown']
    
    def _generate_title(self, raw_file_path: str, context: str) -> str:
        """Generate a title for the record"""
        try:
            file_name = os.path.basename(raw_file_path)
            # Always derive title from filename only (do not append user context or prefixes)
            base = file_name.rsplit('.', 1)[0] if '.' in file_name else file_name
            # If filename contains UUID/random strings, move them to the end so the human name comes first
            try:
                parts = re.split(r'[_\s]+', base)
                uuid_re = re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
                uuid_like = [p for p in parts if uuid_re.match(p)]
                others = [p for p in parts if not uuid_re.match(p)]
                if uuid_like and others:
                    base = '_'.join(others + uuid_like)
            except Exception:
                pass
            # Trim excessively long filenames to keep UI tidy
            if len(base) > 80:
                base = base[:80]
            return base
                
        except Exception as e:
            print(f"Error generating title: {e}")
            return "Log Analysis Record"
    
    def update_record_visibility(self, record_id: str, user_id: str, visibility: str) -> Dict[str, Any]:
        """Update record visibility"""
        try:
            result = self.db.update_record_visibility(record_id, user_id, visibility)
            return result
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_record_summary(self, record_id: str, user_id: str, team_id: str) -> Optional[Dict[str, Any]]:
        """Get summary information for a record"""
        try:
            record = self.db.get_record(record_id, user_id, team_id)
            if not record:
                return None
            
            return {
                'record_id': record['record_id'],
                'title': record.get('title', 'Untitled'),
                'overall_summary': record.get('overall_summary', ''),
                'overall_severity': record.get('overall_severity', 0),
                'problems_count': len(record.get('problems', [])),
                'tags': record.get('tags', []),
                'created_at': record.get('created_at', ''),
                'visibility': record.get('visibility', 'self')
            }
        except Exception as e:
            print(f"Error getting record summary: {e}")
            return None
    
    def delete_record(self, record_id: str, user_id: str) -> Dict[str, Any]:
        """Delete a record and its associated data"""
        try:
            # Check if user owns the record
            record = self.db.get_record(record_id, user_id, '')  # Empty team_id to check ownership only
            if not record or record['owner_user_id'] != user_id:
                return {'success': False, 'error': 'Not authorized'}
            
            # Delete record chunks
            chunk_query = {
                "query": {
                    "term": {"record_id": record_id}
                }
            }
            self.db.es.delete_by_query(
                index=self.db.indices['record_chunks'],
                body=chunk_query
            )
            
            # Delete conversations
            conv_query = {
                "query": {
                    "term": {"record_id": record_id}
                }
            }
            self.db.es.delete_by_query(
                index=self.db.indices['conversations'],
                body=conv_query
            )
            
            # Delete the record
            self.db.es.delete(
                index=self.db.indices['records'],
                id=record_id
            )
            
            # Clean up files
            try:
                if os.path.exists(record['raw_file_path']):
                    os.remove(record['raw_file_path'])
                if os.path.exists(record['processed_file_path']):
                    os.remove(record['processed_file_path'])
            except Exception as e:
                print(f"Warning: Could not delete files: {e}")
            
            return {'success': True}
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_storage_stats(self, user_id: str, team_id: str) -> Dict[str, Any]:
        """Get storage statistics for user/team"""
        try:
            # Get user's records
            user_records = self.db.get_records(user_id, team_id, 'mine')
            
            # Calculate statistics
            total_records = len(user_records)
            total_size = sum(record.get('raw_stats', {}).get('size_bytes', 0) for record in user_records)
            total_problems = sum(len(record.get('problems', [])) for record in user_records)
            
            # Severity distribution
            severity_dist = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'normal': 0}
            for record in user_records:
                severity = record.get('overall_severity', 0)
                if severity >= 90:
                    severity_dist['critical'] += 1
                elif severity >= 70:
                    severity_dist['high'] += 1
                elif severity >= 50:
                    severity_dist['medium'] += 1
                elif severity >= 20:
                    severity_dist['low'] += 1
                else:
                    severity_dist['normal'] += 1
            
            return {
                'total_records': total_records,
                'total_size_mb': total_size / (1024 * 1024),
                'total_problems': total_problems,
                'severity_distribution': severity_dist,
                'average_severity': sum(record.get('overall_severity', 0) for record in user_records) / max(total_records, 1)
            }
            
        except Exception as e:
            print(f"Error getting storage stats: {e}")
            return {'error': str(e)}
