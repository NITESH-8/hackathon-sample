# from collections import Counter
#
# def summarize_chunk(chunk: list[str]) -> str:
#     """
#     Very lightweight summarizer:
#     - Picks most frequent keywords
#     - Builds 1–2 line description
#     """
#     words = []
#     for line in chunk:
#         for w in line.strip().split():
#             if len(w) > 3:  # ignore very short tokens
#                 words.append(w.lower())
#
#     common = [w for w, _ in Counter(words).most_common(3)]
#     if not common:
#         return "No significant events detected."
#
#     return f"Safe chunk summary: contains {', '.join(common)}."

################################
#
# from collections import Counter
# from itertools import islice
#
# STOPWORDS = {"info", "debug", "trace", "service", "started", "successfully", "process"}
#
# def get_ngrams(words, n=2):
#     return [" ".join(words[i:i+n]) for i in range(len(words)-n+1)]
#
# def summarize_chunk(chunk: list[str]) -> str:
#     words = []
#     for line in chunk:
#         for w in line.strip().split():
#             token = w.lower()
#             if len(token) > 3 and token not in STOPWORDS:
#                 words.append(token)
#
#     if not words:
#         return "No significant events detected."
#
#     # Count single + bigrams
#     bigrams = get_ngrams(words, 2)
#     common = Counter(words + bigrams).most_common(5)
#
#     # Pick top keywords/phrases
#     top_phrases = [w for w, _ in islice(common, 3)]
#
#     # Try to pick a representative line
#     best_line = max(chunk, key=lambda l: sum(1 for t in top_phrases if t in l.lower()), default="")
#
#     if best_line:
#         return f"Safe chunk summary: {best_line.strip()}"
#     else:
#         return f"Safe chunk summary: contains {', '.join(top_phrases)}."
##############################################################################
import re
import math
from collections import Counter
from typing import List, Tuple
from functools import lru_cache

try:
    # Optional sklearn-based vectorizer for better n-gram handling
    from sklearn.feature_extraction.text import TfidfVectorizer
    _HAS_SKLEARN = True
except Exception:
    _HAS_SKLEARN = False

STOPWORDS = {
    "info", "debug", "trace", "service", "process", "thread", "started",
    "successfully", "running", "initializing", "completed", "ready", "starting",
    "level", "time", "msg", "version", "worker", "entropy", "systemd", "server",
    "daemon", "manager", "device", "socket", "layer", "subsys", "mounted"
}

TIMESTAMP_PATTERN = re.compile(r"\[.*?\]|\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}")
LOG_ID_PATTERN = re.compile(r"\w+\[\d+\]")

def clean_line(line: str) -> str:
    """Remove timestamps and noise."""
    line = TIMESTAMP_PATTERN.sub("", line)
    return line.strip()

def extract_service_names(chunk: List[str]) -> List[str]:
    """Extract service names from log lines (e.g., 'systemd[1]', 'dockerd[600]')."""
    services = []
    for line in chunk:
        matches = LOG_ID_PATTERN.findall(line)
        for match in matches:
            # Extract just the service name without the PID
            service = match.split('[')[0]
            if service and service.lower() not in STOPWORDS:
                services.append(service)
    return services

def find_representative_line(chunk: List[str], keywords: List[str]) -> str:
    """Find the most informative line in the chunk based on keywords."""
    if not chunk or not keywords:
        return ""
    
    # Score each line based on keyword presence and position (later lines often more important)
    scored_lines = []
    for i, line in enumerate(chunk):
        clean = clean_line(line).lower()
        # Score based on keyword matches and line position
        keyword_score = sum(2 for k in keywords if k in clean)
        position_score = i * 0.1  # Slight preference for later lines
        scored_lines.append((keyword_score + position_score, line))
    
    # Get the highest scoring line
    if scored_lines:
        return max(scored_lines, key=lambda x: x[0])[1]
    return ""

def extract_bigrams(words: List[str]) -> List[str]:
    """Extract meaningful bigrams from the word list."""
    if len(words) < 2:
        return []
    return [f"{words[i]} {words[i+1]}" for i in range(len(words)-1)]

@lru_cache(maxsize=1)
def _get_vectorizer():
    if not _HAS_SKLEARN:
        return None
    # Use char+word n-grams (1,2) with custom stopwords; min_df=1 for short chunks
    return TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        token_pattern=r"(?u)\b\w\w+\b",
        stop_words=list(STOPWORDS),
        min_df=1,
        max_df=1.0,
        norm='l2'
    )


def summarize_chunk(chunk: List[str]) -> str:
    """Generate a TF‑IDF based summary for non-error chunks.
    Uses scikit-learn's TfidfVectorizer with word bigrams when available,
    otherwise falls back to the pure-Python TF‑IDF implemented below.
    """
    if not chunk:
        return "No log data available."

    # Clean and normalize lines (keep original for service extraction)
    cleaned_lines = [clean_line(l) for l in chunk if l.strip()]
    if not cleaned_lines:
        return "No significant events detected."

    # Try sklearn vectorizer for robust TF‑IDF with n-grams
    vec = _get_vectorizer()
    if vec is not None:
        try:
            X = vec.fit_transform([l.lower() for l in cleaned_lines])  # lines as docs
            # Sum TF‑IDF per line to score lines
            import numpy as np
            line_scores = np.asarray(X.sum(axis=1)).ravel()
            best_idx = int(line_scores.argmax()) if line_scores.size else 0
            rep_line = cleaned_lines[best_idx].strip()

            # Get top feature names by global weight
            col_sums = np.asarray(X.sum(axis=0)).ravel()
            order = col_sums.argsort()[::-1]
            feature_names = np.array(vec.get_feature_names_out())
            rep_lower = rep_line.lower()
            key_terms = []
            for idx in order:
                term = feature_names[idx]
                if term in STOPWORDS:
                    continue
                if term not in rep_lower:
                    key_terms.append(term)
                if len(key_terms) >= 3:
                    break

            services = extract_service_names(chunk)
            service_counter = Counter(services)
            top_services = [s for s, _ in service_counter.most_common(2)]

            summary = f"Summary: {rep_line}" if rep_line else "Summary: Normal operational activity"
            if top_services:
                summary += f" [Services: {', '.join(top_services)}]"
            if key_terms:
                summary += f" [Key terms: {', '.join(key_terms)}]"
            return summary
        except Exception:
            # Fall back to pure-Python path below
            pass

    # Tokenize each line, filter stopwords and short tokens (pure-Python TF‑IDF)
    tokens_per_line: List[List[str]] = []
    for line in cleaned_lines:
        toks = []
        for w in line.lower().split():
            if len(w) > 3 and w not in STOPWORDS:
                toks.append(w)
        tokens_per_line.append(toks)

    if not any(tokens_per_line):
        rep_line = max(cleaned_lines, key=len, default="").strip()
        return f"Summary: {rep_line}" if rep_line else "No significant events detected."

    # Document frequency across lines
    df = Counter()
    for toks in tokens_per_line:
        for t in set(toks):
            df[t] += 1

    N = len(tokens_per_line)
    idf = {t: math.log((1 + N) / (1 + df[t])) + 1.0 for t in df}

    # Score lines by sum of TF*IDF
    scores = []
    for toks in tokens_per_line:
        tf = Counter(toks)
        score = sum(tf[t] * idf.get(t, 0.0) for t in tf)
        scores.append(score)

    best_idx = max(range(len(scores)), key=lambda i: scores[i])
    rep_line = cleaned_lines[best_idx].strip()

    # Aggregate TF‑IDF across the chunk for key terms
    term_scores = Counter()
    for toks in tokens_per_line:
        tf = Counter(toks)
        for t, c in tf.items():
            term_scores[t] += c * idf.get(t, 0.0)

    rep_lower = rep_line.lower()
    top_terms = [t for t, _ in term_scores.most_common(5) if t not in rep_lower][:3]

    # Service context
    services = extract_service_names(chunk)
    service_counter = Counter(services)
    top_services = [s for s, _ in service_counter.most_common(2)]

    summary = f"Summary: {rep_line}" if rep_line else "Summary: Normal operational activity"
    if top_services:
        summary += f" [Services: {', '.join(top_services)}]"
    if top_terms:
        summary += f" [Key terms: {', '.join(top_terms)}]"
    return summary

