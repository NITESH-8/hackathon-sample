# Tests

Overview:
- Backend tests: pytest-based API tests (auth, profile, analysis trigger)
- Frontend tests: React Testing Library (ApiService + UI render smoke)
- Integration tests: end-to-end upload → job → record fetch (requires services running)
- Performance tests: simple Python loop for latency/throughput
- Security tests: basic auth/authorization checks

Prerequisites:
- Python 3.9+
- Node 16+
- Backend at http://localhost:5000
- Elasticsearch running (or mock via monkeypatch)

Commands:

Backend:
```bash
pytest -q --maxfail=1 --disable-warnings
```

Coverage:
```bash
pytest --cov=.
```

Frontend (from project root):
```bash
npm test -- --watchAll=false
```

Integration:
```bash
python tests/integration/test_end_to_end.py
```

Performance:
```bash
python tests/performance/test_smoke_perf.py
```
