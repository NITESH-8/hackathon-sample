import app as app_module
import pytest

@pytest.fixture(scope='module')
def client():
    app = app_module.app
    app.config.update({'TESTING': True})
    with app.test_client() as c:
        yield c


def test_profile_requires_token(client):
    res = client.get('/profile/me')
    assert res.status_code == 401
