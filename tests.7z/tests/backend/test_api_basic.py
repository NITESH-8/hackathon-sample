import json
import os
import types
import pytest

# Import Flask app
import app as app_module

@pytest.fixture(scope="module")
def client():
    app = app_module.app
    app.config.update({
        'TESTING': True
    })
    with app.test_client() as c:
        yield c


def test_root_serves_index(client):
    res = client.get('/')
    assert res.status_code in (200,)


def test_signup_and_login_flow(monkeypatch, client):
    # Monkeypatch AuthManager to avoid ES
    from backend.auth import AuthManager

    fake_db = {}

    def fake_signup(self, userid, password, teamid):
        uid = f"user-{userid}"
        fake_db[userid] = {"user_id": uid, "team_id": teamid, "password": password}
        return {"success": True, "user_id": uid}

    def fake_login(self, userid, password):
        if userid in fake_db and fake_db[userid]["password"] == password:
            return {"success": True, "user_id": fake_db[userid]["user_id"], "team_id": fake_db[userid]["team_id"], "token": "test-token"}
        return {"success": False, "error": "Invalid"}

    monkeypatch.setattr(AuthManager, 'signup', fake_signup, raising=False)
    monkeypatch.setattr(AuthManager, 'login', fake_login, raising=False)

    r = client.post('/auth/signup', json={"userid": "testu", "password": "pass", "teamid": "team1"})
    assert r.status_code in (200, 201)

    r2 = client.post('/auth/login', json={"userid": "testu", "password": "pass"})
    assert r2.status_code == 200
    data = r2.get_json()
    assert 'token' in data


def test_profile_requires_auth(client):
    r = client.get('/profile/me')
    assert r.status_code in (401, 400)
