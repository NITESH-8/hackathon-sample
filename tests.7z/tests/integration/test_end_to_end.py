import os
import time
import requests

BASE = os.getenv('APP_BASE', 'http://localhost:5000')


def wait_ok(url, timeout=5):
    try:
        r = requests.get(url, timeout=timeout)
        return r.status_code < 500
    except Exception:
        return False


def test_smoke_endpoints_available():
    assert wait_ok(f"{BASE}/")
