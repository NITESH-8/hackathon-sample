import ApiService from '../../src/services/ApiService';

describe('ApiService', () => {
  test('exports methods', () => {
    expect(typeof ApiService.login).toBe('function');
    expect(typeof ApiService.getRecords).toBe('function');
    expect(typeof ApiService.analyzeRecord).toBe('function');
  });
});
