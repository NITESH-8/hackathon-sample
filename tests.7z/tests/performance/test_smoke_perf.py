import os
import time
import statistics
import requests

BASE = os.getenv('APP_BASE', 'http://localhost:5000')


def test_home_latency_under_1s():
    samples = []
    for _ in range(3):
        t0 = time.time()
        r = requests.get(f"{BASE}/", timeout=5)
        r.raise_for_status()
        samples.append(time.time() - t0)
    assert statistics.median(samples) < 1.0
